package ir.kian.hamrah

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

object Cloud {
    fun initialize(context: Context, apiKey: String, appId: String, projectId: String, dbUrl: String): Boolean {
        return try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                val options = FirebaseOptions.Builder()
                    .setApiKey(apiKey.trim())
                    .setApplicationId(appId.trim())
                    .setProjectId(projectId.trim())
                    .setDatabaseUrl(dbUrl.trim())
                    .build()
                FirebaseApp.initializeApp(context, options)
            }
            true
        } catch (_: Exception) { false }
    }
    fun auth() = FirebaseAuth.getInstance()
    fun db() = FirebaseDatabase.getInstance().reference
}
