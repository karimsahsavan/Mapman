package ir.kian.hamrah

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.firebase.database.*
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import java.util.UUID

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("kian", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private var map: MapView? = null
    private var locationListener: ValueEventListener? = null
    private var historyListener: ValueEventListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().userAgentValue = packageName
        showSetup()
    }

    private fun page(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 18, 22, 18)
            setBackgroundColor(0xFFFFF7ED.toInt())
        }
        setContentView(ScrollView(this).apply { addView(root) })
        root.addView(TextView(this).apply {
            text = title; textSize = 24f; gravity = Gravity.CENTER
            setTextColor(0xFFD9572D.toInt()); setPadding(0, 8, 0, 16)
        })
    }

    private fun field(hint: String, key: String): EditText {
        val e = EditText(this).apply {
            this.hint = hint; setSingleLine(true); textSize = 14f
            setText(prefs.getString(key, "") ?: "")
        }
        root.addView(e, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 7 })
        return e
    }

    private fun button(label: String, action: () -> Unit) {
        root.addView(Button(this).apply { text = label; setOnClickListener { action() } },
            LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 6 })
    }

    private fun saveCloud(api: String, app: String, project: String, url: String, family: String) {
        prefs.edit().putString("api",api).putString("app",app).putString("project",project)
            .putString("url",url).putString("family",family).apply()
    }

    private fun cloudReady(done: () -> Unit) {
        val ok = Cloud.initialize(this, prefs.getString("api","") ?: "", prefs.getString("app","") ?: "",
            prefs.getString("project","") ?: "", prefs.getString("url","") ?: "")
        if (!ok) { toast("ابتدا مشخصات Firebase را کامل وارد کن."); showSetup(); return }
        val auth = Cloud.auth()
        if (auth.currentUser != null) done()
        else auth.signInAnonymously().addOnSuccessListener { done() }
            .addOnFailureListener { toast("ورود به Firebase ناموفق: ${it.message}") }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun showSetup() {
        page("کیان همراه")
        root.addView(TextView(this).apply {
            text = "تنظیمات Firebase را می‌توانی بعداً وارد کنی. برای ارتباط دو گوشی، مشخصات یک پروژه را در هر دو وارد کن."
            textSize = 14f
        })
        val api = field("Firebase API Key", "api")
        val app = field("Firebase App ID", "app")
        val project = field("Firebase Project ID", "project")
        val url = field("Realtime Database URL", "url")
        val family = field("کد خانواده", "family")
        val role = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("پدر – نقشه و مدیریت", "فرزند – ارسال موقعیت"))
            setSelection(if (prefs.getString("role","parent") == "child") 1 else 0)
        }
        root.addView(role)
        button("ذخیره و ادامه") {
            saveCloud(api.text.toString().trim(), app.text.toString().trim(), project.text.toString().trim(),
                url.text.toString().trim(), family.text.toString().trim())
            prefs.edit().putString("role", if (role.selectedItemPosition == 1) "child" else "parent").apply()
            if (api.text.isNullOrBlank() || app.text.isNullOrBlank() || project.text.isNullOrBlank() || url.text.isNullOrBlank()) {
                toast("تنظیمات ذخیره شد؛ برای اتصال واقعی باید چهار مقدار Firebase را وارد کنی.")
                return@button
            }
            cloudReady { if (prefs.getString("role","parent") == "child") showChild() else showParent() }
        }
    }

    private fun showChild() {
        page("گوشی فرزند")
        root.addView(TextView(this).apply {
            text = "این گوشی نقشه ندارد. پس از تأیید درخواست توسط پدر، موقعیت با اعلان دائمی ارسال می‌شود. اشتراک‌گذاری باید با اطلاع فرزند باشد."
            textSize = 15f
        })
        val family = field("کد خانواده پدر", "family")
        button("درخواست اتصال به پدر") {
            val code = family.text.toString().trim()
            if (code.length < 8) { toast("کد خانواده معتبر نیست."); return@button }
            saveCloud(prefs.getString("api","") ?: "", prefs.getString("app","") ?: "",
                prefs.getString("project","") ?: "", prefs.getString("url","") ?: "", code)
            cloudReady {
                val uid = Cloud.auth().currentUser!!.uid
                Cloud.db().child("families").child(code).child("pairingRequests").child(uid)
                    .setValue(mapOf("requestedAt" to ServerValue.TIMESTAMP, "status" to "pending"))
                    .addOnSuccessListener {
                        toast("درخواست ارسال شد. پس از تأیید پدر، اشتراک موقعیت را شروع کن.")
                        waitForApproval(code, uid)
                    }.addOnFailureListener { toast("ارسال درخواست ناموفق: ${it.message}") }
            }
        }
        button("شروع ارسال موقعیت (پس از تأیید پدر)") {
            cloudReady {
                val code = prefs.getString("family","") ?: ""
                val uid = Cloud.auth().currentUser!!.uid
                Cloud.db().child("families").child(code).child("childUid").get()
                    .addOnSuccessListener { snap ->
                        if (snap.getValue(String::class.java) != uid) {
                            toast("هنوز درخواستت توسط پدر تأیید نشده است."); return@addOnSuccessListener
                        }
                        requestLocationPermissions()
                    }.addOnFailureListener { toast("بررسی تأیید ناموفق بود.") }
            }
        }
        button("توقف اشتراک موقعیت") {
            stopService(Intent(this, LocationService::class.java))
            toast("ارسال موقعیت متوقف شد.")
        }
        button("تنظیمات") { showSetup() }
    }

    private fun waitForApproval(code: String, uid: String) {
        Cloud.db().child("families").child(code).child("childUid").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) {
                if (s.getValue(String::class.java) == uid) toast("درخواست اتصال تأیید شد. حالا ارسال موقعیت را شروع کن.")
            }
            override fun onCancelled(e: DatabaseError) { toast(e.message) }
        })
    }

    private fun requestLocationPermissions() {
        val p = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
        ActivityCompat.requestPermissions(this, p.toTypedArray(), 22)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != 22) return
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine) { toast("مجوز مکان دقیق لازم است."); return }
        if (Build.VERSION.SDK_INT >= 29 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            toast("از تنظیمات گوشی، مجوز مکان را روی «همیشه مجاز» قرار بده. تا آن زمان اجرای پس‌زمینه تضمین نیست.")
        }
        ContextCompat.startForegroundService(this, Intent(this, LocationService::class.java))
        showChild()
    }

    private fun showParent() {
        page("کیان همراه | والد")
        val family = prefs.getString("family","") ?: ""
        if (family.isBlank()) {
            root.addView(TextView(this).apply { text = "ابتدا خانواده بساز؛ کد را فقط به فرزندت بده."; textSize = 14f })
            button("ساخت خانواده و کد اتصال") {
                cloudReady {
                    val code = UUID.randomUUID().toString().replace("-","").take(16)
                    val uid = Cloud.auth().currentUser!!.uid
                    Cloud.db().child("families").child(code).child("parentUid").setValue(uid)
                        .addOnSuccessListener {
                            prefs.edit().putString("family",code).apply()
                            toast("کد خانواده ساخته شد: $code")
                            showParent()
                        }.addOnFailureListener { toast("ساخت خانواده ناموفق: ${it.message}") }
                }
            }
            button("تنظیمات") { showSetup() }
            return
        }
        root.addView(TextView(this).apply { text = "کد اتصال فرزند: $family\nدرخواست‌های فرزند را بررسی و تأیید کن."; textSize = 14f })
        val mv = MapView(this).also { map = it }
        mv.setTileSource(TileSourceFactory.MAPNIK)
        mv.setMultiTouchControls(true)
        mv.controller.setZoom(12.5)
        mv.controller.setCenter(GeoPoint(36.2972,59.6067))
        root.addView(mv, LinearLayout.LayoutParams(-1, 560))
        button("بررسی درخواست‌های اتصال") { loadRequests(family) }
        button("نمایش تاریخچه مسیر") { showHistory(family) }
        button("تنظیمات") { showSetup() }
        listenLatest(family)
    }

    private fun loadRequests(code: String) {
        cloudReady {
            val req = Cloud.db().child("families").child(code).child("pairingRequests")
            req.get().addOnSuccessListener { snap ->
                val pending = snap.children.filter { it.child("status").getValue(String::class.java) == "pending" }
                if (pending.isEmpty()) { toast("درخواست جدیدی وجود ندارد."); return@addOnSuccessListener }
                val uids = pending.mapNotNull { it.key }
                val choices = uids.toTypedArray()
                android.app.AlertDialog.Builder(this).setTitle("درخواست اتصال")
                    .setItems(choices) { _, which -> approveChild(code, choices[which]) }
                    .setNegativeButton("بستن", null).show()
            }.addOnFailureListener { toast("خواندن درخواست‌ها ناموفق: ${it.message}") }
        }
    }

    private fun approveChild(code: String, uid: String) {
        cloudReady {
            val familyRef = Cloud.db().child("families").child(code)
            familyRef.child("childUid").setValue(uid).addOnSuccessListener {
                familyRef.child("pairingRequests").child(uid).child("status").setValue("approved")
                toast("فرزند تأیید شد.")
            }.addOnFailureListener { toast("تأیید ناموفق: ${it.message}") }
        }
    }

    private fun listenLatest(code: String) {
        cloudReady {
            val ref = Cloud.db().child("families").child(code).child("lastLocation")
            locationListener?.let { ref.removeEventListener(it) }
            locationListener = object : ValueEventListener {
                override fun onDataChange(s: DataSnapshot) {
                    val lat = s.child("lat").getValue(Double::class.java) ?: return
                    val lon = s.child("lon").getValue(Double::class.java) ?: return
                    val point = GeoPoint(lat,lon)
                    map?.let { m ->
                        m.overlays.removeAll { it is Marker }
                        m.overlays.add(Marker(m).apply { position = point; title = "موقعیت فرزند"; setAnchor(Marker.ANCHOR_CENTER,Marker.ANCHOR_BOTTOM) })
                        m.controller.animateTo(point); m.invalidate()
                    }
                }
                override fun onCancelled(e: DatabaseError) { toast("دریافت موقعیت ناموفق: ${e.message}") }
            }
            ref.addValueEventListener(locationListener!!)
        }
    }

    private fun showHistory(code: String) {
        page("تاریخچه مسیر")
        val info = TextView(this).apply { text = "در حال دریافت مسیرها…"; textSize = 14f }
        root.addView(info)
        val historyMap = MapView(this)
        historyMap.setTileSource(TileSourceFactory.MAPNIK)
        historyMap.setMultiTouchControls(true)
        historyMap.controller.setZoom(13.0)
        historyMap.controller.setCenter(GeoPoint(36.2972,59.6067))
        root.addView(historyMap, LinearLayout.LayoutParams(-1, 430))
        button("بازگشت به نقشه") { showParent() }
        cloudReady {
            val ref = Cloud.db().child("families").child(code).child("history").limitToLast(300)
            historyListener?.let { ref.removeEventListener(it) }
            historyListener = object : ValueEventListener {
                override fun onDataChange(s: DataSnapshot) {
                    val pts = mutableListOf<GeoPoint>()
                    s.children.forEach { item ->
                        val lat = item.child("lat").getValue(Double::class.java)
                        val lon = item.child("lon").getValue(Double::class.java)
                        if (lat != null && lon != null) pts.add(GeoPoint(lat,lon))
                    }
                    info.text = "تعداد نقاط دریافت‌شده: ${pts.size}  |  حداکثر ۳۰۰ نقطه اخیر"
                    if (pts.isNotEmpty()) {
                        val line = Polyline().apply { setPoints(pts); title = "مسیر ثبت‌شده" }
                        historyMap.overlays.add(line)
                        historyMap.overlays.add(Marker(historyMap).apply { position=pts.last(); title="آخرین نقطه" })
                        historyMap.controller.setCenter(pts.last())
                        historyMap.invalidate()
                    }
                }
                override fun onCancelled(e: DatabaseError) { info.text = "خطا: ${e.message}" }
            }
            ref.addValueEventListener(historyListener!!)
        }
    }

    override fun onResume() { super.onResume(); map?.onResume() }
    override fun onPause() { map?.onPause(); super.onPause() }
}
