package com.shik.dialer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.Drawable
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.abs

/**
 * Swipe a row right / left to run the action chosen in Settings
 * (call, message, delete). The row snaps back after the swipe.
 */
class SwipeHandler(
    private val ctx: Context,
    private val itemAt: (Int) -> Entry?,
    private val onAction: (Int, Entry) -> Unit
) : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT) {

    private val d = ctx.resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    private val icCall = icon(R.drawable.ic_call)
    private val icSms = icon(R.drawable.ic_message)
    private val icDelete = icon(R.drawable.ic_delete)

    private fun icon(res: Int): Drawable {
        val raw = ContextCompat.getDrawable(ctx, res)!!.mutate()
        val dr = DrawableCompat.wrap(raw)
        DrawableCompat.setTint(dr, Color.WHITE)
        return dr
    }

    private fun colorOf(action: Int): Int = when (action) {
        Prefs.SW_CALL -> 0xFF1FC46A.toInt()
        Prefs.SW_SMS -> 0xFF2F80ED.toInt()
        else -> 0xFFF0524A.toInt()
    }

    private fun iconOf(action: Int): Drawable = when (action) {
        Prefs.SW_CALL -> icCall
        Prefs.SW_SMS -> icSms
        else -> icDelete
    }

    override fun getSwipeDirs(rv: RecyclerView, vh: RecyclerView.ViewHolder): Int {
        if (vh !is EntryAdapter.VH) return 0 // day bars are not swipeable
        var dirs = 0
        if (Prefs.swipeRight(ctx) != Prefs.SW_NONE) dirs = dirs or ItemTouchHelper.RIGHT
        if (Prefs.swipeLeft(ctx) != Prefs.SW_NONE) dirs = dirs or ItemTouchHelper.LEFT
        return dirs
    }

    override fun onMove(
        rv: RecyclerView,
        vh: RecyclerView.ViewHolder,
        target: RecyclerView.ViewHolder
    ): Boolean = false

    override fun getSwipeThreshold(vh: RecyclerView.ViewHolder): Float = 0.36f

    override fun onSwiped(vh: RecyclerView.ViewHolder, direction: Int) {
        val pos = vh.bindingAdapterPosition
        if (pos == RecyclerView.NO_POSITION) return
        val action = if (direction == ItemTouchHelper.RIGHT) Prefs.swipeRight(ctx)
        else Prefs.swipeLeft(ctx)
        val e = itemAt(pos)
        // snap the row back; the action itself happens afterwards
        vh.bindingAdapter?.notifyItemChanged(pos)
        if (e != null) onAction(action, e)
    }

    override fun onChildDraw(
        c: Canvas,
        rv: RecyclerView,
        vh: RecyclerView.ViewHolder,
        dX: Float,
        dY: Float,
        actionState: Int,
        isCurrentlyActive: Boolean
    ) {
        if (actionState == ItemTouchHelper.ACTION_STATE_SWIPE && dX != 0f) {
            val v = vh.itemView
            val action = if (dX > 0f) Prefs.swipeRight(ctx) else Prefs.swipeLeft(ctx)
            paint.color = colorOf(action)
            val top = v.top.toFloat()
            val bottom = v.bottom.toFloat()
            if (dX > 0f) rect.set(v.left.toFloat(), top, v.left + dX, bottom)
            else rect.set(v.right + dX, top, v.right.toFloat(), bottom)
            val r = 22f * d
            c.drawRoundRect(rect, r, r, paint)

            val size = (24f * d).toInt()
            val pad = (24f * d).toInt()
            if (abs(dX) > pad + size + 8f * d) {
                val ic = iconOf(action)
                val cy = ((top + bottom) / 2f).toInt()
                val left = if (dX > 0f) v.left + pad else v.right - pad - size
                ic.setBounds(left, cy - size / 2, left + size, cy + size / 2)
                ic.draw(c)
            }
        }
        super.onChildDraw(c, rv, vh, dX, dY, actionState, isCurrentlyActive)
    }
}
