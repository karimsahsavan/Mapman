package com.shik.dialer

import android.content.Context

/** Which cartoon (woman / man) each contact number gets. Unset = decided from the contact key. */
object Genders {

    private fun sp(c: Context) =
        c.applicationContext.getSharedPreferences("shik_gender", Context.MODE_PRIVATE)

    fun get(c: Context, number: String): Int {
        val k = PhotoStore.key(number)
        if (k.isEmpty()) return GENDER_AUTO
        return sp(c).getInt(k, GENDER_AUTO)
    }

    fun set(c: Context, number: String, g: Int) {
        val k = PhotoStore.key(number)
        if (k.isEmpty()) return
        if (g == GENDER_AUTO) sp(c).edit().remove(k).apply()
        else sp(c).edit().putInt(k, g).apply()
    }

    fun remove(c: Context, number: String) = set(c, number, GENDER_AUTO)

    fun move(c: Context, from: String, to: String) {
        val a = PhotoStore.key(from)
        val b = PhotoStore.key(to)
        if (a.isEmpty() || b.isEmpty() || a == b) return
        val g = sp(c).getInt(a, GENDER_AUTO)
        if (g != GENDER_AUTO) sp(c).edit().putInt(b, g).remove(a).apply()
    }

    /** The gender the cartoon is really drawn with (so forms can pre-select it). */
    fun effective(c: Context, number: String, title: String): Int {
        val key = PhotoStore.key(number).ifEmpty { title }
        return if (avatarIsFemale(key, get(c, number))) GENDER_FEMALE else GENDER_MALE
    }
}
