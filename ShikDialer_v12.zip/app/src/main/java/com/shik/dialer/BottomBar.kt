package com.shik.dialer

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Colourful bottom bar: every tab has its own accent colour, the selected tab gets a soft
 * pill that pops in and its icon bounces. The round call button floats above the bar.
 */
class BottomBar @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) :
    LinearLayout(ctx, attrs) {

    private class Slot(
        val id: Int,
        val pill: View,
        val icon: ImageView,
        val label: TextView,
        val color: Int
    )

    private val d = resources.displayMetrics.density
    private val idle = 0xFF8B93A7.toInt()
    private val slots = ArrayList<Slot>()
    private var current = -1

    /** Return true to let the tab become selected. */
    var onSelect: ((Int) -> Boolean)? = null

    var selectedId: Int
        get() = current
        set(value) {
            select(value)
        }

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        clipChildren = false
        background = GradientDrawable().apply {
            setColor(Color.WHITE)
            val r = 26f * d
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            setStroke(maxOf(1, d.toInt()), 0xFFECEFF5.toInt())
        }
        elevation = 12f * d

        addTab(R.id.nav_keypad, R.drawable.ic_dialpad, R.string.tab_keypad, 0xFF1FC46A.toInt())
        addTab(R.id.nav_recents, R.drawable.ic_history, R.string.tab_recents, 0xFF2F80ED.toInt())
        addTab(R.id.nav_contacts, R.drawable.ic_person, R.string.tab_contacts, 0xFF8E5CF7.toInt())
        addTab(R.id.nav_settings, R.drawable.ic_settings, R.string.tab_settings, 0xFFFF8F3F.toInt())
    }

    private fun px(v: Float): Int = (v * d).toInt()

    private fun addTab(id: Int, iconRes: Int, labelRes: Int, color: Int) {
        val col = LinearLayout(context)
        col.orientation = VERTICAL
        col.gravity = Gravity.CENTER
        col.isClickable = true
        col.isFocusable = true

        val frame = FrameLayout(context)
        val pill = View(context)
        pill.background = GradientDrawable().apply {
            cornerRadius = 16f * d
            setColor(Color.argb(0x2E, Color.red(color), Color.green(color), Color.blue(color)))
        }
        pill.alpha = 0f
        frame.addView(pill, FrameLayout.LayoutParams(px(58f), px(32f), Gravity.CENTER))

        val icon = ImageView(context)
        icon.setImageResource(iconRes)
        icon.imageTintList = ColorStateList.valueOf(idle)
        frame.addView(icon, FrameLayout.LayoutParams(px(24f), px(24f), Gravity.CENTER))
        col.addView(frame, LinearLayout.LayoutParams(px(58f), px(32f)))

        val label = TextView(context)
        label.setText(labelRes)
        label.textSize = 11f
        label.setTextColor(idle)
        label.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        label.maxLines = 1
        label.gravity = Gravity.CENTER
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = px(3f)
        col.addView(label, lp)

        Anim.press(col, 0.92f)
        col.setOnClickListener { select(id) }
        addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        slots.add(Slot(id, pill, icon, label, color))
    }

    /** Kept for compatibility: the call button now floats above the bar on its own. */
    fun setCallLabel(resId: Int) {}

    private fun select(id: Int) {
        if (id == current) return
        val next = slots.firstOrNull { it.id == id } ?: return
        val ok = onSelect?.invoke(id) ?: true
        if (!ok) return
        val prev = slots.firstOrNull { it.id == current }
        current = id
        if (prev != null) style(prev, false)
        style(next, true)
    }

    private fun style(s: Slot, on: Boolean) {
        val c = if (on) s.color else idle
        s.icon.imageTintList = ColorStateList.valueOf(c)
        s.label.setTextColor(c)
        s.label.typeface = Typeface.create("sans-serif-medium", if (on) Typeface.BOLD else Typeface.NORMAL)
        s.pill.animate().cancel()
        s.icon.animate().cancel()
        if (on) {
            s.pill.scaleX = 0.4f
            s.pill.alpha = 0f
            s.pill.animate().alpha(1f).scaleX(1f).setDuration(280)
                .setInterpolator(OvershootInterpolator(1.7f)).start()
            s.icon.scaleX = 0.7f
            s.icon.scaleY = 0.7f
            s.icon.animate().scaleX(1f).scaleY(1f).setDuration(340)
                .setInterpolator(OvershootInterpolator(3f)).start()
        } else {
            s.pill.animate().alpha(0f).setDuration(160).start()
            s.icon.scaleX = 1f
            s.icon.scaleY = 1f
        }
    }
}
