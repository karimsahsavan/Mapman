package com.shik.dialer

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.telecom.VideoProfile

class AnswerActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CallManager.primary?.answer(VideoProfile.STATE_AUDIO_ONLY)
        startActivity(Intent(this, InCallActivity::class.java))
        finish()
    }
}
