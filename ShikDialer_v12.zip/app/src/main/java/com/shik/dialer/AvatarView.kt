package com.shik.dialer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.util.AttributeSet
import android.view.Choreographer
import android.view.View
import android.view.ViewOutlineProvider
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** One shared frame clock for every visible avatar (~30 fps), so lists stay cheap. */
object AvatarClock : Choreographer.FrameCallback {
    private val views = ArrayList<View>()
    private var running = false
    private var last = 0L

    @Volatile
    var now: Long = SystemClock.uptimeMillis()
        private set

    /** Prefs.REACT_*: 0 all moves, 1 blink only, 2 still. */
    @Volatile
    var reaction: Int = 0

    fun register(v: View) {
        if (!views.contains(v)) views.add(v)
        if (!running) {
            running = true
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    fun unregister(v: View) {
        views.remove(v)
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (views.isEmpty()) {
            running = false
            return
        }
        val t = frameTimeNanos / 1_000_000L
        now = t
        if (t - last >= 30L) {
            last = t
            for (i in views.indices.reversed()) views[i].invalidate()
        }
        Choreographer.getInstance().postFrameCallback(this)
    }
}

private val SKINS = intArrayOf(
    0xFFFFE0C7.toInt(), 0xFFF8CFA8.toInt(), 0xFFEDB78C.toInt(),
    0xFFD39A6E.toInt(), 0xFFA9724B.toInt(), 0xFF7A5035.toInt()
)
private val HAIRS = intArrayOf(
    0xFF2A1A12.toInt(), 0xFF4B2E1B.toInt(), 0xFF16161C.toInt(), 0xFFB5651D.toInt(),
    0xFFE0A93B.toInt(), 0xFF7B3FA0.toInt(), 0xFF2F6DB5.toInt(), 0xFFD9B26F.toInt(),
    0xFFB03A48.toInt()
)
private val SHIRTS = intArrayOf(
    0xFFFF6F91.toInt(), 0xFF6C8CFF.toInt(), 0xFF2EC4A0.toInt(), 0xFFFFA94D.toInt(),
    0xFFA77BFF.toInt(), 0xFF3BB6F0.toInt(), 0xFFEF5350.toInt()
)
private val EYES = intArrayOf(
    0xFF3B2A20.toInt(), 0xFF5A3A22.toInt(), 0xFF2F6DB5.toInt(),
    0xFF2E8B6A.toInt(), 0xFF7A5A1E.toInt(), 0xFF5B4B8A.toInt()
)
private val BG_A = intArrayOf(
    0xFFD7F7E6.toInt(), 0xFFD6E4FF.toInt(), 0xFFFFE3D3.toInt(),
    0xFFEBDDFF.toInt(), 0xFFFFF3C9.toInt(), 0xFFD3F4F7.toInt()
)
private val BG_B = intArrayOf(
    0xFF8FDDB8.toInt(), 0xFF9DBAFF.toInt(), 0xFFFFB592.toInt(),
    0xFFC6A9FF.toInt(), 0xFFFFDB75.toInt(), 0xFF8AD6E3.toInt()
)

const val GENDER_AUTO = 0
const val GENDER_FEMALE = 1
const val GENDER_MALE = 2

/** True when the cartoon for [key] is drawn as a woman ([gender] AUTO = decided from the key). */
fun avatarIsFemale(key: String, gender: Int): Boolean = when (gender) {
    GENDER_FEMALE -> true
    GENDER_MALE -> false
    else -> mix(key.hashCode() and 0x7fffffff, 7) % 2 == 0
}

private fun mix(seed: Int, salt: Int): Int {
    var x = seed xor (salt * 0x45d9f3b)
    x = (x xor (x ushr 16)) * 0x45d9f3b
    x = x xor (x ushr 16)
    return x and 0x7fffffff
}

private fun shade(c: Int, f: Float): Int = Color.rgb(
    (Color.red(c) * f).toInt().coerceIn(0, 255),
    (Color.green(c) * f).toInt().coerceIn(0, 255),
    (Color.blue(c) * f).toInt().coerceIn(0, 255)
)

private fun tint(c: Int, f: Float): Int = Color.rgb(
    (Color.red(c) + (255 - Color.red(c)) * f).toInt().coerceIn(0, 255),
    (Color.green(c) + (255 - Color.green(c)) * f).toInt().coerceIn(0, 255),
    (Color.blue(c) + (255 - Color.blue(c)) * f).toInt().coerceIn(0, 255)
)

private fun smooth(x: Float): Float {
    val v = x.coerceIn(0f, 1f)
    return v * v * (3f - 2f * v)
}

/** 0 outside [a,b], 1 inside, with soft edges of width [ramp]. */
private fun env(t: Float, a: Float, b: Float, ramp: Float = 0.35f): Float =
    smooth(min((t - a) / ramp, (b - t) / ramp))

private fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t

/**
 * A round avatar. If a photo is set it shows the photo; otherwise it shows a cute cartoon
 * person with big shiny eyes, soft shading and a hairstyle / accessories of its own.
 * The character blinks, looks around, raises one eyebrow, laughs while clapping (with
 * floating hearts) and waves. It is derived from [setPerson]'s key, so each contact
 * always looks the same.
 */
class AvatarView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) :
    View(ctx, attrs) {

    /** Faster action cycle (used on the call screen). */
    var lively = false

    /** Draws a thin white ring around the avatar. */
    var ring = false

    /** Neutral, motionless pose (used when rendering the avatar into a notification icon). */
    var still = false

    private var seed = 0
    private var offsetMs = 0L
    private var skin = SKINS[0]
    private var hair = HAIRS[0]
    private var shirt = SHIRTS[0]
    private var accent = SHIRTS[1]
    private var eyeCol = EYES[0]
    private var hairStyle = 0
    private var lashes = false
    private var glasses = false
    private var beard = false
    private var bow = false
    private var earring = false
    private var freckles = false
    private var flip = false
    private var male = false
    private var tie = false

    private var bgShader: Shader? = null
    private var faceShader: Shader? = null
    private var bodyShader: Shader? = null
    private var hairShader: Shader? = null

    private var photo: Bitmap? = null
    private var photoShader: BitmapShader? = null

    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()
    private val path2 = Path()
    private val rect = RectF()
    private val matrix = Matrix()

    private val facePath = Path().apply { addOval(27f, 30f, 73f, 74f, Path.Direction.CW) }

    /** Beard with a hole for the mouth (even-odd fill). */
    private val beardPath = Path().apply {
        fillType = Path.FillType.EVEN_ODD
        moveTo(26f, 55f)
        cubicTo(29f, 71f, 40f, 79f, 50f, 79f)
        cubicTo(60f, 79f, 71f, 71f, 74f, 55f)
        quadTo(67f, 62f, 58f, 61f)
        quadTo(50f, 63.4f, 42f, 61f)
        quadTo(33f, 62f, 26f, 55f)
        close()
        addOval(44f, 62.6f, 56f, 69f, Path.Direction.CW)
    }

    init {
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                val s = min(view.width, view.height)
                val l = (view.width - s) / 2
                val t = (view.height - s) / 2
                outline.setOval(l, t, l + s, t + s)
            }
        }
        clipToOutline = true
        setPerson("", null)
    }

    fun setPerson(key: String, bmp: Bitmap?, gender: Int = GENDER_AUTO) {
        seed = key.hashCode() and 0x7fffffff
        offsetMs = (mix(seed, 1) % 10000).toLong()
        skin = SKINS[mix(seed, 2) % SKINS.size]
        hair = HAIRS[mix(seed, 3) % HAIRS.size]
        val shirtIdx = mix(seed, 4) % SHIRTS.size
        shirt = SHIRTS[shirtIdx]
        accent = SHIRTS[(shirtIdx + 3) % SHIRTS.size]
        eyeCol = EYES[mix(seed, 14) % EYES.size]
        // styles: 0 side part, 1 top bun, 2 long, 3 curly, 4 pigtails, 5 spiky
        val female = avatarIsFemale(key, gender)
        male = !female
        hairStyle = if (female) intArrayOf(1, 2, 3, 4)[mix(seed, 5) % 4]
        else intArrayOf(0, 5, 3, 0)[mix(seed, 5) % 4]
        lashes = female
        glasses = mix(seed, 8) % 4 == 0
        beard = male && mix(seed, 9) % 3 == 0
        tie = male && mix(seed, 15) % 2 == 0
        bow = female && hairStyle != 1 && hairStyle != 3 && mix(seed, 10) % 2 == 0
        earring = female && mix(seed, 11) % 2 == 0
        freckles = mix(seed, 12) % 5 == 0
        flip = mix(seed, 13) % 2 == 0

        val bg = mix(seed, 6) % BG_A.size
        bgShader = LinearGradient(0f, 0f, 100f, 100f, BG_A[bg], BG_B[bg], Shader.TileMode.CLAMP)
        faceShader = RadialGradient(
            43f, 42f, 38f,
            intArrayOf(tint(skin, 0.3f), skin, shade(skin, 0.86f)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        bodyShader = LinearGradient(
            0f, 76f, 0f, 104f, tint(shirt, 0.24f), shade(shirt, 0.8f), Shader.TileMode.CLAMP
        )
        hairShader = LinearGradient(
            0f, 14f, 0f, 66f, tint(hair, 0.18f), hair, Shader.TileMode.CLAMP
        )

        photo = bmp
        photoShader = if (bmp != null) {
            BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        } else null
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        invalidateOutline()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        AvatarClock.reaction = Prefs.reaction(context)
        if (windowVisibility == VISIBLE) AvatarClock.register(this)
    }

    override fun onDetachedFromWindow() {
        AvatarClock.unregister(this)
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE && isAttachedToWindow) AvatarClock.register(this)
        else AvatarClock.unregister(this)
    }

    override fun onDraw(canvas: Canvas) {
        val s = min(width, height).toFloat()
        if (s <= 0f) return
        canvas.save()
        canvas.translate((width - s) / 2f, (height - s) / 2f)

        val ph = photo
        val sh = photoShader
        if (ph != null && sh != null) {
            matrix.reset()
            val k = s / min(ph.width, ph.height).toFloat()
            matrix.setScale(k, k)
            sh.setLocalMatrix(matrix)
            p.style = Paint.Style.FILL
            p.shader = sh
            canvas.drawCircle(s / 2f, s / 2f, s / 2f, p)
            p.shader = null
        } else {
            canvas.save()
            canvas.scale(s / 100f, s / 100f)
            drawCharacter(canvas)
            canvas.restore()
        }

        if (ring) {
            p.shader = null
            p.style = Paint.Style.STROKE
            p.strokeWidth = s * 0.03f
            p.color = 0xB3FFFFFF.toInt()
            canvas.drawCircle(s / 2f, s / 2f, s / 2f - p.strokeWidth / 2f, p)
        }
        canvas.restore()
    }

    // ------------------------------------------------------------------ character

    private fun fill(c: Int) {
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = c
    }

    private fun stroke(c: Int, w: Float) {
        p.shader = null
        p.style = Paint.Style.STROKE
        p.color = c
        p.strokeWidth = w
    }

    private fun hairPaint() {
        p.style = Paint.Style.FILL
        p.shader = hairShader
        p.color = hair
    }

    private fun sparkle(c: Canvas, x: Float, y: Float, r: Float) {
        val d = r * 0.55f
        c.drawLine(x - r, y, x + r, y, p)
        c.drawLine(x, y - r, x, y + r, p)
        c.drawLine(x - d, y - d, x + d, y + d, p)
        c.drawLine(x - d, y + d, x + d, y - d, p)
    }

    private fun heart(c: Canvas, x: Float, y: Float, s: Float, color: Int) {
        fill(color)
        path.reset()
        path.moveTo(x, y + s * 0.9f)
        path.cubicTo(x - s * 1.5f, y - s * 0.1f, x - s * 0.7f, y - s * 1.2f, x, y - s * 0.4f)
        path.cubicTo(x + s * 0.7f, y - s * 1.2f, x + s * 1.5f, y - s * 0.1f, x, y + s * 0.9f)
        path.close()
        c.drawPath(path, p)
    }

    private fun drawCharacter(c: Canvas) {
        val now = AvatarClock.now
        val period = if (lively) 7000L else 10000L
        val cyc = now + offsetMs
        val phase = (cyc % period).toFloat() / period * 10f
        val cycleIdx = (cyc / period).toInt()
        val ts = (now % 600000L) / 1000f
        val tau = (2.0 * PI).toFloat()

        val react = AvatarClock.reaction
        val calm = still || react == Prefs.REACT_STILL
        val moves = !calm && react == Prefs.REACT_ALL
        val wBrow = if (moves) env(phase, 2.2f, 4.2f) else 0f
        val wLaugh = if (moves) env(phase, 4.4f, 7.0f) else 0f
        val wWave = if (moves) env(phase, 7.2f, 9.2f) else 0f
        val side = if ((cycleIdx + seed) % 2 == 0) -1 else 1 // -1: left brow, 1: right brow

        val blinkT = cyc % 3300L
        val blink = if (!calm && blinkT < 170L) sin(PI * blinkT / 170.0).toFloat() else 0f
        val open = 0.5f + 0.5f * sin(ts * tau * 3.2f)
        val bob = if (calm) 0f else sin(ts * 1.8f) * 0.7f + sin(ts * tau * 3.2f) * 1.1f * wLaugh
        val tilt = if (calm) 0f else -5f * wBrow * side + sin(ts * tau * 1.6f) * 3.5f * wLaugh +
            sin(ts * 0.9f) * 1.2f
        val look = if (calm) 0f else sin(ts * 0.8f) * 0.9f
        val drift = if (calm) 0f else sin(ts * 0.5f + seed) * 2f

        // ---- background with soft bubbles
        p.style = Paint.Style.FILL
        p.shader = bgShader
        c.drawRect(0f, 0f, 100f, 100f, p)
        fill(0x30FFFFFF)
        c.drawCircle(18f + drift, 22f, 14f, p)
        c.drawCircle(86f - drift, 32f, 8f, p)
        c.drawCircle(78f, 86f + drift, 17f, p)

        // ---- sparkles and hearts while laughing
        if (wLaugh > 0.05f) {
            stroke(Color.argb((230 * wLaugh).toInt(), 255, 255, 255), 1.4f)
            val pulse = 0.7f + 0.3f * sin(ts * tau * 2f)
            sparkle(c, 15f, 36f, 4.2f * pulse)
            sparkle(c, 90f, 22f, 3.4f * (1.7f - pulse))
            val hp = (ts * 0.75f) % 1f
            heart(
                c, 85f + sin(ts * 3f) * 2f, 56f - 30f * hp, 3.4f,
                Color.argb((235 * wLaugh * (1f - hp)).toInt(), 255, 92, 128)
            )
            val hq = (ts * 0.75f + 0.5f) % 1f
            heart(
                c, 14f + sin(ts * 3.4f) * 2f, 60f - 30f * hq, 2.7f,
                Color.argb((235 * wLaugh * (1f - hq)).toInt(), 255, 130, 160)
            )
        }

        // ---- long hair sits behind the body
        if (hairStyle == 2) {
            c.save()
            c.translate(0f, bob)
            c.rotate(tilt, 50f, 74f)
            hairPaint()
            rect.set(23f, 26f, 77f, 94f)
            c.drawRoundRect(rect, 25f, 25f, p)
            c.restore()
        }

        // ---- body, neck, neckline
        val bodyY = bob * 0.4f
        c.save()
        c.translate(0f, bodyY)
        p.style = Paint.Style.FILL
        p.shader = bodyShader
        path.reset()
        path.moveTo(10f, 106f)
        path.quadTo(10f, 80f, 36f, 77f)
        path.lineTo(64f, 77f)
        path.quadTo(90f, 80f, 90f, 106f)
        path.close()
        c.drawPath(path, p)

        fill(shade(skin, 0.9f))
        rect.set(43f, 63f, 57f, 83f)
        c.drawRoundRect(rect, 5f, 5f, p)
        path.reset()
        path.moveTo(40.5f, 77.5f)
        path.quadTo(50f, 92f, 59.5f, 77.5f)
        path.close()
        fill(shade(skin, 0.95f))
        c.drawPath(path, p)
        stroke(tint(shirt, 0.38f), 1.3f)
        path.reset()
        path.moveTo(40.5f, 77.5f)
        path.quadTo(50f, 92f, 59.5f, 77.5f)
        c.drawPath(path, p)
        if (male) {
            // shirt collar (and a tie for some)
            val collar = tint(shirt, 0.86f)
            fill(collar)
            path.reset()
            path.moveTo(37.5f, 77f)
            path.lineTo(50f, 92f)
            path.lineTo(46f, 76f)
            path.close()
            c.drawPath(path, p)
            path.reset()
            path.moveTo(62.5f, 77f)
            path.lineTo(50f, 92f)
            path.lineTo(54f, 76f)
            path.close()
            c.drawPath(path, p)
            if (tie) {
                fill(accent)
                rect.set(47.4f, 83f, 52.6f, 87f)
                c.drawRoundRect(rect, 1.5f, 1.5f, p)
                path.reset()
                path.moveTo(47.6f, 87f)
                path.lineTo(52.4f, 87f)
                path.lineTo(54.2f, 100f)
                path.lineTo(50f, 104f)
                path.lineTo(45.8f, 100f)
                path.close()
                c.drawPath(path, p)
            }
        }
        // shadow under the chin
        fill(0x2E000000)
        rect.set(43f, 70f, 57f, 79f)
        c.drawRoundRect(rect, 5f, 5f, p)
        c.restore()

        // ---- head
        c.save()
        c.translate(0f, bob)
        c.rotate(tilt, 50f, 74f)

        // ears (+ earrings)
        fill(shade(skin, 0.95f))
        c.drawCircle(27.5f, 54f, 4.2f, p)
        c.drawCircle(72.5f, 54f, 4.2f, p)
        fill(shade(skin, 0.8f))
        c.drawCircle(27.9f, 54.2f, 2f, p)
        c.drawCircle(72.1f, 54.2f, 2f, p)
        if (earring) {
            fill(0xFFFFC83D.toInt())
            c.drawCircle(27.3f, 60.4f, 1.7f, p)
            c.drawCircle(72.7f, 60.4f, 1.7f, p)
        }

        // hair behind the face
        hairPaint()
        when (hairStyle) {
            0, 2 -> {
                rect.set(25f, 24f, 75f, 70f)
                c.drawArc(rect, 180f, 180f, true, p)
            }
            1 -> {
                c.drawCircle(50f, 20.5f, 9.5f, p)
                rect.set(25f, 24f, 75f, 70f)
                c.drawArc(rect, 180f, 180f, true, p)
                fill(accent)
                rect.set(41.5f, 27f, 58.5f, 31f)
                c.drawRoundRect(rect, 2f, 2f, p)
            }
            3 -> {
                for (i in 0..8) {
                    val a = (PI * (0.95 + 1.1 * i / 8.0)).toFloat()
                    c.drawCircle(50f + 24.5f * cos(a), 52f + 24.5f * sin(a), 8.2f, p)
                }
                c.drawCircle(26f, 57f, 6f, p)
                c.drawCircle(74f, 57f, 6f, p)
            }
            4 -> {
                val sw = if (calm) 0f else sin(ts * 1.6f) * 4f
                c.save()
                c.rotate(sw, 30f, 44f)
                rect.set(16f, 42f, 33f, 78f)
                c.drawRoundRect(rect, 8.5f, 8.5f, p)
                fill(accent)
                c.drawCircle(29.5f, 45f, 3f, p)
                c.restore()
                c.save()
                c.rotate(-sw, 70f, 44f)
                hairPaint()
                rect.set(67f, 42f, 84f, 78f)
                c.drawRoundRect(rect, 8.5f, 8.5f, p)
                fill(accent)
                c.drawCircle(70.5f, 45f, 3f, p)
                c.restore()
                hairPaint()
                rect.set(25f, 24f, 75f, 70f)
                c.drawArc(rect, 180f, 180f, true, p)
            }
            else -> {}
        }

        // face with soft shading
        p.style = Paint.Style.FILL
        p.shader = faceShader
        rect.set(27f, 30f, 73f, 74f)
        c.drawOval(rect, p)

        // cheeks
        fill(Color.argb(((75 + 75 * wLaugh) * (if (male) 0.35f else 1f)).toInt(), 255, 105, 130))
        rect.set(30.5f, 58f, 39.5f, 65f)
        c.drawOval(rect, p)
        rect.set(60.5f, 58f, 69.5f, 65f)
        c.drawOval(rect, p)
        if (freckles) {
            fill(shade(skin, 0.74f))
            for (i in 0..2) {
                c.drawCircle(33.5f + i * 2.4f, 59.4f + (i % 2) * 1.6f, 0.5f, p)
                c.drawCircle(61.5f + i * 2.4f, 59.4f + (i % 2) * 1.6f, 0.5f, p)
            }
        }

        // beard (clipped to the face, with a hole for the mouth)
        if (beard) {
            c.save()
            c.clipPath(facePath)
            fill(shade(hair, 0.95f))
            c.drawPath(beardPath, p)
            c.restore()
        }

        // nose
        stroke(shade(skin, 0.74f), 1.1f)
        path.reset()
        path.moveTo(48.6f, 58f)
        path.quadTo(50f, 59.8f, 51.4f, 58f)
        c.drawPath(path, p)

        // front hair
        hairPaint()
        when (hairStyle) {
            0 -> {
                c.save()
                c.clipPath(facePath)
                if (flip) c.scale(-1f, 1f, 50f, 0f)
                path.reset()
                path.moveTo(20f, 18f)
                path.lineTo(80f, 18f)
                path.lineTo(80f, 46f)
                path.quadTo(58f, 33f, 36f, 40f)
                path.quadTo(27f, 43f, 20f, 50f)
                path.close()
                c.drawPath(path, p)
                c.restore()
            }
            1, 4 -> {
                c.save()
                c.clipPath(facePath)
                path.reset()
                path.moveTo(20f, 18f)
                path.lineTo(80f, 18f)
                path.lineTo(80f, 46f)
                path.quadTo(66f, 37f, 50f, 38.5f)
                path.quadTo(34f, 37f, 20f, 46f)
                path.close()
                c.drawPath(path, p)
                c.restore()
            }
            2 -> {
                c.save()
                c.clipPath(facePath)
                path.reset()
                path.moveTo(20f, 18f)
                path.lineTo(80f, 18f)
                path.lineTo(80f, 56f)
                path.quadTo(68f, 36f, 50f, 36f)
                path.quadTo(32f, 36f, 20f, 56f)
                path.close()
                c.drawPath(path, p)
                c.restore()
            }
            3 -> {
                c.drawCircle(38f, 35f, 6.8f, p)
                c.drawCircle(46f, 32f, 7.2f, p)
                c.drawCircle(54f, 32f, 7.2f, p)
                c.drawCircle(62f, 35f, 6.8f, p)
            }
            else -> {
                path.reset()
                path.moveTo(22f, 40f)
                path.lineTo(25f, 24f)
                path.lineTo(33f, 33f)
                path.lineTo(39f, 17f)
                path.lineTo(46f, 31f)
                path.lineTo(53f, 15f)
                path.lineTo(60f, 31f)
                path.lineTo(67f, 19f)
                path.lineTo(72f, 34f)
                path.lineTo(78f, 40f)
                path.quadTo(64f, 35f, 50f, 38f)
                path.quadTo(36f, 35f, 22f, 40f)
                path.close()
                c.drawPath(path, p)
            }
        }
        // glossy highlight on the hair
        stroke(0x66FFFFFF, 1.7f)
        path.reset()
        path.moveTo(33f, 33f)
        path.quadTo(42f, 27.5f, 52f, 28.5f)
        c.drawPath(path, p)

        // ---- eyes
        val eyeY = 54f
        val dark = 0xFF2B2230.toInt()
        if (wLaugh > 0.5f) {
            stroke(dark, 2.1f)
            path.reset()
            path.moveTo(36.3f, 55.6f)
            path.quadTo(40.5f, 49.2f, 44.7f, 55.6f)
            path.moveTo(55.3f, 55.6f)
            path.quadTo(59.5f, 49.2f, 63.7f, 55.6f)
            c.drawPath(path, p)
        } else {
            for (sd in intArrayOf(-1, 1)) {
                val ex = if (sd < 0) 40.5f else 59.5f
                val rx = 4.5f
                val ry = 5.2f
                // eye white
                fill(0xFFFFFFFF.toInt())
                rect.set(ex - rx, eyeY - ry, ex + rx, eyeY + ry)
                c.drawOval(rect, p)
                // iris, pupil and shine
                val ix = ex + look * 0.9f
                fill(eyeCol)
                c.drawCircle(ix, eyeY + 0.3f, 3.5f, p)
                fill(shade(eyeCol, 0.5f))
                c.drawCircle(ix, eyeY + 0.3f, 1.9f, p)
                fill(Color.WHITE)
                c.drawCircle(ix - 1.2f, eyeY - 1.3f, 1.25f, p)
                c.drawCircle(ix + 1.2f, eyeY + 1.5f, 0.65f, p)
                // eyelid that sweeps down when blinking
                var lid = 0f
                if (blink > 0.02f) {
                    lid = 2f * ry * blink
                    c.save()
                    path2.reset()
                    path2.addOval(rect, Path.Direction.CW)
                    c.clipPath(path2)
                    fill(skin)
                    c.drawRect(ex - rx - 1f, eyeY - ry - 1f, ex + rx + 1f, eyeY - ry + lid, p)
                    c.restore()
                }
                // upper lash line
                stroke(dark, if (lashes) 1.8f else 1.5f)
                rect.set(ex - rx - 0.2f, eyeY - ry + lid * 0.9f, ex + rx + 0.2f, eyeY + ry)
                c.drawArc(rect, 192f, 156f, false, p)
                if (lashes) {
                    val o = if (sd < 0) -1f else 1f
                    stroke(dark, 1.2f)
                    c.drawLine(ex + o * 4.5f, eyeY - 2.4f + lid * 0.4f, ex + o * 6.4f, eyeY - 3.8f + lid * 0.4f, p)
                    c.drawLine(ex + o * 4.7f, eyeY - 0.4f, ex + o * 6.6f, eyeY - 0.7f, p)
                }
            }
        }

        // glasses
        if (glasses) {
            fill(0x22FFFFFF)
            c.drawCircle(40.5f, eyeY, 6.7f, p)
            c.drawCircle(59.5f, eyeY, 6.7f, p)
            stroke(0xFF303652.toInt(), 1.4f)
            c.drawCircle(40.5f, eyeY, 6.7f, p)
            c.drawCircle(59.5f, eyeY, 6.7f, p)
            c.drawLine(47.2f, eyeY - 0.8f, 52.8f, eyeY - 0.8f, p)
            c.drawLine(33.8f, eyeY - 0.5f, 28.5f, eyeY - 1.5f, p)
            c.drawLine(66.2f, eyeY - 0.5f, 71.5f, eyeY - 1.5f, p)
            stroke(0x80FFFFFF.toInt(), 1.1f)
            c.drawLine(36.4f, eyeY - 3.8f, 38.6f, eyeY - 5.2f, p)
            c.drawLine(55.4f, eyeY - 3.8f, 57.6f, eyeY - 5.2f, p)
        }

        // ---- eyebrows (one of them goes up and tilts)
        val browBase = 45.8f - 1.5f * wLaugh - (if (glasses) 1.2f else 0f)
        for (sd in intArrayOf(-1, 1)) {
            val cx = if (sd < 0) 40.5f else 59.5f
            val raised = if (sd == side) wBrow else 0f
            val other = if (sd == side) 0f else wBrow
            val by2 = browBase - 3.4f * raised + 1.2f * other
            val ang = (if (sd < 0) 1f else -1f) * (14f * raised - 6f * other)
            c.save()
            c.rotate(ang, cx, by2)
            stroke(shade(hair, 0.85f), if (lashes) 1.6f else 2.1f)
            path.reset()
            path.moveTo(cx - 4.9f, by2 + 1f)
            path.quadTo(cx, by2 - 1.9f - 1.4f * raised, cx + 4.9f, by2 + 1f)
            c.drawPath(path, p)
            c.restore()
        }

        // ---- mouth
        if (wLaugh < 0.08f) {
            fill(0xFFC8465F.toInt())
            path.reset()
            path.moveTo(44.6f, 62.4f)
            path.quadTo(50f, 69.4f, 55.4f, 62.4f)
            path.quadTo(50f, 65.4f, 44.6f, 62.4f)
            path.close()
            c.drawPath(path, p)
        } else {
            val dd = (2f + (4f + 9f * open) * wLaugh)
            path.reset()
            path.moveTo(43.2f, 61.5f)
            path.lineTo(56.8f, 61.5f)
            path.cubicTo(56.2f, 61.5f + dd, 43.8f, 61.5f + dd, 43.2f, 61.5f)
            path.close()
            fill(0xFF5A1B2B.toInt())
            c.drawPath(path, p)
            c.save()
            c.clipPath(path)
            fill(0xFFFF7A93.toInt())
            c.drawCircle(50f, 61.5f + dd * 0.8f, 5.2f, p)
            fill(Color.WHITE)
            c.drawRect(44f, 60.8f, 56f, 63.8f, p)
            c.restore()
        }

        // ---- bow
        if (bow) {
            c.save()
            c.rotate(-12f, 66f, 32f)
            fill(accent)
            path.reset()
            path.moveTo(66f, 32f)
            path.lineTo(58f, 27.5f)
            path.lineTo(58f, 36.5f)
            path.close()
            path.moveTo(66f, 32f)
            path.lineTo(74f, 27.5f)
            path.lineTo(74f, 36.5f)
            path.close()
            c.drawPath(path, p)
            fill(shade(accent, 0.82f))
            c.drawCircle(66f, 32f, 2.5f, p)
            c.restore()
        }
        c.restore() // head

        // ---- arms & hands (appear from below while clapping / waving)
        val wHand = max(wLaugh, wWave)
        if (wHand > 0.02f) {
            val clap = 0.5f + 0.5f * sin(ts * tau * 3.2f + 1.2f)
            val sleeve = shade(shirt, 0.85f)
            val shL = floatArrayOf(30f, 94f)
            val shR = floatArrayOf(70f, 94f)

            // left hand: only claps
            val lx = lerp(18f, 41f + 4f * clap, wLaugh)
            val ly = lerp(114f, 82f, wLaugh)
            // right hand: claps or waves
            val mixW = wWave / (wWave + wLaugh + 0.0001f)
            val txClap = 59f - 4f * clap
            val txWave = 80f + 6f * sin(ts * tau * 2.2f)
            val tyWave = 66f + 1.6f * sin(ts * tau * 4.4f)
            val tx = lerp(txClap, txWave, mixW)
            val ty = lerp(82f, tyWave, mixW)
            val hx = lerp(82f, tx, wHand)
            val hy = lerp(114f, ty, wHand)

            if (wLaugh > 0.02f) {
                stroke(sleeve, 8f)
                c.drawLine(shL[0], shL[1], lx, ly, p)
                fill(skin)
                c.drawCircle(lx, ly, 5.4f, p)
                fill(0x40FFFFFF)
                c.drawCircle(lx - 1.5f, ly - 1.6f, 1.8f, p)
            }
            stroke(sleeve, 8f)
            c.drawLine(shR[0], shR[1], hx, hy, p)
            fill(skin)
            c.drawCircle(hx, hy, 5.4f, p)
            fill(0x40FFFFFF)
            c.drawCircle(hx - 1.5f, hy - 1.6f, 1.8f, p)
        }
        p.shader = null
    }
}

/** Renders the avatar (photo or cartoon) into a round bitmap, e.g. for notifications. */
object AvatarBitmap {
    fun make(ctx: Context, key: String, photo: Bitmap?, size: Int, gender: Int = GENDER_AUTO): Bitmap {
        val v = AvatarView(ctx)
        v.still = true
        v.setPerson(key, photo, gender)
        v.measure(
            View.MeasureSpec.makeMeasureSpec(size, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(size, View.MeasureSpec.EXACTLY)
        )
        v.layout(0, 0, size, size)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val clip = Path()
        clip.addCircle(size / 2f, size / 2f, size / 2f, Path.Direction.CW)
        c.clipPath(clip)
        v.draw(c)
        return bmp
    }
}
