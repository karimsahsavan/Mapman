package com.shik.dialer

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/**
 * Plays the incoming-call ringtone and vibration. A default dialer must do this itself,
 * the system does not ring for it.
 */
object Ringer {

    private var ringtone: Ringtone? = null
    private var vibrator: Vibrator? = null
    private var playing = false

    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
        .build()

    @Synchronized
    fun start(ctx: Context) {
        if (playing) return
        playing = true
        val app = ctx.applicationContext
        val am = app.getSystemService(AudioManager::class.java)
        val mode = am?.ringerMode ?: AudioManager.RINGER_MODE_NORMAL
        if (mode == AudioManager.RINGER_MODE_NORMAL) playSound(app)
        if (mode != AudioManager.RINGER_MODE_SILENT && Prefs.vibrate(app)) vibrate(app)
    }

    @Synchronized
    fun stop() {
        playing = false
        try {
            ringtone?.stop()
        } catch (e: Exception) {
        }
        ringtone = null
        try {
            vibrator?.cancel()
        } catch (e: Exception) {
        }
        vibrator = null
    }

    private fun open(ctx: Context, uri: Uri): Ringtone? {
        return try {
            val r = RingtoneManager.getRingtone(ctx, uri) ?: return null
            r.setAudioAttributes(attrs)
            r.isLooping = true
            r.play()
            if (r.isPlaying) r else {
                r.stop()
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun playSound(ctx: Context) {
        val pref = Prefs.ringtone(ctx)
        if (pref == Prefs.RING_SILENT) return
        var r: Ringtone? = null
        if (pref.isNotEmpty()) {
            r = open(ctx, Uri.parse(pref))
        }
        if (r == null) {
            // custom file unreadable (or none chosen) -> system default
            r = open(ctx, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE))
        }
        ringtone = r
    }

    @Suppress("DEPRECATION")
    private fun vibrate(ctx: Context) {
        try {
            val v: Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
                ctx.getSystemService(VibratorManager::class.java)?.defaultVibrator
            } else {
                ctx.getSystemService(Vibrator::class.java)
            }
            if (v == null || !v.hasVibrator()) return
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 900, 900), 0), attrs)
            vibrator = v
        } catch (e: Exception) {
        }
    }
}
