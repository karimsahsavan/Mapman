package com.shik.dialer

import android.annotation.SuppressLint
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator

object Anim {
    /**
     * Smooth, physical press: the button sinks in quickly and slightly dims while the finger is
     * down, then rises back with a soft spring. The click itself is never delayed.
     */
    @SuppressLint("ClickableViewAccessibility")
    fun press(v: View, scale: Float = 0.9f) {
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(scale).scaleY(scale).alpha(0.86f)
                        .setDuration(70)
                        .setInterpolator(DecelerateInterpolator(1.4f))
                        .start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).alpha(1f)
                        .setDuration(260)
                        .setInterpolator(OvershootInterpolator(1.8f))
                        .start()
            }
            false
        }
    }
}
