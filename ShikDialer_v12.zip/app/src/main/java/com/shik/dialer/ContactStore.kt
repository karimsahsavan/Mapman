package com.shik.dialer

import android.accounts.AccountManager
import android.content.ContentProviderOperation
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.ContactsContract
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager

/**
 * Where a new contact is stored. Contacts without an account live only in the phone
 * memory and are lost on reset / format, so the default is the Google account (cloud),
 * and the SIM card can be ticked as well.
 */
object ContactStore {

    class Dest(
        val id: String,
        val title: String,
        val sub: String,
        val color: Int,
        val type: String?,
        val name: String?,
        val sim: Boolean
    )

    private const val PREF = "shik_prefs"
    private const val KEY = "save_dests"

    private fun isSimType(t: String?) = t != null && (t.lowercase().contains("sim") || t.lowercase().contains("icc"))
    private fun isLocalType(t: String?): Boolean {
        if (t.isNullOrEmpty()) return true
        val l = t.lowercase()
        return l.contains("local") || l == "vnd.sec.contact.phone" || l.endsWith(".phone")
    }

    /** Every (type, name) account the contacts database knows about. */
    private fun allAccounts(ctx: Context): LinkedHashSet<Pair<String, String>> {
        val out = LinkedHashSet<Pair<String, String>>()
        try {
            for (a in AccountManager.get(ctx).accounts) {
                if (a.type == "com.google") out.add(a.type to a.name)
            }
        } catch (e: Exception) {
        }
        fun scan(uri: Uri) {
            try {
                ctx.contentResolver.query(
                    uri, arrayOf("account_type", "account_name"), null, null, null
                )?.use { c ->
                    while (c.moveToNext()) {
                        val t = c.getString(0) ?: continue
                        val n = c.getString(1) ?: continue
                        out.add(t to n)
                    }
                }
            } catch (e: Exception) {
            }
        }
        scan(ContactsContract.Settings.CONTENT_URI)
        scan(ContactsContract.RawContacts.CONTENT_URI.buildUpon()
            .appendQueryParameter("distinct", "1").build())
        return out
    }

    private fun simAvailable(ctx: Context): Boolean {
        try {
            val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            if (tm.simState == TelephonyManager.SIM_STATE_READY) return true
        } catch (e: Exception) {
        }
        return allAccounts(ctx).any { isSimType(it.first) }
    }

    fun destinations(ctx: Context): List<Dest> {
        val out = ArrayList<Dest>()
        val seen = HashSet<String>()
        for ((t, n) in allAccounts(ctx)) {
            if (isSimType(t) || isLocalType(t)) continue
            if (!seen.add("$t|$n")) continue
            val google = t == "com.google"
            out.add(
                Dest(
                    "acc:$t|$n",
                    (if (google) "Google" else t.substringAfterLast('.')) + " • " + n,
                    ctx.getString(R.string.dest_cloud_sub),
                    if (google) 0xFF2F80ED.toInt() else 0xFF8E5CF7.toInt(),
                    t, n, false
                )
            )
        }
        if (simAvailable(ctx)) {
            out.add(
                Dest("sim", ctx.getString(R.string.dest_sim), ctx.getString(R.string.dest_sim_sub),
                    0xFF1FC46A.toInt(), null, null, true)
            )
        }
        out.add(
            Dest("local", ctx.getString(R.string.dest_local), ctx.getString(R.string.dest_local_sub),
                0xFFFF8F3F.toInt(), null, null, false)
        )
        return out
    }

    /** Remembered choice; first time: Google account, else SIM, else phone. */
    fun selectedIds(ctx: Context, dests: List<Dest>): LinkedHashSet<String> {
        val saved = ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY, null)
        val ids = LinkedHashSet<String>()
        saved?.split("\n")?.forEach { id -> if (dests.any { it.id == id }) ids.add(id) }
        if (ids.isEmpty()) {
            val first = dests.firstOrNull { it.type != null } ?: dests.firstOrNull { it.sim }
                ?: dests.last()
            ids.add(first.id)
        }
        return ids
    }

    fun saveSelection(ctx: Context, ids: Set<String>) {
        ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString(KEY, ids.joinToString("\n")).apply()
    }

    fun selected(ctx: Context): List<Dest> {
        val all = destinations(ctx)
        val ids = selectedIds(ctx, all)
        return all.filter { it.id in ids }
    }

    // ---------------------------------------------------------------- writing

    private fun insertRaw(ctx: Context, name: String, num: String, type: String?, acc: String?): Boolean {
        return try {
            val ops = ArrayList<ContentProviderOperation>()
            ops.add(
                ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                    .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, type)
                    .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, acc)
                    .build()
            )
            ops.add(
                ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(
                        ContactsContract.Data.MIMETYPE,
                        ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE
                    )
                    .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, name)
                    .build()
            )
            ops.add(
                ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(
                        ContactsContract.Data.MIMETYPE,
                        ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE
                    )
                    .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, num)
                    .withValue(
                        ContactsContract.CommonDataKinds.Phone.TYPE,
                        ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE
                    )
                    .build()
            )
            ctx.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun shortTag(n: String): String {
        val ascii = n.all { it.code < 128 }
        return n.take(if (ascii) 14 else 6)
    }

    private fun simInsert(ctx: Context, name: String, num: String): Boolean {
        val uris = ArrayList<Uri>()
        uris.add(Uri.parse("content://icc/adn"))
        try {
            val sm = ctx.getSystemService(SubscriptionManager::class.java)
            sm?.activeSubscriptionInfoList?.forEach {
                uris.add(Uri.parse("content://icc/adn/subId/" + it.subscriptionId))
            }
        } catch (e: Exception) {
        }
        for (u in uris) {
            for (tag in listOf(name, shortTag(name)).distinct()) {
                try {
                    val v = ContentValues()
                    v.put("tag", tag)
                    v.put("number", num)
                    if (ctx.contentResolver.insert(u, v) != null) return true
                } catch (e: Exception) {
                }
            }
        }
        // some phones (Samsung ...) store SIM contacts as a raw contact of a SIM account
        for ((t, n) in allAccounts(ctx)) {
            if (isSimType(t) && insertRaw(ctx, name, num, t, n)) return true
        }
        return false
    }

    /** Saves to every chosen place. Returns the titles that worked and the ones that failed. */
    fun save(ctx: Context, name: String, num: String, dests: List<Dest>): Pair<List<String>, List<String>> {
        val ok = ArrayList<String>()
        val bad = ArrayList<String>()
        for (d in dests) {
            val done = if (d.sim) simInsert(ctx, name, num) else insertRaw(ctx, name, num, d.type, d.name)
            (if (done) ok else bad).add(if (d.type != null) d.title.substringBefore(" •") else d.title)
        }
        return ok to bad
    }
}
