package com.shik.dialer

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class EntryAdapter(
    private val onClick: (Entry) -> Unit,
    private val onAvatar: (Entry) -> Unit,
    private val onMenu: (Entry) -> Unit,
    private val large: Boolean = false,
    private val recents: Boolean = false,
    private val onInfo: ((Entry) -> Unit)? = null
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    /** Coloured day bar shown above the calls of one day (Recents only). */
    private class Head(val ms: Long, val count: Int)

    private var rows: List<Any> = emptyList()

    fun submit(list: List<Entry>) {
        if (!recents) {
            rows = list
        } else {
            val out = ArrayList<Any>(list.size + 16)
            var i = 0
            while (i < list.size) {
                val key = FaFormat.dayKey(list[i].date)
                var j = i
                while (j < list.size && FaFormat.dayKey(list[j].date) == key) j++
                out.add(Head(list[i].date, j - i))
                for (k in i until j) out.add(list[k])
                i = j
            }
            rows = out
        }
        notifyDataSetChanged()
    }

    /** Null for day bars, so they can't be swiped. */
    fun itemAt(pos: Int): Entry? = rows.getOrNull(pos) as? Entry

    /** Re-binds every row (used after a contact photo changes). */
    fun refresh() {
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val avatar: AvatarView = v.findViewById(R.id.avatar)
        val title: TextView = v.findViewById(R.id.title)
        val subtitle: TextView = v.findViewById(R.id.subtitle)
        val typeIcon: ImageView? = v.findViewById(R.id.typeIcon)
        val time: TextView? = v.findViewById(R.id.time)
        val dateText: TextView? = v.findViewById(R.id.dateText)
        val info: ImageButton? = v.findViewById(R.id.btnInfo)
        val stripe: View? = v.findViewById(R.id.dayStripe)
    }

    class HeadVH(v: View) : RecyclerView.ViewHolder(v) {
        val bar: View = v.findViewById(R.id.dayBar)
        val title: TextView = v.findViewById(R.id.dayTitle)
        val sub: TextView = v.findViewById(R.id.daySub)
        val count: TextView = v.findViewById(R.id.dayCount)
    }

    override fun getItemViewType(position: Int): Int = if (rows[position] is Head) 1 else 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inf = LayoutInflater.from(parent.context)
        if (viewType == 1) return HeadVH(inf.inflate(R.layout.item_day_header, parent, false))
        val layout = when {
            recents -> R.layout.item_recent
            large -> R.layout.item_entry_large
            else -> R.layout.item_entry
        }
        return VH(inf.inflate(layout, parent, false))
    }

    override fun getItemCount(): Int = rows.size

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val row = rows[position]
        if (holder is HeadVH && row is Head) {
            bindHead(holder, row)
            return
        }
        if (holder is VH && row is Entry) bindEntry(holder, row)
    }

    private fun bindHead(h: HeadVH, r: Head) {
        val ctx = h.itemView.context
        val d = ctx.resources.displayMetrics.density
        val color = FaFormat.dayColor(r.ms)
        h.itemView.background = GradientDrawable().apply {
            cornerRadius = 16f * d
            setColor(Color.argb(0x24, Color.red(color), Color.green(color), Color.blue(color)))
        }
        h.bar.background = GradientDrawable().apply {
            cornerRadius = 3f * d
            setColor(color)
        }
        h.title.text = FaFormat.dayTitle(ctx, r.ms)
        h.title.setTextColor(color)
        h.sub.text = FaFormat.daySub(r.ms)
        h.count.text = FaFormat.digits(r.count.toString()) + " " + ctx.getString(R.string.calls_unit)
        h.count.background = GradientDrawable().apply {
            cornerRadius = 12f * d
            setColor(color)
        }
    }

    private fun bindEntry(holder: VH, e: Entry) {
        val ctx = holder.itemView.context
        val d = ctx.resources.displayMetrics.density
        val key = PhotoStore.key(e.number).ifEmpty { e.title }
        holder.avatar.setPerson(key, PhotoStore.get(ctx, e.number), Genders.get(ctx, e.number))
        holder.avatar.setOnClickListener { onAvatar(e) }
        holder.title.text = e.title
        holder.title.setTextColor(if (e.missed) 0xFFF0524A.toInt() else 0xFF14161C.toInt())

        if (recents) {
            val color = FaFormat.typeColor(e)
            holder.subtitle.text = FaFormat.summary(ctx, e)
            holder.subtitle.setTextColor(if (e.missed) color else 0xFF6B7280.toInt())
            holder.typeIcon?.setImageResource(FaFormat.typeIcon(e))
            holder.typeIcon?.imageTintList = ColorStateList.valueOf(color)
            holder.time?.text = FaFormat.time(e.date)
            // the day is shown by the coloured bar above, so the row only needs the time
            holder.dateText?.visibility = View.GONE
            holder.stripe?.background = GradientDrawable().apply {
                cornerRadius = 3f * d
                setColor(FaFormat.dayColor(e.date))
            }
            holder.info?.let { b ->
                Anim.press(b, 0.85f)
                b.setOnClickListener { onInfo?.invoke(e) }
            }
        } else {
            holder.subtitle.text = e.subtitle
        }

        Anim.press(holder.itemView, 0.97f)
        holder.itemView.setOnClickListener { onClick(e) }
        holder.itemView.setOnLongClickListener {
            onMenu(e)
            true
        }
    }
}
