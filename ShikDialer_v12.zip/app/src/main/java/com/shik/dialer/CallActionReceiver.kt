package com.shik.dialer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telecom.Call
import android.telecom.VideoProfile

class CallActionReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_DECLINE = "com.shik.dialer.ACTION_DECLINE"
        const val ACTION_HANGUP = "com.shik.dialer.ACTION_HANGUP"
        const val ACTION_ANSWER = "com.shik.dialer.ACTION_ANSWER"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val call = CallManager.primary ?: return
        when (intent.action) {
            ACTION_ANSWER ->
                if (call.state == Call.STATE_RINGING) call.answer(VideoProfile.STATE_AUDIO_ONLY)
            ACTION_DECLINE ->
                if (call.state == Call.STATE_RINGING) call.reject(false, null) else call.disconnect()
            ACTION_HANGUP -> call.disconnect()
        }
    }
}
