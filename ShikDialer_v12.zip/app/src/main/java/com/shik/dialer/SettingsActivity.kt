package com.shik.dialer

import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    private lateinit var rows: LinearLayout
    private val refreshers = ArrayList<() -> Unit>()

    private val pickSystemRingtone =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == RESULT_OK) {
                @Suppress("DEPRECATION")
                val uri: Uri? = r.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
                if (uri == null) {
                    Prefs.setRingtone(this, Prefs.RING_SILENT, "")
                } else if (uri == RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)) {
                    Prefs.setRingtone(this, Prefs.RING_DEFAULT, "")
                } else {
                    val title = try {
                        RingtoneManager.getRingtone(this, uri)?.getTitle(this)
                    } catch (e: Exception) {
                        null
                    }
                    Prefs.setRingtone(this, uri.toString(), title ?: "")
                }
                refreshAll()
            }
        }

    private val pickAudioFile =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (e: Exception) {
                }
                Prefs.setRingtone(this, uri.toString(), displayName(uri))
                refreshAll()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        rows = findViewById(R.id.rows)
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }

        // ---- ringtone
        addRow(R.string.set_ringtone, { ringtoneLabel() }) {
            choose(
                R.string.set_ringtone,
                arrayOf(
                    getString(R.string.ring_default),
                    getString(R.string.ring_pick_system),
                    getString(R.string.ring_pick_file),
                    getString(R.string.ring_silent)
                ),
                -1
            ) { which ->
                when (which) {
                    0 -> {
                        Prefs.setRingtone(this, Prefs.RING_DEFAULT, "")
                        refreshAll()
                    }
                    1 -> openSystemPicker()
                    2 -> try {
                        pickAudioFile.launch(arrayOf("audio/*"))
                    } catch (e: Exception) {
                    }
                    else -> {
                        Prefs.setRingtone(this, Prefs.RING_SILENT, "")
                        refreshAll()
                    }
                }
            }
        }

        // ---- vibration
        addRow(
            R.string.set_vibrate,
            { getString(if (Prefs.vibrate(this)) R.string.on else R.string.off) }
        ) {
            Prefs.setVibrate(this, !Prefs.vibrate(this))
            refreshAll()
        }

        // ---- call-screen animation (shows a live preview after choosing)
        val animLabels = arrayOf(
            getString(R.string.anim_galaxy),
            getString(R.string.anim_neon),
            getString(R.string.anim_soft),
            getString(R.string.anim_off)
        )
        addRow(R.string.set_call_anim, { animLabels[Prefs.callAnim(this).coerceIn(0, 3)] }) {
            choose(R.string.set_call_anim, animLabels, Prefs.callAnim(this)) { which ->
                Prefs.setCallAnim(this, which)
                refreshAll()
                startActivity(
                    Intent(this, InCallActivity::class.java).putExtra("preview", true)
                )
            }
        }

        // ---- cartoon reaction
        val reactLabels = arrayOf(
            getString(R.string.react_all),
            getString(R.string.react_blink),
            getString(R.string.react_still)
        )
        addRow(R.string.set_reaction, { reactLabels[Prefs.reaction(this).coerceIn(0, 2)] }) {
            choose(R.string.set_reaction, reactLabels, Prefs.reaction(this)) { which ->
                Prefs.setReaction(this, which)
                refreshAll()
            }
        }

        // ---- swipe actions
        val swLabels = arrayOf(
            getString(R.string.sw_call),
            getString(R.string.sw_sms),
            getString(R.string.sw_delete),
            getString(R.string.sw_none)
        )
        addRow(R.string.set_swipe_right, { swLabels[Prefs.swipeRight(this).coerceIn(0, 3)] }) {
            choose(R.string.set_swipe_right, swLabels, Prefs.swipeRight(this)) { which ->
                Prefs.setSwipeRight(this, which)
                refreshAll()
            }
        }
        addRow(R.string.set_swipe_left, { swLabels[Prefs.swipeLeft(this).coerceIn(0, 3)] }) {
            choose(R.string.set_swipe_left, swLabels, Prefs.swipeLeft(this)) { which ->
                Prefs.setSwipeLeft(this, which)
                refreshAll()
            }
        }
    }

    private fun addRow(title: Int, value: () -> String, onClick: () -> Unit) {
        val v = layoutInflater.inflate(R.layout.item_setting, rows, false)
        v.findViewById<TextView>(R.id.setTitle).setText(title)
        val tv = v.findViewById<TextView>(R.id.setValue)
        tv.text = value()
        Anim.press(v, 0.97f)
        v.setOnClickListener { onClick() }
        rows.addView(v)
        refreshers.add { tv.text = value() }
    }

    private fun refreshAll() {
        for (r in refreshers) r()
    }

    private fun choose(title: Int, items: Array<String>, current: Int, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setSingleChoiceItems(items, current) { dlg, which ->
                dlg.dismiss()
                onPick(which)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun ringtoneLabel(): String {
        return when (val pref = Prefs.ringtone(this)) {
            Prefs.RING_DEFAULT -> getString(R.string.ring_default)
            Prefs.RING_SILENT -> getString(R.string.ring_silent)
            else -> {
                if (pref.isNotEmpty() && Prefs.ringtoneName(this).isNotEmpty())
                    Prefs.ringtoneName(this)
                else getString(R.string.ring_custom)
            }
        }
    }

    private fun openSystemPicker() {
        try {
            val cur = Prefs.ringtone(this)
            val existing: Uri = if (cur.isNotEmpty() && cur != Prefs.RING_SILENT) Uri.parse(cur)
            else RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_RINGTONE)
                .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
                .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                .putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, getString(R.string.set_ringtone))
                .putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, existing)
            pickSystemRingtone.launch(i)
        } catch (e: Exception) {
        }
    }

    private fun displayName(uri: Uri): String {
        return try {
            contentResolver.query(
                uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null
            )?.use { c -> if (c.moveToFirst()) c.getString(0) else null } ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
    }
}
