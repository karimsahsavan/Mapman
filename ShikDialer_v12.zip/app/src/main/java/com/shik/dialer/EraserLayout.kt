package com.shik.dialer

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout

/**
 * Hosts the app pages. erase() rubs the old page out with a soft, feathered edge (like an
 * eraser) so the page underneath slowly shows through.
 */
class EraserLayout @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) :
    FrameLayout(ctx, attrs) {

    private var erasing: View? = null
    private var progress = 0f
    private var dir = 1f
    private var anim: ValueAnimator? = null
    private val mask = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
    }

    fun erase(from: View, direction: Float, duration: Long, onEnd: () -> Unit) {
        cancelErase()
        erasing = from
        dir = direction
        progress = 0f
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = duration
        a.interpolator = AccelerateDecelerateInterpolator()
        a.addUpdateListener {
            progress = it.animatedValue as Float
            invalidate()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: Animator) { cancelled = true }
            override fun onAnimationEnd(animation: Animator) {
                if (cancelled) return
                erasing = null
                progress = 0f
                anim = null
                invalidate()
                onEnd()
            }
        })
        anim = a
        a.start()
    }

    fun cancelErase() {
        anim?.cancel()
        anim = null
        erasing = null
        progress = 0f
    }

    override fun drawChild(canvas: Canvas, child: View, drawingTime: Long): Boolean {
        if (child !== erasing || progress <= 0f) return super.drawChild(canvas, child, drawingTime)
        val w = width.toFloat()
        val h = height.toFloat()
        val feather = w * 0.35f
        val edge = progress * (w + feather)
        val layer = canvas.saveLayer(0f, 0f, w, h, null)
        val r = super.drawChild(canvas, child, drawingTime)
        mask.shader = if (dir > 0f) {
            // erased area grows from the left edge towards the right
            LinearGradient(edge - feather, 0f, edge, 0f, Color.BLACK, Color.TRANSPARENT, Shader.TileMode.CLAMP)
        } else {
            LinearGradient(w - edge, 0f, w - edge + feather, 0f, Color.TRANSPARENT, Color.BLACK, Shader.TileMode.CLAMP)
        }
        canvas.drawRect(0f, 0f, w, h, mask)
        canvas.restoreToCount(layer)
        return r
    }
}
