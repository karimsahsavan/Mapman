package com.shik.dialer

import android.content.Context
import android.content.SharedPreferences

/** All user settings in one place (stored in SharedPreferences). */
object Prefs {

    // swipe actions
    const val SW_CALL = 0
    const val SW_SMS = 1
    const val SW_DELETE = 2
    const val SW_NONE = 3

    // tap on a contact / recent row
    const val TAP_DIALER = 0
    const val TAP_CALL = 1

    // call-screen animation styles
    const val ANIM_GALAXY = 0
    const val ANIM_NEON = 1
    const val ANIM_SOFT = 2
    const val ANIM_OFF = 3

    // contact cartoon reactions
    const val REACT_ALL = 0
    const val REACT_BLINK = 1
    const val REACT_STILL = 2

    const val RING_DEFAULT = ""
    const val RING_SILENT = "silent"

    @Volatile
    private var sp: SharedPreferences? = null

    private fun s(c: Context): SharedPreferences {
        val cur = sp
        if (cur != null) return cur
        val n = c.applicationContext.getSharedPreferences("shik_prefs", Context.MODE_PRIVATE)
        sp = n
        return n
    }

    /** "" = system default, "silent" = no sound, otherwise a content/file uri string. */
    fun ringtone(c: Context): String = s(c).getString("ringtone", RING_DEFAULT) ?: RING_DEFAULT

    fun ringtoneName(c: Context): String = s(c).getString("ringtone_name", "") ?: ""

    fun setRingtone(c: Context, value: String, name: String) {
        s(c).edit().putString("ringtone", value).putString("ringtone_name", name).apply()
    }

    fun vibrate(c: Context): Boolean = s(c).getBoolean("vibrate", true)

    fun setVibrate(c: Context, v: Boolean) {
        s(c).edit().putBoolean("vibrate", v).apply()
    }

    fun callAnim(c: Context): Int = s(c).getInt("call_anim", ANIM_GALAXY)

    fun setCallAnim(c: Context, v: Int) {
        s(c).edit().putInt("call_anim", v).apply()
    }

    fun reaction(c: Context): Int = s(c).getInt("reaction", REACT_ALL)

    fun setReaction(c: Context, v: Int) {
        s(c).edit().putInt("reaction", v).apply()
        AvatarClock.reaction = v
    }

    fun swipeRight(c: Context): Int = s(c).getInt("swipe_right", SW_CALL)

    fun setSwipeRight(c: Context, v: Int) {
        s(c).edit().putInt("swipe_right", v).apply()
    }

    fun swipeLeft(c: Context): Int = s(c).getInt("swipe_left", SW_SMS)

    fun setSwipeLeft(c: Context, v: Int) {
        s(c).edit().putInt("swipe_left", v).apply()
    }

    /** What a tap on a row does: put the number on the dial pad (default) or call at once. */
    fun rowTap(c: Context): Int = s(c).getInt("row_tap", TAP_DIALER)

    fun setRowTap(c: Context, v: Int) {
        s(c).edit().putInt("row_tap", v).apply()
    }
}
