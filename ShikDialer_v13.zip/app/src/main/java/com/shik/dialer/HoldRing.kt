package com.shik.dialer

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator

/** A ring that fills clockwise around the call button while it is being held. */
class HoldRing @JvmOverloads constructor(
    ctx: Context,
    attrs: AttributeSet? = null
) : View(ctx, attrs) {

    var color: Int = 0xFF2F80ED.toInt()

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val box = RectF()
    private var progress = 0f
    private var anim: ValueAnimator? = null

    fun start(ms: Long) {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = ms
            interpolator = LinearInterpolator()
            addUpdateListener {
                progress = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun cancel() {
        anim?.cancel()
        anim = null
        progress = 0f
        invalidate()
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        if (progress <= 0f) return
        val w = 5f * resources.displayMetrics.density
        paint.strokeWidth = w
        paint.color = color
        box.set(w / 2f, w / 2f, width - w / 2f, height - w / 2f)
        c.drawArc(box, -90f, 360f * progress, false, paint)
    }
}
