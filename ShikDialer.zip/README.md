# Shik Dialer (تماس شیک)

A Samsung-style dark dialer for Android: keypad, recents, contacts, a custom in-call screen,
and it can be set as the **default phone app** (all calls then go through it).

Build: push to GitHub -> Actions tab -> "Build APK" -> download artifact `ShikDialer-debug-apk`.
Install the APK, open the app, tap "Set as default".
