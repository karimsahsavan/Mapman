# Shik Dialer (تماس شیک)

A Samsung-style dark dialer for Android: keypad, recents, contacts, a custom in-call screen,
and it can be set as the **default phone app** (all calls then go through it).

Build: push to GitHub -> Actions tab -> "Build APK" -> download artifact `ShikDialer-debug-apk`.
Install the APK, open the app, tap "Set as default".

## What's new
- Dialer number display auto-shrinks, so 11+ digit numbers are always fully visible (09xx numbers are grouped `0912 123 4567`).
- Call screen: animated galaxy (spiral disc, stars, nebulae, shooting stars), pulse rings, dashed orbits and flowing neon lines; colours/energy follow the call state.
- Contact photos: tap a contact's avatar (or long-press the row) -> choose a photo from the gallery / remove it. Tap the avatar on the call screen to set it too.
- Contacts without a photo get an animated cartoon person (blinks, raises one eyebrow, laughs and claps, waves) - unique per contact.
