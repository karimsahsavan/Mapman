# Shik Dialer (تماس شیک)

A Samsung-style dark dialer for Android: keypad, recents, contacts, a custom in-call screen,
and it can be set as the **default phone app** (all calls then go through it).

Build: push to GitHub -> Actions tab -> "Build APK" -> download artifact `ShikDialer-debug-apk`.
Install the APK, open the app, tap "Set as default".

## What's new
- Dialer number display auto-shrinks, so 11+ digit numbers are always fully visible (09xx numbers are grouped `0912 123 4567`).
- Call screen: animated galaxy (spiral disc, stars, nebulae, shooting stars), pulse rings, dashed orbits and flowing neon lines; colours/energy follow the call state.
- Contact photos: tap a contact's avatar (or long-press the row) -> choose a photo from the gallery / remove it. Tap the avatar on the call screen to set it too.
- Contacts without a photo get an animated cartoon person (blinks, raises one eyebrow, laughs and claps, waves) - unique per contact.

## Version 2
- **Contacts**: add a contact (+ button in Contacts, or "Add to contacts" under the keypad number / in the Recents menu) and delete a contact (long-press the row, or swipe if you set swipe to "Delete").
- **Swipe**: swipe a row right / left. Defaults: right = call, left = message. Both are changeable in Settings (call / message / delete / nothing).
- **Settings tab**: ringtone (system default, phone ringtones, your own audio file, or silent), vibration, call-screen animation (full galaxy / neon / simple / none, with a live preview), cartoon reaction (all moves / blink only / still), swipe actions.
- **Ringtone**: the app now plays the ringtone and vibration itself for incoming calls (a default dialer must do this).
- **Notifications**: the contact photo (or the cartoon avatar when there is no photo) shows in the incoming / ongoing call notification.
- Plain white background everywhere except the dark call screen.

## Version 3
- **Incoming call**: the answer / decline buttons are now one animated slide control. Drag the knob to the right to answer, to the left to decline. While idle it glows, breathes and arrows flow to both sides; the track turns green / red as you drag, and the knob springs back if you let go early.
- **Contacts**: a newly added contact now appears at once in Contacts and in Recents (names are resolved live from the contacts instead of waiting for the call-log name cache), and the lists refresh automatically when contacts or the call log change.
- **Cartoon avatars**: redesigned with big shiny eyes, soft face / hair / shirt shading, 6 hairstyles (side-swept, bun, long, curly, pigtails, spiky), glasses, beard, bow, earrings and freckles, eyelid blinking, eyes that look around and floating hearts while laughing.

## Version 4
- **Auto-complete**: type the first 8 digits of a saved contact's number and, if only one contact matches, the full number is filled in at once; the display blinks green and the call button bumps. One backspace undoes it (back to the 8 typed digits, and it will not auto-fill that prefix again). The contact's name is shown under the number.
- **Keypad layout**: the number display sits lower, in its own card; the call button is now a round green button docked in the middle of the bottom bar (on Recents / Contacts it turns into a keypad button).
- **Bottom bar**: each tab has its own colour (green, blue, purple, orange) with a soft pill and a bounce animation on the selected tab.
