package com.shik.dialer

import android.telecom.Call
import android.telecom.InCallService
import java.util.concurrent.CopyOnWriteArrayList

object CallManager {

    interface Listener {
        fun onChanged()
    }

    private val calls = CopyOnWriteArrayList<Call>()
    private val listeners = CopyOnWriteArrayList<Listener>()

    @Volatile
    var service: InCallService? = null

    private val callback = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            notifyChanged()
        }

        override fun onDetailsChanged(call: Call, details: Call.Details) {
            notifyChanged()
        }
    }

    val primary: Call?
        get() = calls.firstOrNull { it.state == Call.STATE_RINGING }
            ?: calls.firstOrNull { it.state != Call.STATE_DISCONNECTED }
            ?: calls.firstOrNull()

    fun add(call: Call) {
        calls.add(call)
        call.registerCallback(callback)
        notifyChanged()
    }

    fun remove(call: Call) {
        call.unregisterCallback(callback)
        calls.remove(call)
        notifyChanged()
    }

    fun addListener(l: Listener) {
        if (!listeners.contains(l)) listeners.add(l)
    }

    fun removeListener(l: Listener) {
        listeners.remove(l)
    }

    fun notifyChanged() {
        for (l in listeners) l.onChanged()
    }

    fun numberOf(call: Call): String =
        call.details?.handle?.schemeSpecificPart ?: ""
}
