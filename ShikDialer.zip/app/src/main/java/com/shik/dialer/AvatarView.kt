package com.shik.dialer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.util.AttributeSet
import android.view.Choreographer
import android.view.View
import android.view.ViewOutlineProvider
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** One shared frame clock for every visible avatar (~30 fps), so lists stay cheap. */
object AvatarClock : Choreographer.FrameCallback {
    private val views = ArrayList<View>()
    private var running = false
    private var last = 0L

    @Volatile
    var now: Long = SystemClock.uptimeMillis()
        private set

    /** Prefs.REACT_*: 0 all moves, 1 blink only, 2 still. */
    @Volatile
    var reaction: Int = 0

    fun register(v: View) {
        if (!views.contains(v)) views.add(v)
        if (!running) {
            running = true
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    fun unregister(v: View) {
        views.remove(v)
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (views.isEmpty()) {
            running = false
            return
        }
        val t = frameTimeNanos / 1_000_000L
        now = t
        if (t - last >= 30L) {
            last = t
            for (i in views.indices.reversed()) views[i].invalidate()
        }
        Choreographer.getInstance().postFrameCallback(this)
    }
}

private val SKINS = intArrayOf(
    0xFFFFD9B8.toInt(), 0xFFF5C7A0.toInt(), 0xFFE8B088.toInt(),
    0xFFC98F62.toInt(), 0xFF9C6A45.toInt(), 0xFF6F4A31.toInt()
)
private val HAIRS = intArrayOf(
    0xFF2A1A12.toInt(), 0xFF4B2E1B.toInt(), 0xFF16161C.toInt(), 0xFFB5651D.toInt(),
    0xFFE0A93B.toInt(), 0xFF7B3FA0.toInt(), 0xFF2F6DB5.toInt()
)
private val SHIRTS = intArrayOf(
    0xFFFF6F91.toInt(), 0xFF6C8CFF.toInt(), 0xFF2EC4A0.toInt(), 0xFFFFA94D.toInt(),
    0xFFA77BFF.toInt(), 0xFF3BB6F0.toInt(), 0xFFEF5350.toInt()
)
private val BG_A = intArrayOf(
    0xFFD7F7E6.toInt(), 0xFFD6E4FF.toInt(), 0xFFFFE3D3.toInt(),
    0xFFEBDDFF.toInt(), 0xFFFFF3C9.toInt(), 0xFFD3F4F7.toInt()
)
private val BG_B = intArrayOf(
    0xFF8FDDB8.toInt(), 0xFF9DBAFF.toInt(), 0xFFFFB592.toInt(),
    0xFFC6A9FF.toInt(), 0xFFFFDB75.toInt(), 0xFF8AD6E3.toInt()
)

private fun mix(seed: Int, salt: Int): Int {
    var x = seed xor (salt * 0x45d9f3b)
    x = (x xor (x ushr 16)) * 0x45d9f3b
    x = x xor (x ushr 16)
    return x and 0x7fffffff
}

private fun shade(c: Int, f: Float): Int = Color.rgb(
    (Color.red(c) * f).toInt().coerceIn(0, 255),
    (Color.green(c) * f).toInt().coerceIn(0, 255),
    (Color.blue(c) * f).toInt().coerceIn(0, 255)
)

private fun smooth(x: Float): Float {
    val v = x.coerceIn(0f, 1f)
    return v * v * (3f - 2f * v)
}

/** 0 outside [a,b], 1 inside, with soft edges of width [ramp]. */
private fun env(t: Float, a: Float, b: Float, ramp: Float = 0.35f): Float =
    smooth(min((t - a) / ramp, (b - t) / ramp))

private fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t

/**
 * A round avatar. If a photo is set it shows the photo; otherwise it shows a little cartoon
 * person who blinks, raises one eyebrow, laughs while clapping, and waves.
 * The character is derived from [setPerson]'s key, so each contact always looks the same.
 */
class AvatarView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) :
    View(ctx, attrs) {

    /** Faster action cycle (used on the call screen). */
    var lively = false

    /** Draws a thin white ring around the avatar. */
    var ring = false

    /** Neutral, motionless pose (used when rendering the avatar into a notification icon). */
    var still = false

    private var seed = 0
    private var offsetMs = 0L
    private var skin = SKINS[0]
    private var hair = HAIRS[0]
    private var shirt = SHIRTS[0]
    private var hairStyle = 0
    private var bgShader: Shader? = null

    private var photo: Bitmap? = null
    private var photoShader: BitmapShader? = null

    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()
    private val path2 = Path()
    private val rect = RectF()
    private val matrix = Matrix()

    init {
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                val s = min(view.width, view.height)
                val l = (view.width - s) / 2
                val t = (view.height - s) / 2
                outline.setOval(l, t, l + s, t + s)
            }
        }
        clipToOutline = true
        setPerson("", null)
    }

    fun setPerson(key: String, bmp: Bitmap?) {
        seed = key.hashCode() and 0x7fffffff
        offsetMs = (mix(seed, 1) % 10000).toLong()
        skin = SKINS[mix(seed, 2) % SKINS.size]
        hair = HAIRS[mix(seed, 3) % HAIRS.size]
        shirt = SHIRTS[mix(seed, 4) % SHIRTS.size]
        hairStyle = mix(seed, 5) % 4
        val bg = mix(seed, 6) % BG_A.size
        bgShader = LinearGradient(0f, 0f, 100f, 100f, BG_A[bg], BG_B[bg], Shader.TileMode.CLAMP)
        photo = bmp
        photoShader = if (bmp != null) {
            BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        } else null
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        invalidateOutline()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        AvatarClock.reaction = Prefs.reaction(context)
        if (windowVisibility == VISIBLE) AvatarClock.register(this)
    }

    override fun onDetachedFromWindow() {
        AvatarClock.unregister(this)
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE && isAttachedToWindow) AvatarClock.register(this)
        else AvatarClock.unregister(this)
    }

    override fun onDraw(canvas: Canvas) {
        val s = min(width, height).toFloat()
        if (s <= 0f) return
        canvas.save()
        canvas.translate((width - s) / 2f, (height - s) / 2f)

        val ph = photo
        val sh = photoShader
        if (ph != null && sh != null) {
            matrix.reset()
            val k = s / min(ph.width, ph.height).toFloat()
            matrix.setScale(k, k)
            sh.setLocalMatrix(matrix)
            p.style = Paint.Style.FILL
            p.shader = sh
            canvas.drawCircle(s / 2f, s / 2f, s / 2f, p)
            p.shader = null
        } else {
            canvas.save()
            canvas.scale(s / 100f, s / 100f)
            drawCharacter(canvas)
            canvas.restore()
        }

        if (ring) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = s * 0.03f
            p.color = 0xB3FFFFFF.toInt()
            canvas.drawCircle(s / 2f, s / 2f, s / 2f - p.strokeWidth / 2f, p)
        }
        canvas.restore()
    }

    // ------------------------------------------------------------------ character

    private fun fill(c: Int) {
        p.style = Paint.Style.FILL
        p.color = c
    }

    private fun stroke(c: Int, w: Float) {
        p.style = Paint.Style.STROKE
        p.color = c
        p.strokeWidth = w
    }

    private fun sparkle(c: Canvas, x: Float, y: Float, r: Float) {
        val d = r * 0.55f
        c.drawLine(x - r, y, x + r, y, p)
        c.drawLine(x, y - r, x, y + r, p)
        c.drawLine(x - d, y - d, x + d, y + d, p)
        c.drawLine(x - d, y + d, x + d, y - d, p)
    }

    private fun drawCharacter(c: Canvas) {
        val now = AvatarClock.now
        val period = if (lively) 7000L else 10000L
        val cyc = now + offsetMs
        val phase = (cyc % period).toFloat() / period * 10f
        val cycleIdx = (cyc / period).toInt()
        val ts = (now % 600000L) / 1000f
        val tau = (2.0 * PI).toFloat()

        val rx = AvatarClock.reaction
        val calm = still || rx == Prefs.REACT_STILL
        val moves = !calm && rx == Prefs.REACT_ALL
        val wBrow = if (moves) env(phase, 2.2f, 4.2f) else 0f
        val wLaugh = if (moves) env(phase, 4.4f, 7.0f) else 0f
        val wWave = if (moves) env(phase, 7.2f, 9.2f) else 0f
        val side = if ((cycleIdx + seed) % 2 == 0) -1 else 1 // -1: left brow, 1: right brow

        val blinkT = cyc % 3300L
        val blink = if (!calm && blinkT < 150L) sin(PI * blinkT / 150.0).toFloat() else 0f
        val open = 0.5f + 0.5f * sin(ts * tau * 3.2f)
        val bob = if (calm) 0f else sin(ts * 1.8f) * 0.7f + sin(ts * tau * 3.2f) * 1.1f * wLaugh
        val tilt = -5f * wBrow * side + sin(ts * tau * 1.6f) * 3.5f * wLaugh

        // background
        p.style = Paint.Style.FILL
        p.shader = bgShader
        c.drawRect(0f, 0f, 100f, 100f, p)
        p.shader = null

        // sparkles while laughing
        if (wLaugh > 0.05f) {
            stroke(Color.argb((230 * wLaugh).toInt(), 255, 255, 255), 1.4f)
            val pulse = 0.7f + 0.3f * sin(ts * tau * 2f)
            sparkle(c, 17f, 30f, 4.5f * pulse)
            sparkle(c, 84f, 24f, 3.6f * (1.7f - pulse))
            sparkle(c, 88f, 56f, 3f * pulse)
        }

        // long hair sits behind the body
        if (hairStyle == 2) {
            c.save()
            c.translate(0f, bob)
            c.rotate(tilt, 50f, 74f)
            fill(hair)
            rect.set(26f, 32f, 74f, 96f)
            c.drawRoundRect(rect, 20f, 20f, p)
            c.restore()
        }

        // body + neck
        fill(shirt)
        rect.set(18f, 82f + bob * 0.4f, 82f, 134f)
        c.drawOval(rect, p)
        fill(shade(skin, 0.92f))
        rect.set(44f, 66f, 56f, 84f)
        c.drawRoundRect(rect, 4f, 4f, p)

        // ---- head
        c.save()
        c.translate(0f, bob)
        c.rotate(tilt, 50f, 74f)

        fill(skin)
        c.drawCircle(29.5f, 53f, 4f, p)
        c.drawCircle(70.5f, 53f, 4f, p)

        // hair behind the face
        fill(hair)
        when (hairStyle) {
            0 -> {
                rect.set(26.5f, 24.5f, 73.5f, 71.5f)
                c.drawArc(rect, 180f, 180f, true, p)
            }
            1 -> {
                c.drawCircle(50f, 24f, 8.5f, p)
                rect.set(26.5f, 24.5f, 73.5f, 71.5f)
                c.drawArc(rect, 180f, 180f, true, p)
            }
            3 -> {
                for (i in 0..6) {
                    val a = (PI * (1.05 + 0.9 * i / 6.0)).toFloat()
                    val x = 50f + 21.5f * kotlin.math.cos(a)
                    val y = 52f + 21.5f * sin(a)
                    c.drawCircle(x, y, 7.2f, p)
                }
            }
            else -> {}
        }

        // face
        fill(skin)
        c.drawCircle(50f, 52f, 21f, p)

        // front hair (clipped to the face)
        fill(hair)
        when (hairStyle) {
            0, 1, 2 -> {
                c.save()
                path2.reset()
                path2.addCircle(50f, 52f, 21f, Path.Direction.CW)
                c.clipPath(path2)
                path.reset()
                path.moveTo(20f, 20f)
                path.lineTo(80f, 20f)
                when (hairStyle) {
                    0 -> {
                        path.lineTo(80f, 46f)
                        path.quadTo(58f, 34f, 20f, 42f)
                    }
                    1 -> {
                        path.lineTo(80f, 44f)
                        path.quadTo(50f, 36f, 20f, 44f)
                    }
                    else -> {
                        path.lineTo(80f, 54f)
                        path.quadTo(66f, 36f, 50f, 38f)
                        path.quadTo(34f, 36f, 20f, 54f)
                    }
                }
                path.close()
                c.drawPath(path, p)
                c.restore()
            }
            else -> {
                c.drawCircle(40f, 35f, 6.5f, p)
                c.drawCircle(50f, 33f, 7f, p)
                c.drawCircle(60f, 35f, 6.5f, p)
            }
        }

        // cheeks
        fill(Color.argb((70 + 70 * wLaugh).toInt(), 255, 105, 130))
        c.drawCircle(36f, 61f, 3.6f, p)
        c.drawCircle(64f, 61f, 3.6f, p)

        // eyes
        val look = sin(ts * 0.8f) * 0.8f
        if (wLaugh > 0.5f) {
            stroke(0xFF2B2230.toInt(), 1.9f)
            path.reset()
            path.moveTo(39.5f, 55f)
            path.quadTo(42.5f, 50.5f, 45.5f, 55f)
            path.moveTo(54.5f, 55f)
            path.quadTo(57.5f, 50.5f, 60.5f, 55f)
            c.drawPath(path, p)
        } else {
            val ry = max(0.35f, 2.5f * (1f - blink) * (1f - wLaugh))
            fill(0xFF2B2230.toInt())
            rect.set(40.2f + look, 54f - ry, 44.8f + look, 54f + ry)
            c.drawOval(rect, p)
            rect.set(55.2f + look, 54f - ry, 59.8f + look, 54f + ry)
            c.drawOval(rect, p)
            if (ry > 1.2f) {
                fill(Color.WHITE)
                c.drawCircle(43.2f + look, 53f, 0.8f, p)
                c.drawCircle(58.2f + look, 53f, 0.8f, p)
            }
        }

        // eyebrows (one of them goes up and tilts)
        val browBase = 47.2f - 1.6f * wLaugh
        for (sd in intArrayOf(-1, 1)) {
            val cx = if (sd < 0) 42.5f else 57.5f
            val raised = if (sd == side) wBrow else 0f
            val other = if (sd == side) 0f else wBrow
            val by = browBase - 3.4f * raised + 1.2f * other
            // outer end goes up on the raised brow (clockwise on the left, counter-clockwise on the right)
            val ang = (if (sd < 0) 1f else -1f) * (14f * raised - 6f * other)
            c.save()
            c.rotate(ang, cx, by)
            stroke(shade(hair, 0.9f), 1.9f)
            path.reset()
            path.moveTo(cx - 4.8f, by + 0.9f)
            path.quadTo(cx, by - 1.6f - 1.4f * raised, cx + 4.8f, by + 0.9f)
            c.drawPath(path, p)
            c.restore()
        }

        // mouth
        if (wLaugh < 0.08f) {
            stroke(0xFF7A2E3E.toInt(), 1.8f)
            path.reset()
            path.moveTo(44.5f, 61.5f)
            path.quadTo(50f, 66.8f, 55.5f, 61.5f)
            c.drawPath(path, p)
        } else {
            val dd = (2f + (4f + 9f * open) * wLaugh)
            path.reset()
            path.moveTo(43.2f, 60f)
            path.lineTo(56.8f, 60f)
            path.cubicTo(56.2f, 60f + dd, 43.8f, 60f + dd, 43.2f, 60f)
            path.close()
            fill(0xFF5A1B2B.toInt())
            c.drawPath(path, p)
            c.save()
            c.clipPath(path)
            fill(0xFFFF7A93.toInt())
            c.drawCircle(50f, 60f + dd * 0.78f, 5f, p)
            fill(Color.WHITE)
            c.drawRect(44f, 59.5f, 56f, 62.2f, p)
            c.restore()
        }
        c.restore() // head

        // ---- arms & hands (appear from below while clapping / waving)
        val wHand = max(wLaugh, wWave)
        if (wHand > 0.02f) {
            val clap = 0.5f + 0.5f * sin(ts * tau * 3.2f + 1.2f)
            val shirtDark = shade(shirt, 0.85f)
            val shL = floatArrayOf(34f, 90f)
            val shR = floatArrayOf(66f, 90f)

            // left hand: only claps
            val lx = lerp(20f, 41f + 4f * clap, wLaugh)
            val ly = lerp(112f, 80f, wLaugh)
            // right hand: claps or waves
            val mixW = wWave / (wWave + wLaugh + 0.0001f)
            val rxClap = 59f - 4f * clap
            val rxWave = 78f + 6f * sin(ts * tau * 2.2f)
            val ryWave = 64f + 1.6f * sin(ts * tau * 4.4f)
            val tx = lerp(rxClap, rxWave, mixW)
            val ty = lerp(80f, ryWave, mixW)
            val rx = lerp(80f, tx, wHand)
            val ry = lerp(112f, ty, wHand)

            if (wLaugh > 0.02f) {
                stroke(shirtDark, 7f)
                c.drawLine(shL[0], shL[1], lx, ly, p)
                fill(skin)
                c.drawCircle(lx, ly, 5.3f, p)
            }
            stroke(shirtDark, 7f)
            c.drawLine(shR[0], shR[1], rx, ry, p)
            fill(skin)
            c.drawCircle(rx, ry, 5.3f, p)
        }
    }
}

/** Renders the avatar (photo or cartoon) into a round bitmap, e.g. for notifications. */
object AvatarBitmap {
    fun make(ctx: Context, key: String, photo: Bitmap?, size: Int): Bitmap {
        val v = AvatarView(ctx)
        v.still = true
        v.setPerson(key, photo)
        v.measure(
            View.MeasureSpec.makeMeasureSpec(size, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(size, View.MeasureSpec.EXACTLY)
        )
        v.layout(0, 0, size, size)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val clip = Path()
        clip.addCircle(size / 2f, size / 2f, size / 2f, Path.Direction.CW)
        c.clipPath(clip)
        v.draw(c)
        return bmp
    }
}
