package com.shik.dialer

data class Entry(
    val title: String,
    val subtitle: String,
    val number: String,
    val missed: Boolean = false,
    /** Contacts list only: used to delete the contact. */
    val contactId: Long = 0L,
    val lookupKey: String? = null,
    /** Recents list only: the call-log row id. */
    val logId: Long = 0L,
    /** True when the number belongs to a saved contact. */
    val saved: Boolean = false
)
