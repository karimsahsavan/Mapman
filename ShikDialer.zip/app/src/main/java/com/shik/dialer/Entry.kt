package com.shik.dialer

data class Entry(
    val title: String,
    val subtitle: String,
    val number: String,
    val missed: Boolean = false
)
