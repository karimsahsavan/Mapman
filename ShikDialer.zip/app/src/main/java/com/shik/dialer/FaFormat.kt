package com.shik.dialer

import android.content.Context
import android.provider.CallLog
import java.util.Calendar
import java.util.Locale

/** Jalali (Shamsi) dates, Persian digits, call durations and call-type styling. */
object FaFormat {

    private val months = arrayOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )

    /** Index = Calendar.DAY_OF_WEEK - 1 (Sunday first). */
    private val weekdays = arrayOf(
        "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"
    )

    fun digits(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s) sb.append(if (ch in '0'..'9') '۰' + (ch - '0') else ch)
        return sb.toString()
    }

    /** Gregorian -> Jalali. Returns [year, month, day]. */
    fun toJalali(gy0: Int, gm: Int, gd: Int): IntArray {
        val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        var gy = gy0
        var jy: Int
        if (gy > 1600) {
            jy = 979
            gy -= 1600
        } else {
            jy = 0
            gy -= 621
        }
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 365 * gy + (gy2 + 3) / 4 - (gy2 + 99) / 100 + (gy2 + 399) / 400 - 80 + gd + gdm[gm - 1]
        jy += 33 * (days / 12053)
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            jy += (days - 1) / 365
            days = (days - 1) % 365
        }
        val jm: Int
        val jd: Int
        if (days < 186) {
            jm = 1 + days / 31
            jd = 1 + days % 31
        } else {
            jm = 7 + (days - 186) / 30
            jd = 1 + (days - 186) % 30
        }
        return intArrayOf(jy, jm, jd)
    }

    private fun cal(ms: Long): Calendar = Calendar.getInstance().apply { timeInMillis = ms }

    private fun jalali(c: Calendar): IntArray =
        toJalali(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))

    /** 14:35 in Persian digits (device time zone). */
    fun time(ms: Long): String {
        val c = cal(ms)
        return digits(
            String.format(Locale.US, "%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
        )
    }

    /** پنجشنبه ۵ آذر ۱۴۰۵ */
    fun fullDate(ms: Long): String {
        val c = cal(ms)
        val j = jalali(c)
        return weekdays[c.get(Calendar.DAY_OF_WEEK) - 1] + " " +
            digits(j[2].toString()) + " " + months[j[1] - 1] + " " + digits(j[0].toString())
    }

    private fun sameDay(a: Calendar, b: Calendar): Boolean =
        a.get(Calendar.YEAR) == b.get(Calendar.YEAR) &&
            a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)

    /** امروز / دیروز / ۵ آذر / ۵ آذر ۱۴۰۴ (year only when it is not the current year). */
    fun shortDate(ctx: Context, ms: Long): String {
        val c = cal(ms)
        val now = Calendar.getInstance()
        if (sameDay(c, now)) return ctx.getString(R.string.today)
        val y = Calendar.getInstance()
        y.add(Calendar.DAY_OF_YEAR, -1)
        if (sameDay(c, y)) return ctx.getString(R.string.yesterday)
        val j = jalali(c)
        val base = digits(j[2].toString()) + " " + months[j[1] - 1]
        return if (j[0] == jalali(now)[0]) base else base + " " + digits(j[0].toString())
    }

    /** 02:34 or 1:05:12 */
    fun duration(sec: Long): String {
        val s = sec.coerceAtLeast(0L)
        val h = s / 3600
        val m = (s % 3600) / 60
        val ss = s % 60
        return digits(
            if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, ss)
            else String.format(Locale.US, "%02d:%02d", m, ss)
        )
    }

    /** ۲ دقیقه و ۳۴ ثانیه */
    fun durationLong(ctx: Context, sec: Long): String {
        val s = sec.coerceAtLeast(0L)
        if (s == 0L) return ctx.getString(R.string.dur_none)
        val parts = ArrayList<String>()
        val h = s / 3600
        val m = (s % 3600) / 60
        val ss = s % 60
        if (h > 0) parts.add(ctx.getString(R.string.dur_h, digits(h.toString())))
        if (m > 0) parts.add(ctx.getString(R.string.dur_m, digits(m.toString())))
        if (ss > 0) parts.add(ctx.getString(R.string.dur_s, digits(ss.toString())))
        return parts.joinToString(ctx.getString(R.string.dur_and))
    }

    // ---------------------------------------------------------------- call type styling

    private const val GREEN = 0xFF1FC46A.toInt()
    private const val BLUE = 0xFF2F80ED.toInt()
    private const val RED = 0xFFF0524A.toInt()
    private const val ORANGE = 0xFFFF8F3F.toInt()

    fun typeColor(e: Entry): Int = when (e.type) {
        CallLog.Calls.OUTGOING_TYPE -> GREEN
        CallLog.Calls.MISSED_TYPE -> RED
        CallLog.Calls.REJECTED_TYPE, CallLog.Calls.BLOCKED_TYPE -> ORANGE
        else -> BLUE
    }

    fun typeIcon(e: Entry): Int = when (e.type) {
        CallLog.Calls.OUTGOING_TYPE -> R.drawable.ic_call_made
        CallLog.Calls.MISSED_TYPE, CallLog.Calls.REJECTED_TYPE,
        CallLog.Calls.BLOCKED_TYPE -> R.drawable.ic_call_missed
        else -> R.drawable.ic_call_received
    }

    private fun unanswered(e: Entry) = e.type == CallLog.Calls.OUTGOING_TYPE && e.duration <= 0L

    /** Short label for the row: ورودی / خروجی / بی‌پاسخ … */
    fun shortLabel(ctx: Context, e: Entry): String = when (e.type) {
        CallLog.Calls.OUTGOING_TYPE -> ctx.getString(R.string.type_outgoing)
        CallLog.Calls.MISSED_TYPE -> ctx.getString(R.string.type_missed)
        CallLog.Calls.REJECTED_TYPE -> ctx.getString(R.string.type_rejected)
        CallLog.Calls.BLOCKED_TYPE -> ctx.getString(R.string.type_blocked)
        else -> ctx.getString(R.string.type_incoming)
    }

    /** Long label for the details sheet: تماس ورودی / تماس خروجی … */
    fun longLabel(ctx: Context, e: Entry): String = when {
        unanswered(e) -> ctx.getString(R.string.call_out_unanswered)
        e.type == CallLog.Calls.OUTGOING_TYPE -> ctx.getString(R.string.call_out)
        e.type == CallLog.Calls.MISSED_TYPE -> ctx.getString(R.string.call_missed)
        e.type == CallLog.Calls.REJECTED_TYPE -> ctx.getString(R.string.call_rejected)
        e.type == CallLog.Calls.BLOCKED_TYPE -> ctx.getString(R.string.call_blocked)
        else -> ctx.getString(R.string.call_in)
    }

    /** "ورودی • ۰۲:۳۴", "خروجی • بی‌پاسخ", "بی‌پاسخ" */
    fun summary(ctx: Context, e: Entry): String {
        val base = shortLabel(ctx, e)
        return when {
            unanswered(e) -> base + " • " + ctx.getString(R.string.no_answer)
            e.duration > 0L &&
                (e.type == CallLog.Calls.OUTGOING_TYPE || e.type == CallLog.Calls.INCOMING_TYPE) ->
                base + " • " + duration(e.duration)
            else -> base
        }
    }
}
