package com.shik.dialer

import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.VideoProfile
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class InCallActivity : AppCompatActivity(), CallManager.Listener {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var avatar: TextView
    private lateinit var callName: TextView
    private lateinit var callStatus: TextView
    private lateinit var rowOptions: View
    private lateinit var rowIncoming: View
    private lateinit var rowActive: View
    private lateinit var optMute: ImageButton
    private lateinit var optSpeaker: ImageButton
    private lateinit var optHold: ImageButton

    private var cachedNumber: String? = null
    private var cachedName: String = ""
    private var closing = false

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_incall)

        avatar = findViewById(R.id.avatar)
        callName = findViewById(R.id.callName)
        callStatus = findViewById(R.id.callStatus)
        rowOptions = findViewById(R.id.rowOptions)
        rowIncoming = findViewById(R.id.rowIncoming)
        rowActive = findViewById(R.id.rowActive)
        optMute = findViewById(R.id.optMute)
        optSpeaker = findViewById(R.id.optSpeaker)
        optHold = findViewById(R.id.optHold)

        Anim.press(findViewById<View>(R.id.btnAnswer), 0.88f)
        Anim.press(findViewById<View>(R.id.btnDecline), 0.88f)
        Anim.press(findViewById<View>(R.id.btnEnd), 0.88f)
        Anim.press(optMute, 0.88f)
        Anim.press(optSpeaker, 0.88f)
        Anim.press(optHold, 0.88f)

        findViewById<View>(R.id.btnAnswer).setOnClickListener {
            CallManager.primary?.answer(VideoProfile.STATE_AUDIO_ONLY)
        }
        findViewById<View>(R.id.btnDecline).setOnClickListener {
            CallManager.primary?.reject(false, null)
        }
        findViewById<View>(R.id.btnEnd).setOnClickListener {
            CallManager.primary?.disconnect()
        }
        optMute.setOnClickListener {
            val s = CallManager.service
            val muted = s?.callAudioState?.isMuted ?: false
            s?.setMuted(!muted)
        }
        optSpeaker.setOnClickListener {
            val s = CallManager.service
            val route = s?.callAudioState?.route
            s?.setAudioRoute(
                if (route == CallAudioState.ROUTE_SPEAKER) CallAudioState.ROUTE_WIRED_OR_EARPIECE
                else CallAudioState.ROUTE_SPEAKER
            )
        }
        optHold.setOnClickListener {
            val c = CallManager.primary ?: return@setOnClickListener
            if (c.state == Call.STATE_HOLDING) c.unhold() else c.hold()
        }
    }

    override fun onStart() {
        super.onStart()
        CallManager.addListener(this)
        handler.post(ticker)
    }

    override fun onStop() {
        super.onStop()
        CallManager.removeListener(this)
        handler.removeCallbacks(ticker)
    }

    override fun onChanged() {
        runOnUiThread { refresh() }
    }

    private fun style(b: ImageButton, on: Boolean) {
        b.isSelected = on
        b.imageTintList = ColorStateList.valueOf(if (on) Color.WHITE else 0xFF14161C.toInt())
    }

    private fun refresh() {
        val call = CallManager.primary
        if (call == null) {
            closeSoon()
            return
        }
        closing = false

        val number = CallManager.numberOf(call)
        if (number != cachedNumber) {
            cachedNumber = number
            cachedName = ContactUtils.lookupName(this, number)
                ?: number.ifBlank { getString(R.string.unknown) }
        }
        callName.text = cachedName
        val first = cachedName.trim().firstOrNull()
        avatar.text =
            if (first != null && first.isLetter()) first.uppercaseChar().toString() else "#"

        val state = call.state
        val ringing = state == Call.STATE_RINGING
        rowIncoming.visibility = if (ringing) View.VISIBLE else View.GONE
        rowActive.visibility = if (ringing) View.GONE else View.VISIBLE
        rowOptions.visibility = if (ringing) View.INVISIBLE else View.VISIBLE

        callStatus.text = when (state) {
            Call.STATE_RINGING -> getString(R.string.incoming)
            Call.STATE_DIALING, Call.STATE_CONNECTING, Call.STATE_NEW,
            Call.STATE_PULLING_CALL -> getString(R.string.calling)
            Call.STATE_HOLDING -> getString(R.string.on_hold)
            Call.STATE_DISCONNECTED, Call.STATE_DISCONNECTING -> getString(R.string.call_ended)
            Call.STATE_ACTIVE -> {
                val start = call.details?.connectTimeMillis ?: 0L
                val secs = if (start > 0L) (System.currentTimeMillis() - start) / 1000L else 0L
                String.format(Locale.US, "%02d:%02d", secs / 60L, secs % 60L)
            }
            else -> ""
        }

        val audio = CallManager.service?.callAudioState
        style(optMute, audio?.isMuted ?: false)
        style(optSpeaker, audio?.route == CallAudioState.ROUTE_SPEAKER)
        style(optHold, state == Call.STATE_HOLDING)
    }

    private fun closeSoon() {
        if (closing) return
        closing = true
        callStatus.text = getString(R.string.call_ended)
        handler.postDelayed({
            if (CallManager.primary == null) finish() else closing = false
        }, 800)
    }
}
