package com.shik.dialer

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.VideoProfile
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import java.util.Locale

class InCallActivity : AppCompatActivity(), CallManager.Listener {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var cosmic: CosmicView
    private lateinit var avatar: AvatarView
    private lateinit var callName: TextView
    private lateinit var callNumber: TextView
    private lateinit var callStatus: TextView
    private lateinit var rowOptions: View
    private lateinit var rowIncoming: View
    private lateinit var rowActive: View
    private lateinit var optMute: ImageButton
    private lateinit var optSpeaker: ImageButton
    private lateinit var optHold: ImageButton
    private lateinit var btnAnswer: View

    private var preview = false
    private var cachedNumber: String? = null
    private var cachedName: String = ""
    private var closing = false
    private var pulse: ObjectAnimator? = null

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    private val pickPhoto =
        registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            val num = cachedNumber
            if (uri != null && !num.isNullOrBlank()) {
                Thread {
                    val ok = PhotoStore.save(this, num, uri)
                    runOnUiThread {
                        if (ok) bindPerson() else
                            Toast.makeText(this, R.string.photo_failed, Toast.LENGTH_SHORT).show()
                    }
                }.start()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_incall)
        preview = intent.getBooleanExtra("preview", false)

        // dark space look: dark system bars with light icons
        window.statusBarColor = 0xFF05030F.toInt()
        window.navigationBarColor = 0xFF0A1B3C.toInt()
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        cosmic = findViewById(R.id.cosmic)
        avatar = findViewById(R.id.avatar)
        callName = findViewById(R.id.callName)
        callNumber = findViewById(R.id.callNumber)
        callStatus = findViewById(R.id.callStatus)
        rowOptions = findViewById(R.id.rowOptions)
        rowIncoming = findViewById(R.id.rowIncoming)
        rowActive = findViewById(R.id.rowActive)
        optMute = findViewById(R.id.optMute)
        optSpeaker = findViewById(R.id.optSpeaker)
        optHold = findViewById(R.id.optHold)
        btnAnswer = findViewById(R.id.btnAnswer)

        cosmic.anchor = avatar
        avatar.lively = true
        avatar.ring = true
        cosmic.setOnClickListener {
            if (preview && CallManager.primary == null) finish()
        }

        Anim.press(findViewById<View>(R.id.btnDecline), 0.88f)
        Anim.press(findViewById<View>(R.id.btnEnd), 0.88f)
        Anim.press(optMute, 0.88f)
        Anim.press(optSpeaker, 0.88f)
        Anim.press(optHold, 0.88f)

        btnAnswer.setOnClickListener {
            CallManager.primary?.answer(VideoProfile.STATE_AUDIO_ONLY)
        }
        findViewById<View>(R.id.btnDecline).setOnClickListener {
            CallManager.primary?.reject(false, null)
        }
        findViewById<View>(R.id.btnEnd).setOnClickListener {
            CallManager.primary?.disconnect()
        }
        avatar.setOnClickListener {
            if (!cachedNumber.isNullOrBlank()) {
                pickPhoto.launch(
                    PickVisualMediaRequest.Builder()
                        .setMediaType(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        .build()
                )
            }
        }
        optMute.setOnClickListener {
            val s = CallManager.service
            val muted = s?.callAudioState?.isMuted ?: false
            s?.setMuted(!muted)
        }
        optSpeaker.setOnClickListener {
            val s = CallManager.service
            val route = s?.callAudioState?.route
            s?.setAudioRoute(
                if (route == CallAudioState.ROUTE_SPEAKER) CallAudioState.ROUTE_WIRED_OR_EARPIECE
                else CallAudioState.ROUTE_SPEAKER
            )
        }
        optHold.setOnClickListener {
            val c = CallManager.primary ?: return@setOnClickListener
            if (c.state == Call.STATE_HOLDING) c.unhold() else c.hold()
        }

        playEntrance()
    }

    private fun playEntrance() {
        avatar.alpha = 0f
        avatar.scaleX = 0.6f
        avatar.scaleY = 0.6f
        avatar.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650)
            .setInterpolator(OvershootInterpolator(1.8f)).start()
        for ((i, v) in listOf(callName, callNumber, callStatus).withIndex()) {
            v.alpha = 0f
            v.translationY = 28f
            v.animate().alpha(1f).translationY(0f).setStartDelay(180L + i * 90L)
                .setDuration(450).start()
        }
        for (v in listOf(rowOptions, rowIncoming, rowActive)) {
            v.translationY = 90f
            v.animate().translationY(0f).setStartDelay(250).setDuration(500)
                .setInterpolator(OvershootInterpolator(1.1f)).start()
        }
    }

    override fun onStart() {
        super.onStart()
        cosmic.style = Prefs.callAnim(this)
        AvatarClock.reaction = Prefs.reaction(this)
        CallManager.addListener(this)
        handler.post(ticker)
    }

    override fun onStop() {
        super.onStop()
        CallManager.removeListener(this)
        handler.removeCallbacks(ticker)
        setRingingFx(false)
    }

    override fun onChanged() {
        runOnUiThread { refresh() }
    }

    private fun style(b: ImageButton, on: Boolean) {
        b.isSelected = on
        b.imageTintList = ColorStateList.valueOf(if (on) 0xFF1A1040.toInt() else Color.WHITE)
    }

    private fun setRingingFx(on: Boolean) {
        if (on) {
            if (pulse == null) {
                pulse = ObjectAnimator.ofPropertyValuesHolder(
                    btnAnswer,
                    PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.14f),
                    PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.14f)
                ).apply {
                    duration = 650
                    repeatMode = ObjectAnimator.REVERSE
                    repeatCount = ObjectAnimator.INFINITE
                    start()
                }
            }
        } else {
            pulse?.cancel()
            pulse = null
            btnAnswer.scaleX = 1f
            btnAnswer.scaleY = 1f
        }
    }

    private fun bindPerson() {
        val number = cachedNumber ?: ""
        val key = PhotoStore.key(number).ifEmpty { cachedName }
        avatar.setPerson(key, PhotoStore.get(this, number))
    }

    private fun refresh() {
        val call = CallManager.primary
        if (call == null) {
            if (preview) showPreview() else closeSoon()
            return
        }
        preview = false
        closing = false

        val number = CallManager.numberOf(call)
        if (number != cachedNumber) {
            cachedNumber = number
            val contact = ContactUtils.lookupName(this, number)
            cachedName = contact ?: number.ifBlank { getString(R.string.unknown) }
            callNumber.text = number
            callNumber.visibility =
                if (contact != null && number.isNotBlank()) View.VISIBLE else View.GONE
            bindPerson()
        }
        callName.text = cachedName

        val state = call.state
        val ringing = state == Call.STATE_RINGING
        rowIncoming.visibility = if (ringing) View.VISIBLE else View.GONE
        rowActive.visibility = if (ringing) View.GONE else View.VISIBLE
        rowOptions.visibility = if (ringing) View.INVISIBLE else View.VISIBLE
        setRingingFx(ringing)

        cosmic.setMode(
            when (state) {
                Call.STATE_RINGING -> CosmicView.Mode.RINGING
                Call.STATE_DIALING, Call.STATE_CONNECTING, Call.STATE_NEW,
                Call.STATE_PULLING_CALL -> CosmicView.Mode.CALLING
                Call.STATE_HOLDING -> CosmicView.Mode.HOLD
                Call.STATE_DISCONNECTED, Call.STATE_DISCONNECTING -> CosmicView.Mode.ENDED
                else -> CosmicView.Mode.ACTIVE
            }
        )

        callStatus.text = when (state) {
            Call.STATE_RINGING -> getString(R.string.incoming)
            Call.STATE_DIALING, Call.STATE_CONNECTING, Call.STATE_NEW,
            Call.STATE_PULLING_CALL -> getString(R.string.calling)
            Call.STATE_HOLDING -> getString(R.string.on_hold)
            Call.STATE_DISCONNECTED, Call.STATE_DISCONNECTING -> getString(R.string.call_ended)
            Call.STATE_ACTIVE -> {
                val start = call.details?.connectTimeMillis ?: 0L
                val secs = if (start > 0L) (System.currentTimeMillis() - start) / 1000L else 0L
                String.format(Locale.US, "%02d:%02d", secs / 60L, secs % 60L)
            }
            else -> ""
        }

        val audio = CallManager.service?.callAudioState
        style(optMute, audio?.isMuted ?: false)
        style(optSpeaker, audio?.route == CallAudioState.ROUTE_SPEAKER)
        style(optHold, state == Call.STATE_HOLDING)
    }

    /** Sample screen used by Settings so the chosen animation can be seen without a real call. */
    private fun showPreview() {
        if (cachedNumber != "preview") {
            cachedNumber = "preview"
            avatar.setPerson("preview", null)
        }
        callName.text = getString(R.string.preview_name)
        callNumber.visibility = View.GONE
        callStatus.text = getString(R.string.preview_hint)
        rowIncoming.visibility = View.GONE
        rowActive.visibility = View.GONE
        rowOptions.visibility = View.INVISIBLE
        setRingingFx(false)
        val modes = arrayOf(
            CosmicView.Mode.RINGING, CosmicView.Mode.CALLING,
            CosmicView.Mode.ACTIVE, CosmicView.Mode.HOLD
        )
        cosmic.setMode(modes[((System.currentTimeMillis() / 3000L) % 4L).toInt()])
    }

    private fun closeSoon() {
        if (closing) return
        closing = true
        cosmic.setMode(CosmicView.Mode.ENDED)
        callStatus.text = getString(R.string.call_ended)
        handler.postDelayed({
            if (CallManager.primary == null) finish() else closing = false
        }, 900)
    }
}
