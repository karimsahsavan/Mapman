package com.shik.dialer

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.util.AttributeSet
import android.view.Choreographer
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.*

/** Procedural, resolution-independent dancer. Every pose is calculated continuously (no bitmap/GIF frames). */
class DancingGirlView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs), Choreographer.FrameCallback {
    private val density = resources.displayMetrics.density
    private val skin = Paint(3).apply { color = Color.rgb(245, 190, 157); strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val hair = Paint(3).apply { color = Color.rgb(66, 39, 35); style = Paint.Style.FILL }
    private val shirt = Paint(3).apply { color = Color.rgb(169, 137, 226); style = Paint.Style.FILL }
    private val skirt = Paint(3).apply { color = Color.rgb(77, 43, 105); style = Paint.Style.FILL }
    private val outline = Paint(3).apply { color = Color.rgb(49, 31, 73); style = Paint.Style.STROKE; strokeWidth = 1.4f * density; strokeCap = Paint.Cap.ROUND }
    private val shoe = Paint(3).apply { color = Color.rgb(76, 54, 111); style = Paint.Style.FILL }
    private val face = Paint(3).apply { color = Color.rgb(255, 226, 207); style = Paint.Style.FILL }
    private val eye = Paint(3).apply { color = Color.rgb(58, 38, 42); style = Paint.Style.FILL }
    private val p = Path()
    private var startAt = 0L
    private var running = false
    private var completed = false
    private var danceDuration = 12_500L
    private var fade = 1f
    private var lastPhase = 0f

    init { setLayerType(View.LAYER_TYPE_SOFTWARE, null) }

    fun startDance() {
        if (completed || running) return
        completed = false; running = true; fade = 1f; startAt = SystemClock.uptimeMillis()
        visibility = VISIBLE
        Choreographer.getInstance().postFrameCallback(this)
    }

    fun stopAndFade() {
        if (!running && visibility != VISIBLE) return
        running = false
        Choreographer.getInstance().removeFrameCallback(this)
        animate().cancel()
        animate().alpha(0f).setDuration(260).withEndAction { visibility = GONE; completed = true }.start()
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!running) return
        val elapsed = SystemClock.uptimeMillis() - startAt
        if (elapsed >= danceDuration) {
            running = false; completed = true
            animate().alpha(0f).setDuration(500).withEndAction { visibility = GONE }.start()
            return
        }
        // Ease-in/out at the beginning and end; pose itself remains fully continuous.
        val t = elapsed / 1000f
        val edge = min(1f, min(elapsed / 650f, (danceDuration - elapsed) / 900f).coerceAtLeast(0f))
        fade = edge
        lastPhase = t
        alpha = edge
        invalidate()
        Choreographer.getInstance().postFrameCallback(this)
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (!completed && visibility == VISIBLE) startDance() }
    override fun onDetachedFromWindow() { Choreographer.getInstance().removeFrameCallback(this); running = false; super.onDetachedFromWindow() }

    private fun stroke(canvas: Canvas, paint: Paint, x1: Float, y1: Float, x2: Float, y2: Float, width: Float) {
        paint.style = Paint.Style.STROKE; paint.strokeWidth = width
        canvas.drawLine(x1, y1, x2, y2, paint); paint.style = Paint.Style.FILL
    }
    private fun limb(canvas: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float, width: Float, color: Int) {
        val q = Paint(3).apply { this.color = color; style = Paint.Style.STROKE; strokeWidth = width; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        val path = Path().apply { moveTo(x1,y1); quadTo((x1+x2)/2f,(y1+y2)/2f,x2,y2); quadTo((x2+x3)/2f,(y2+y3)/2f,x3,y3) }
        canvas.drawPath(path,q)
        canvas.drawCircle(x2,y2,width*.48f,skin)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!running && completed) return
        val w = width.toFloat(); val h = height.toFloat(); if (w <= 0f || h <= 0f) return
        val unit = min(w / 104f, h / 116f)
        canvas.save(); canvas.translate((w-104f*unit)/2f, (h-116f*unit)/2f); canvas.scale(unit,unit)
        val t = lastPhase
        val bounce = 2.0f * sin(t*4.4f) + 1.0f*sin(t*8.8f)
        val sway = 7.5f*sin(t*2.2f) + 2.2f*sin(t*4.4f)
        val armL = sin(t*3.2f + .2f); val armR = sin(t*3.2f + 2.0f)
        val stepL = sin(t*3.2f); val stepR = sin(t*3.2f + PI.toFloat())
        canvas.translate(sway, 0f)
        // Soft floor shadow
        val shadow = Paint(3).apply { color = 0x263D2A59; maskFilter = BlurMaskFilter(4f, BlurMaskFilter.Blur.NORMAL) }
        canvas.drawOval(27f,109f,78f,115f,shadow)
        val hipY = 68f + bounce*.45f
        // Legs and shoes, continuously stepping
        limb(canvas,49f,hipY,46f+stepL*5f,87f,45f+stepL*8f,104f,7.4f,Color.rgb(245,190,157))
        limb(canvas,57f,hipY,61f+stepR*5f,87f,62f+stepR*8f,104f,7.4f,Color.rgb(245,190,157))
        canvas.drawOval(37f+stepL*8f,101f,51f+stepL*8f,108f,shoe)
        canvas.drawOval(55f+stepR*8f,101f,69f+stepR*8f,108f,shoe)
        // Flowing skirt with a continuously changing hem
        val flutter = sin(t*4.1f)*4.2f
        p.reset(); p.moveTo(39f,61f); p.cubicTo(33f,68f,28f,78f,24f+flutter,86f)
        p.cubicTo(39f,91f,67f,92f,82f-flutter,84f); p.cubicTo(77f,74f,71f,67f,66f,61f); p.close()
        canvas.drawPath(p,skirt); canvas.drawPath(p,outline)
        // Shirt and shoulders
        p.reset(); p.moveTo(43f,34f); p.quadTo(52f,29f,62f,34f); p.lineTo(68f,62f); p.quadTo(53f,69f,37f,62f); p.close()
        canvas.drawPath(p,shirt); canvas.drawPath(p,outline)
        // Arms: shoulders, elbows and wrists follow smooth independent dance curves
        val shoulderY = 39f + bounce*.35f
        limb(canvas,40f,shoulderY,30f+armL*5f,47f-armL*10f,25f+armL*12f,39f+armL*10f,5.8f,Color.rgb(245,190,157))
        limb(canvas,65f,shoulderY,75f+armR*5f,46f-armR*10f,80f+armR*11f,37f+armR*10f,5.8f,Color.rgb(245,190,157))
        // Neck
        canvas.drawRect(49f,27f,57f,37f,skin)
        // Hair behind head
        canvas.drawOval(38f,5f,68f,39f,hair)
        // Face
        canvas.drawOval(42f,7f,64f,34f,face)
        // Hair fringe and side locks
        p.reset(); p.moveTo(41f,20f); p.cubicTo(36f,2f,51f,-1f,63f,8f); p.quadTo(69f,17f,64f,25f); p.quadTo(60f,13f,54f,13f); p.quadTo(47f,18f,41f,20f); p.close(); canvas.drawPath(p,hair)
        canvas.drawOval(38f,17f,44f,39f,hair); canvas.drawOval(62f,16f,68f,38f,hair)
        canvas.drawCircle(49f,21f,1.05f,eye); canvas.drawCircle(58f,21f,1.05f,eye)
        val smile = Paint(3).apply { color = 0xffa94e60; style = Paint.Style.STROKE; strokeWidth = 1.1f; strokeCap = Paint.Cap.ROUND }
        p.reset(); p.moveTo(51f,27f); p.quadTo(54f,30f,57f,27f); canvas.drawPath(p,smile)
        // Tiny skirt pleats add visual richness without bitmap assets
        val pleat = Paint(3).apply { color = 0x557F5AA0; strokeWidth = .8f }
        for (x in 37..69 step 7) canvas.drawLine(x.toFloat(),69f,(x-4+flutter*.15f).toFloat(),84f,pleat)
        canvas.restore()
    }
}
