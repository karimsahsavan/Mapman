package com.shik.dialer

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.Choreographer
import android.view.View
import kotlin.math.*

/**
 * Fully procedural dancer (no GIF / bitmap frames).
 * Skeleton + two-bone IK for legs and arms, weight shifting, counter-rotating shoulders,
 * lagging hair and a flowing dress, all computed every frame.
 * Dances forever while the number field is empty; fades out when a digit is entered
 * and fades back in when the number is cleared again.
 */
class DancingGirlView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs), Choreographer.FrameCallback {

    private val density = resources.displayMetrics.density

    private fun mk(color: Int, style: Paint.Style = Paint.Style.FILL) =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color; this.style = style
            strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }

    private val skinColor = Color.rgb(241, 192, 161)
    private val fSkin = mk(skinColor)
    private val sLimb = mk(skinColor, Paint.Style.STROKE)
    private val fShoe = mk(Color.rgb(46, 28, 52))
    private val fHair = mk(Color.rgb(70, 42, 32))
    private val sLock = mk(Color.rgb(70, 42, 32), Paint.Style.STROKE)
    private val fDress = mk(Color.WHITE)
    private val sBelt = mk(Color.rgb(255, 214, 120), Paint.Style.STROKE)
    private val sPleat = mk(Color.argb(48, 255, 255, 255), Paint.Style.STROKE)
    private val fEye = mk(Color.rgb(48, 30, 30))
    private val fEyeHi = mk(Color.argb(210, 255, 255, 255))
    private val sBrow = mk(Color.rgb(74, 46, 36), Paint.Style.STROKE)
    private val sLash = mk(Color.rgb(48, 30, 30), Paint.Style.STROKE)
    private val sLips = mk(Color.rgb(205, 72, 96), Paint.Style.STROKE)
    private val sNose = mk(Color.argb(70, 170, 100, 80), Paint.Style.STROKE)
    private val fBlush = mk(Color.argb(70, 255, 120, 140))
    private val fGlow = mk(Color.WHITE)
    private val fSpark = mk(Color.WHITE)
    private val fShadow = mk(Color.argb(26, 60, 30, 90))

    private val path = Path()
    private val rect = RectF()
    private val ik = FloatArray(4)

    private var wanted = true
    private var framesOn = false
    private var t0 = 0L
    private var t = 0f
    private var token = 0

    init {
        fDress.shader = LinearGradient(0f, 16f, 0f, 70f,
            Color.rgb(255, 128, 158), Color.rgb(196, 36, 106), Shader.TileMode.CLAMP)
        val hairShader = LinearGradient(-8f, -6f, 8f, 44f,
            Color.rgb(98, 60, 44), Color.rgb(46, 26, 24), Shader.TileMode.CLAMP)
        fHair.shader = hairShader
        sLock.shader = hairShader
        fGlow.shader = RadialGradient(0f, 50f, 58f,
            Color.argb(80, 255, 140, 190), Color.argb(0, 255, 140, 190), Shader.TileMode.CLAMP)
    }

    // ---------------------------------------------------------------- public API

    /** Show the dancer and keep it dancing (safe to call repeatedly). */
    fun startDance() {
        if (wanted && visibility == VISIBLE && framesOn && alpha >= 0.99f) return
        wanted = true
        token++
        animate().cancel()
        visibility = VISIBLE
        animate().alpha(1f).setDuration(320).start()
        ensureFrames()
    }

    /** Smoothly fade the dancer away (safe to call repeatedly). */
    fun stopAndFade() {
        if (!wanted) return
        wanted = false
        val my = ++token
        animate().cancel()
        animate().alpha(0f).setDuration(350).withEndAction {
            if (my == token) { pauseFrames(); visibility = GONE }
        }.start()
    }

    /** Hide immediately without animation. */
    fun hideNow() {
        wanted = false
        token++
        animate().cancel()
        pauseFrames()
        alpha = 0f
        visibility = GONE
    }

    // ---------------------------------------------------------------- frames

    private fun ensureFrames() {
        if (framesOn || !wanted || !isAttachedToWindow) return
        framesOn = true
        if (t0 == 0L) t0 = System.nanoTime()
        Choreographer.getInstance().postFrameCallback(this)
    }

    private fun pauseFrames() {
        framesOn = false
        Choreographer.getInstance().removeFrameCallback(this)
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!framesOn) return
        t = (System.nanoTime() - t0) / 1_000_000_000f
        invalidate()
        Choreographer.getInstance().postFrameCallback(this)
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (wanted && visibility == VISIBLE) ensureFrames() }
    override fun onDetachedFromWindow() { pauseFrames(); super.onDetachedFromWindow() }
    override fun onWindowVisibilityChanged(v: Int) {
        super.onWindowVisibilityChanged(v)
        if (v == VISIBLE) { if (wanted && visibility == VISIBLE) ensureFrames() } else pauseFrames()
    }

    // ---------------------------------------------------------------- math helpers

    private fun smooth(x: Float): Float { val k = x.coerceIn(0f, 1f); return k * k * (3f - 2f * k) }
    private fun lerp(a: Float, b: Float, k: Float) = a + (b - a) * k

    /** Two-bone IK. Result: ik[0..1] = joint (knee/elbow), ik[2..3] = reached end point. */
    private fun solve(ax: Float, ay: Float, tx: Float, ty: Float, l1: Float, l2: Float, outward: Float) {
        var dx = tx - ax; var dy = ty - ay
        var d = sqrt(dx * dx + dy * dy)
        val maxD = l1 + l2 - 0.15f
        if (d > maxD) { val k = maxD / d; dx *= k; dy *= k; d = maxD }
        if (d < 0.5f) d = 0.5f
        val a = (l1 * l1 - l2 * l2 + d * d) / (2f * d)
        val hh = sqrt(max(l1 * l1 - a * a, 0f))
        val ux = dx / d; val uy = dy / d
        var qx = -uy; var qy = ux
        // bend towards the outside / downwards so joints look natural
        if (qx * outward + qy * 0.5f < 0f) { qx = -qx; qy = -qy }
        ik[0] = ax + ux * a + qx * hh
        ik[1] = ay + uy * a + qy * hh
        ik[2] = ax + dx
        ik[3] = ay + dy
    }

    private fun line(c: Canvas, p: Paint, x1: Float, y1: Float, x2: Float, y2: Float, wd: Float) {
        p.strokeWidth = wd
        c.drawLine(x1, y1, x2, y2, p)
    }

    // ---------------------------------------------------------------- drawing

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val s = h * 0.95f / 100f
        val b = t * 5.2f                       // main sway cycle
        val sw = sin(b)                        // -1..1 pelvis side shift
        val bob = cos(2f * b)                  // beat bounce
        val e = t * 0.7f                       // slow arm / head cycle

        // gentle travel left <-> right across the display
        val range = max(0f, w / 2f - 42f * density)
        val wanderX = range * sin(t * 0.27f)

        canvas.save()
        canvas.translate(w / 2f + wanderX, h * 0.025f)
        canvas.scale(s, s)

        // ---- skeleton
        val px = 4.2f * sw
        val hipY = 50.5f + 1.1f * bob
        val tilt = -0.09f * sw
        val scx = -1.8f * sw + 1.0f * sin(e * 1.3f)
        val scy = 16f + 0.5f * bob
        val ct = cos(tilt); val st = sin(tilt)
        val slx = scx - 8f * ct; val sly = scy - 8f * st
        val srx = scx + 8f * ct; val sry = scy + 8f * st
        val hx = scx + 1.5f * sin(e + 1f)
        val hy = scy - 10.2f + 0.3f * bob
        val headDeg = 7f * sin(e + 1f) + 3f * sw
        val wx = px * 0.45f + scx * 0.55f
        val wy = 36f + 0.4f * bob
        val shift = -2.2f * sw
        val hemY = hipY + 17.5f
        val hl = px - 12.8f + shift
        val hr = px + 12.8f + shift

        // ---- glow + sparkles
        fGlow.alpha = (190f + 60f * sin(b * 0.5f)).toInt().coerceIn(0, 255)
        canvas.drawCircle(0f, 50f, 58f, fGlow)
        for (i in 0..4) {
            val ph = (t * 0.35f + i * 0.2f) % 1f
            val sx = (i - 2) * 16f + 6f * sin(t * 1.7f + i * 2f)
            val sy = 92f - 80f * ph
            val a = (sin(ph * PI.toFloat()) * 150f).toInt().coerceIn(0, 255)
            fSpark.color = Color.argb(a, 255, 190, 215)
            canvas.drawCircle(sx, sy, 0.9f + 0.7f * ((i % 2).toFloat()), fSpark)
        }

        // ---- soft ground shadow
        val shx = px * 0.5f
        for (i in 0..2) {
            val rx = 17f - i * 4f
            rect.set(shx - rx, 99.2f + i * 0.3f, shx + rx, 103.4f - i * 0.3f)
            canvas.drawOval(rect, fShadow)
        }

        // ---- back hair
        val swing = 3.2f * sin(b - 1.0f)
        val tlx = scx - 8.5f + swing; val trx = scx + 8.5f + swing
        val tipY = 40f + 1.0f * bob
        path.reset()
        path.moveTo(hx - 5.4f, hy - 2f)
        path.cubicTo(hx - 8.2f, hy + 6f, tlx + 0.5f, 28f, tlx, tipY)
        path.quadTo((tlx + trx) / 2f - 3f, tipY + 3f + 1.6f * sin(t * 7f), (tlx + trx) / 2f, tipY + 0.5f)
        path.quadTo((tlx + trx) / 2f + 3f, tipY + 2f + 1.6f * sin(t * 7f + 1.5f), trx, tipY)
        path.cubicTo(trx - 0.5f, 28f, hx + 8.2f, hy + 6f, hx + 5.4f, hy - 2f)
        path.quadTo(hx, hy - 10f, hx - 5.4f, hy - 2f)
        path.close()
        canvas.drawPath(path, fHair)

        // ---- legs (weight shifts from foot to foot)
        val liftL = 4.5f * max(0f, sw); val liftR = 4.5f * max(0f, -sw)
        val alx = -8.5f - 1.8f * max(0f, sw); val aly = 96f - liftL
        val arx = 8.5f + 1.8f * max(0f, -sw); val ary = 96f - liftR
        val hipLx = px - 4.3f; val hipRx = px + 4.3f; val hipJy = hipY + 1.5f

        solve(hipLx, hipJy, alx, aly, 25f, 24f, -1f)
        val klx = ik[0]; val kly = ik[1]; val elx = ik[2]; val ely = ik[3]
        solve(hipRx, hipJy, arx, ary, 25f, 24f, 1f)
        val krx = ik[0]; val kry = ik[1]; val erx = ik[2]; val ery = ik[3]

        line(canvas, sLimb, hipLx, hipJy, klx, kly, 8.4f)
        line(canvas, sLimb, klx, kly, elx, ely, 5.6f)
        line(canvas, sLimb, hipRx, hipJy, krx, kry, 8.4f)
        line(canvas, sLimb, krx, kry, erx, ery, 5.6f)
        canvas.drawCircle(klx, kly, 3.1f, fSkin)
        canvas.drawCircle(krx, kry, 3.1f, fSkin)
        // shoes
        rect.set(elx - 4.2f, ely + 0.6f, elx + 2.8f, ely + 4.4f); canvas.drawOval(rect, fShoe)
        rect.set(erx - 2.8f, ery + 0.6f, erx + 4.2f, ery + 4.4f); canvas.drawOval(rect, fShoe)

        // ---- chest / shoulders (bare skin under the straps)
        path.reset()
        path.moveTo(slx, sly); path.lineTo(srx, sry)
        path.lineTo(srx - 1f, sry + 14f); path.lineTo(slx + 1f, sly + 14f); path.close()
        canvas.drawPath(path, fSkin)
        canvas.drawCircle(slx, sly + 0.4f, 3.2f, fSkin)
        canvas.drawCircle(srx, sry + 0.4f, 3.2f, fSkin)

        // ---- dress
        path.reset()
        path.moveTo(slx + 1.0f, sly + 0.3f)
        path.lineTo(scx - 3.6f, scy + 0.2f)
        path.quadTo(scx, scy + 8.5f, scx + 3.6f, scy + 0.2f)
        path.lineTo(srx - 1.0f, sry + 0.3f)
        path.cubicTo(srx, sry + 8f, wx + 6.2f, 28f, wx + 5.4f, wy)
        path.cubicTo(wx + 7f, 44f, hr - 1f, hipY + 6f, hr, hemY)
        for (i in 1..11) {
            val xf = hr + (hl - hr) * i / 12f
            val yf = hemY + 1.8f * sin(i * 1.05f + t * 6f)
            path.lineTo(xf, yf)
        }
        path.lineTo(hl, hemY)
        path.cubicTo(hl + 1f, hipY + 6f, wx - 7f, 44f, wx - 5.4f, wy)
        path.cubicTo(wx - 6.2f, 28f, slx, sly + 8f, slx + 1.0f, sly + 0.3f)
        path.close()
        canvas.drawPath(path, fDress)
        // pleats + belt
        sPleat.strokeWidth = 0.6f
        for (i in 0..4) {
            val k = (i - 2).toFloat()
            canvas.drawLine(wx + k * 2.6f, wy + 1.5f, px + shift + k * 5.2f, hemY - 1f, sPleat)
        }
        line(canvas, sBelt, wx - 5.4f, wy, wx + 5.4f, wy, 1.8f)

        // ---- arms
        val eL = smooth(0.5f + 0.5f * sin(e))
        val eR = smooth(0.5f + 0.5f * sin(e + 2.4f))
        val wLx = slx + lerp(-8f + 4f * sin(b + 0.3f), -10f + 7f * sin(b + 0.5f), eL)
        val wLy = sly + lerp(22f + 3f * cos(b), -20f + 5f * sin(2f * b + 1f), eL)
        val wRx = srx + lerp(8f + 4f * sin(b + 2.5f), 10f + 7f * sin(b + 3f), eR)
        val wRy = sry + lerp(22f + 3f * cos(b + 2f), -20f + 5f * sin(2f * b + 2f), eR)

        solve(slx, sly + 0.4f, wLx, wLy, 14.5f, 13.5f, -1f)
        drawArm(canvas, slx, sly + 0.4f)
        solve(srx, sry + 0.4f, wRx, wRy, 14.5f, 13.5f, 1f)
        drawArm(canvas, srx, sry + 0.4f)

        // ---- neck
        line(canvas, sLimb, scx, scy + 1f, hx, hy + 5.5f, 4.3f)

        // ---- head (tilts with the dance)
        canvas.save()
        canvas.rotate(headDeg, hx, hy + 6f)
        rect.set(hx - 4.7f, hy - 6.3f, hx + 4.7f, hy + 5.4f)
        canvas.drawOval(rect, fSkin)
        // cheeks
        canvas.drawCircle(hx - 3.2f, hy + 2.3f, 1.6f, fBlush)
        canvas.drawCircle(hx + 3.2f, hy + 2.3f, 1.6f, fBlush)
        // eyes with blink
        val blink = if ((t % 3.6f) < 0.12f) 0.15f else 1f
        for (side in intArrayOf(-1, 1)) {
            val ex = hx + side * 2.1f; val ey = hy + 0.2f
            rect.set(ex - 0.95f, ey - 1.0f * blink, ex + 0.95f, ey + 1.0f * blink)
            canvas.drawOval(rect, fEye)
            if (blink > 0.5f) canvas.drawCircle(ex + 0.3f, ey - 0.4f, 0.32f, fEyeHi)
            sLash.strokeWidth = 0.45f
            canvas.drawLine(ex + side * 0.9f, ey - 0.5f, ex + side * 1.7f, ey - 1.1f, sLash)
            sBrow.strokeWidth = 0.5f
            path.reset()
            path.moveTo(ex - 1.6f, ey - 2.2f); path.quadTo(ex, ey - 3.1f, ex + 1.6f, ey - 2.2f)
            canvas.drawPath(path, sBrow)
        }
        // nose + lips
        sNose.strokeWidth = 0.45f
        path.reset(); path.moveTo(hx - 0.5f, hy + 1.6f); path.quadTo(hx, hy + 2.3f, hx + 0.6f, hy + 1.7f)
        canvas.drawPath(path, sNose)
        sLips.strokeWidth = 1.0f
        path.reset(); path.moveTo(hx - 1.9f, hy + 3.4f); path.quadTo(hx, hy + 4.7f, hx + 1.9f, hy + 3.4f)
        canvas.drawPath(path, sLips)
        // fringe (side-swept)
        path.reset()
        path.moveTo(hx - 5.1f, hy + 1.8f)
        path.cubicTo(hx - 5.8f, hy - 9f, hx + 5.8f, hy - 9f, hx + 5.1f, hy + 1.8f)
        path.quadTo(hx + 4.3f, hy - 3.3f, hx + 0.8f, hy - 4.6f)
        path.quadTo(hx - 2.0f, hy - 4.4f, hx - 3.4f, hy - 2.2f)
        path.lineTo(hx - 5.1f, hy + 1.8f)
        path.close()
        canvas.drawPath(path, fHair)
        canvas.restore()

        // ---- front locks falling over the shoulders
        sLock.strokeWidth = 2.6f
        path.reset(); path.moveTo(hx - 5f, hy + 1f)
        path.quadTo(scx - 7.2f + swing * 0.4f, scy + 3f, scx - 6.6f + swing * 0.7f, 34f)
        canvas.drawPath(path, sLock)
        path.reset(); path.moveTo(hx + 5f, hy + 1f)
        path.quadTo(scx + 7.2f + swing * 0.4f, scy + 3f, scx + 6.6f + swing * 0.7f, 34f)
        canvas.drawPath(path, sLock)

        canvas.restore()
    }

    /** Draws an arm from the last solve() result (ik[0..1] elbow, ik[2..3] wrist). */
    private fun drawArm(c: Canvas, sx: Float, sy: Float) {
        val ex = ik[0]; val ey = ik[1]; val wx = ik[2]; val wy = ik[3]
        line(c, sLimb, sx, sy, ex, ey, 4.6f)
        line(c, sLimb, ex, ey, wx, wy, 3.6f)
        c.drawCircle(ex, ey, 2.1f, fSkin)
        var ux = wx - ex; var uy = wy - ey
        val d = max(sqrt(ux * ux + uy * uy), 0.01f)
        ux /= d; uy /= d
        rect.set(wx + ux * 1.6f - 2.2f, wy + uy * 1.6f - 2.5f, wx + ux * 1.6f + 2.2f, wy + uy * 1.6f + 2.5f)
        c.drawOval(rect, fSkin)
    }
}
