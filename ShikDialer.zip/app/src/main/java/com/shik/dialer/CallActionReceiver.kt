package com.shik.dialer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telecom.Call

class CallActionReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_DECLINE = "com.shik.dialer.ACTION_DECLINE"
        const val ACTION_HANGUP = "com.shik.dialer.ACTION_HANGUP"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val call = CallManager.primary ?: return
        when (intent.action) {
            ACTION_DECLINE ->
                if (call.state == Call.STATE_RINGING) call.reject(false, null) else call.disconnect()
            ACTION_HANGUP -> call.disconnect()
        }
    }
}
