package com.shik.dialer

import android.animation.ObjectAnimator
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.button.MaterialButton

/** Rounded bottom sheets: the row action menu and the add / edit contact form. */
object Sheets {

    class Item(val label: String, val icon: Int, val color: Int, val action: () -> Unit)

    private const val INK = 0xFF14161C.toInt()
    private const val GRAY = 0xFF6B7280.toInt()
    private const val GREEN = 0xFF1FC46A.toInt()

    private fun dp(ctx: Context, v: Float): Int = (v * ctx.resources.displayMetrics.density).toInt()

    private fun root(ctx: Context): LinearLayout {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.VERTICAL
        val rad = dp(ctx, 28f).toFloat()
        r.background = GradientDrawable().apply {
            setColor(Color.WHITE)
            cornerRadii = floatArrayOf(rad, rad, rad, rad, 0f, 0f, 0f, 0f)
        }
        r.setPadding(dp(ctx, 20f), dp(ctx, 10f), dp(ctx, 20f), dp(ctx, 22f))
        val handle = View(ctx)
        handle.background = GradientDrawable().apply {
            cornerRadius = dp(ctx, 3f).toFloat()
            setColor(0xFFD9DEE8.toInt())
        }
        val lp = LinearLayout.LayoutParams(dp(ctx, 44f), dp(ctx, 5f))
        lp.gravity = Gravity.CENTER_HORIZONTAL
        lp.bottomMargin = dp(ctx, 14f)
        r.addView(handle, lp)
        return r
    }

    private fun makeDialog(ctx: Context, content: View): BottomSheetDialog {
        val d = BottomSheetDialog(ctx)
        d.setContentView(content)
        (content.parent as? View)?.setBackgroundColor(Color.TRANSPARENT)
        d.setOnShowListener {
            d.behavior.skipCollapsed = true
            d.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        }
        return d
    }

    private fun title(ctx: Context, text: String, sub: String?, parent: LinearLayout) {
        val t = TextView(ctx)
        t.text = text
        t.textSize = 21f
        t.setTextColor(INK)
        t.typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        parent.addView(t)
        if (!sub.isNullOrBlank()) {
            val s = TextView(ctx)
            s.text = sub
            s.textSize = 14f
            s.setTextColor(GRAY)
            s.maxLines = 1
            s.textDirection = View.TEXT_DIRECTION_LTR
            s.gravity = Gravity.START
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(ctx, 2f)
            parent.addView(s, lp)
        }
    }

    /** Expands the sheet and lets [views] float in one after another. */
    private fun enter(ctx: Context, d: BottomSheetDialog, views: List<View>) {
        views.forEach { it.alpha = 0f }
        d.setOnShowListener {
            d.behavior.skipCollapsed = true
            d.behavior.state = BottomSheetBehavior.STATE_EXPANDED
            views.forEachIndexed { i, v ->
                v.translationY = dp(ctx, 22f).toFloat()
                v.animate().alpha(1f).translationY(0f)
                    .setStartDelay(70L + i * 55L).setDuration(300)
                    .setInterpolator(DecelerateInterpolator(1.8f))
                    .withEndAction { v.animate().setStartDelay(0) }
                    .start()
            }
        }
    }

    // ---------------------------------------------------------------- menu

    fun menu(ctx: Context, name: String, subtitle: String?, items: List<Item>) {
        val r = root(ctx)
        title(ctx, name, subtitle, r)
        val gap = View(ctx)
        r.addView(gap, LinearLayout.LayoutParams(1, dp(ctx, 10f)))
        val d = makeDialog(ctx, r)
        val rows = ArrayList<View>()
        for (item in items) {
            val row = menuRow(ctx, item) { d.dismiss() }
            rows.add(row)
            r.addView(
                row,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
                )
            )
        }
        enter(ctx, d, rows)
        d.show()
    }

    private fun menuRow(ctx: Context, item: Item, dismiss: () -> Unit): View {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(ctx, 6f), dp(ctx, 8f), dp(ctx, 6f), dp(ctx, 8f))
        val mask = GradientDrawable().apply {
            cornerRadius = dp(ctx, 18f).toFloat()
            setColor(Color.WHITE)
        }
        row.background = RippleDrawable(ColorStateList.valueOf(0x16000000), null, mask)
        row.isClickable = true
        row.isFocusable = true

        val ic = ImageView(ctx)
        ic.setImageResource(item.icon)
        ic.imageTintList = ColorStateList.valueOf(item.color)
        val p = dp(ctx, 12f)
        ic.setPadding(p, p, p, p)
        ic.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.argb(0x26, Color.red(item.color), Color.green(item.color), Color.blue(item.color)))
        }
        row.addView(ic, LinearLayout.LayoutParams(dp(ctx, 48f), dp(ctx, 48f)))

        val label = TextView(ctx)
        label.text = item.label
        label.textSize = 17f
        label.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        label.setTextColor(if (item.color == 0xFFF0524A.toInt()) item.color else INK)
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        lp.marginStart = dp(ctx, 14f)
        row.addView(label, lp)

        Anim.press(row, 0.97f)
        row.setOnClickListener {
            dismiss()
            item.action()
        }
        return row
    }

    // ---------------------------------------------------------------- form

    private fun field(ctx: Context, hint: String, value: String, type: Int, ltr: Boolean): EditText {
        val e = EditText(ctx)
        e.hint = hint
        e.setText(value)
        e.inputType = type
        e.maxLines = 1
        e.textSize = 18f
        e.setTextColor(INK)
        e.setHintTextColor(0xFF9AA3B5.toInt())
        e.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        if (ltr) e.textDirection = View.TEXT_DIRECTION_LTR
        val r = dp(ctx, 18f).toFloat()
        val w = dp(ctx, 1.5f)
        fun bg(focused: Boolean) = GradientDrawable().apply {
            cornerRadius = r
            setColor(if (focused) Color.WHITE else 0xFFF6F8FC.toInt())
            setStroke(w, if (focused) GREEN else 0xFFE3E7EF.toInt())
        }
        e.background = bg(false)
        e.setOnFocusChangeListener { _, f -> e.background = bg(f) }
        e.setPadding(dp(ctx, 18f), dp(ctx, 15f), dp(ctx, 18f), dp(ctx, 15f))
        return e
    }

    private fun shake(v: View) {
        val a = v.context.resources.displayMetrics.density * 10f
        ObjectAnimator.ofFloat(v, View.TRANSLATION_X, 0f, -a, a, -a * 0.6f, a * 0.6f, 0f)
            .setDuration(320).start()
    }

    fun contactForm(
        ctx: Context,
        heading: String,
        name: String,
        number: String,
        saveLabel: String,
        gender: Int,
        onSave: (String, String, Int) -> Unit
    ) {
        val r = root(ctx)
        title(ctx, heading, null, r)
        val nameEt = field(
            ctx, ctx.getString(R.string.contact_name), name,
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS, false
        )
        val numEt = field(
            ctx, ctx.getString(R.string.contact_number), number, InputType.TYPE_CLASS_PHONE, true
        )
        val fl = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        fl.topMargin = dp(ctx, 16f)
        r.addView(nameEt, fl)
        val fl2 = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        fl2.topMargin = dp(ctx, 12f)
        r.addView(numEt, fl2)

        // woman / man cartoon, chosen when the contact is saved
        var chosen = gender
        val gl = TextView(ctx)
        gl.text = ctx.getString(R.string.gender_title)
        gl.textSize = 14f
        gl.setTextColor(GRAY)
        val glp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        glp.topMargin = dp(ctx, 16f)
        r.addView(gl, glp)
        val chips = LinearLayout(ctx)
        chips.orientation = LinearLayout.HORIZONTAL
        val fem = chip(ctx, "👩  " + ctx.getString(R.string.gender_female), 0xFFEC4899.toInt())
        val mal = chip(ctx, "👨  " + ctx.getString(R.string.gender_male), 0xFF2F80ED.toInt())
        fun paint() {
            styleChip(ctx, fem, chosen == GENDER_FEMALE, 0xFFEC4899.toInt())
            styleChip(ctx, mal, chosen == GENDER_MALE, 0xFF2F80ED.toInt())
        }
        paint()
        fem.setOnClickListener {
            chosen = if (chosen == GENDER_FEMALE) GENDER_AUTO else GENDER_FEMALE
            paint()
            pop(fem)
        }
        mal.setOnClickListener {
            chosen = if (chosen == GENDER_MALE) GENDER_AUTO else GENDER_MALE
            paint()
            pop(mal)
        }
        chips.addView(fem, LinearLayout.LayoutParams(0, dp(ctx, 50f), 1f).apply { marginEnd = dp(ctx, 10f) })
        chips.addView(mal, LinearLayout.LayoutParams(0, dp(ctx, 50f), 1f))
        val cl = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        cl.topMargin = dp(ctx, 8f)
        r.addView(chips, cl)

        val d = makeDialog(ctx, r)
        val btns = LinearLayout(ctx)
        btns.orientation = LinearLayout.HORIZONTAL
        val cancel = MaterialButton(
            ctx, null, com.google.android.material.R.attr.materialButtonOutlinedStyle
        )
        cancel.text = ctx.getString(R.string.cancel)
        cancel.cornerRadius = dp(ctx, 28f)
        cancel.setTextColor(GRAY)
        cancel.strokeColor = ColorStateList.valueOf(0xFFE3E7EF.toInt())
        cancel.setOnClickListener { d.dismiss() }
        val save = MaterialButton(ctx)
        save.text = saveLabel
        save.textSize = 16f
        save.cornerRadius = dp(ctx, 28f)
        save.backgroundTintList = ColorStateList.valueOf(GREEN)
        save.setTextColor(Color.WHITE)
        save.setOnClickListener {
            val n = nameEt.text.toString().trim()
            val m = numEt.text.toString().trim()
            when {
                n.isEmpty() -> shake(nameEt)
                m.isEmpty() -> shake(numEt)
                else -> {
                    d.dismiss()
                    onSave(n, m, chosen)
                }
            }
        }
        Anim.press(save, 0.96f)
        Anim.press(cancel, 0.96f)
        val h = dp(ctx, 54f)
        btns.addView(cancel, LinearLayout.LayoutParams(0, h, 1f).apply { marginEnd = dp(ctx, 10f) })
        btns.addView(save, LinearLayout.LayoutParams(0, h, 2f))
        val bl = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        bl.topMargin = dp(ctx, 20f)
        r.addView(btns, bl)

        d.window?.setSoftInputMode(
            WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or
                WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
        )
        d.show()
        nameEt.requestFocus()
        nameEt.setSelection(nameEt.text.length)
    }

    private fun chip(ctx: Context, text: String, color: Int): TextView {
        val t = TextView(ctx)
        t.text = text
        t.textSize = 16f
        t.gravity = Gravity.CENTER
        t.isClickable = true
        t.isFocusable = true
        return t
    }

    private fun styleChip(ctx: Context, t: TextView, on: Boolean, color: Int) {
        t.background = GradientDrawable().apply {
            cornerRadius = dp(ctx, 18f).toFloat()
            setColor(
                if (on) Color.argb(0x22, Color.red(color), Color.green(color), Color.blue(color))
                else 0xFFF6F8FC.toInt()
            )
            setStroke(dp(ctx, 1.5f), if (on) color else 0xFFE3E7EF.toInt())
        }
        t.setTextColor(if (on) color else GRAY)
        t.typeface = Typeface.create("sans-serif-medium", if (on) Typeface.BOLD else Typeface.NORMAL)
    }

    private fun pop(v: View) {
        v.scaleX = 0.9f
        v.scaleY = 0.9f
        v.animate().scaleX(1f).scaleY(1f).setDuration(260)
            .setInterpolator(android.view.animation.OvershootInterpolator(3f)).start()
    }

    // ---------------------------------------------------------------- call details

    private fun detailRow(ctx: Context, label: String, value: String, last: Boolean): View {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(ctx, 14f), 0, dp(ctx, 14f))
        val l = TextView(ctx)
        l.text = label
        l.textSize = 14f
        l.setTextColor(GRAY)
        row.addView(l, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val v = TextView(ctx)
        v.text = value
        v.textSize = 16f
        v.setTextColor(INK)
        v.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        v.gravity = Gravity.END
        row.addView(v, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        box.addView(row)
        if (!last) {
            val line = View(ctx)
            line.setBackgroundColor(0xFFE9EDF4.toInt())
            box.addView(line, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1))
        }
        return box
    }

    fun callDetails(ctx: Context, e: Entry, onCall: () -> Unit, onSms: () -> Unit, onDelete: () -> Unit) {
        val r = root(ctx)
        val color = FaFormat.typeColor(e)
        val parts = ArrayList<View>()

        // header: type icon + name + number
        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val ic = ImageView(ctx)
        ic.setImageResource(FaFormat.typeIcon(e))
        ic.imageTintList = ColorStateList.valueOf(color)
        val ip = dp(ctx, 15f)
        ic.setPadding(ip, ip, ip, ip)
        ic.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.argb(0x26, Color.red(color), Color.green(color), Color.blue(color)))
        }
        head.addView(ic, LinearLayout.LayoutParams(dp(ctx, 58f), dp(ctx, 58f)))
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        title(ctx, e.title, e.number, col)
        head.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(ctx, 14f)
        })
        r.addView(head)
        parts.add(head)

        // type pill
        val pill = TextView(ctx)
        pill.text = FaFormat.longLabel(ctx, e)
        pill.textSize = 14f
        pill.setTextColor(color)
        pill.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        pill.setPadding(dp(ctx, 14f), dp(ctx, 6f), dp(ctx, 14f), dp(ctx, 6f))
        pill.background = GradientDrawable().apply {
            cornerRadius = dp(ctx, 20f).toFloat()
            setColor(Color.argb(0x1F, Color.red(color), Color.green(color), Color.blue(color)))
        }
        val plp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        plp.topMargin = dp(ctx, 16f)
        r.addView(pill, plp)
        parts.add(pill)

        // info card
        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(ctx, 18f), dp(ctx, 4f), dp(ctx, 18f), dp(ctx, 4f))
        card.background = GradientDrawable().apply {
            cornerRadius = dp(ctx, 22f).toFloat()
            setColor(0xFFF6F8FC.toInt())
            setStroke(dp(ctx, 1f), 0xFFEBEEF5.toInt())
        }
        card.addView(detailRow(ctx, ctx.getString(R.string.d_date), FaFormat.fullDate(e.date), false))
        card.addView(detailRow(ctx, ctx.getString(R.string.d_time), FaFormat.time(e.date), false))
        card.addView(
            detailRow(ctx, ctx.getString(R.string.d_duration), FaFormat.durationLong(ctx, e.duration), true)
        )
        val clp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        clp.topMargin = dp(ctx, 14f)
        r.addView(card, clp)
        parts.add(card)

        // actions
        val d = makeDialog(ctx, r)
        val btns = LinearLayout(ctx)
        btns.orientation = LinearLayout.HORIZONTAL
        val sms = MaterialButton(
            ctx, null, com.google.android.material.R.attr.materialButtonOutlinedStyle
        )
        sms.text = ctx.getString(R.string.menu_sms)
        sms.cornerRadius = dp(ctx, 28f)
        sms.setTextColor(0xFF2F80ED.toInt())
        sms.strokeColor = ColorStateList.valueOf(0xFFCFE0FB.toInt())
        sms.setOnClickListener {
            d.dismiss()
            onSms()
        }
        val call = MaterialButton(ctx)
        call.text = ctx.getString(R.string.menu_call)
        call.textSize = 16f
        call.cornerRadius = dp(ctx, 28f)
        call.backgroundTintList = ColorStateList.valueOf(GREEN)
        call.setTextColor(Color.WHITE)
        call.setOnClickListener {
            d.dismiss()
            onCall()
        }
        Anim.press(sms, 0.96f)
        Anim.press(call, 0.96f)
        val h = dp(ctx, 54f)
        btns.addView(sms, LinearLayout.LayoutParams(0, h, 1f).apply { marginEnd = dp(ctx, 10f) })
        btns.addView(call, LinearLayout.LayoutParams(0, h, 1.4f))
        val blp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        blp.topMargin = dp(ctx, 18f)
        r.addView(btns, blp)
        parts.add(btns)

        val del = TextView(ctx)
        del.text = ctx.getString(R.string.delete_history)
        del.textSize = 15f
        del.gravity = Gravity.CENTER
        del.setTextColor(0xFFF0524A.toInt())
        del.setPadding(0, dp(ctx, 12f), 0, dp(ctx, 4f))
        del.setOnClickListener {
            d.dismiss()
            onDelete()
        }
        r.addView(del, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        parts.add(del)

        enter(ctx, d, parts)
        d.show()
    }
}
