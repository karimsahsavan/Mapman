package com.shik.dialer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.graphics.Bitmap
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import androidx.core.app.NotificationCompat
import androidx.core.app.Person
import androidx.core.graphics.drawable.IconCompat

class DialerInCallService : InCallService(), CallManager.Listener {

    companion object {
        private const val CH_INCOMING = "incoming_calls"
        private const val CH_ONGOING = "ongoing_calls"
        private const val NOTIF_ID = 1001
        private const val PI_FLAGS = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    }

    private val nm: NotificationManager by lazy {
        getSystemService(NotificationManager::class.java)
    }

    private var avatarKey: String? = null
    private var avatarBmp: Bitmap? = null

    /** Contact photo, or the cartoon avatar when there is no photo, as a round bitmap. */
    private fun avatarFor(number: String, name: String): Bitmap? {
        return try {
            val photo = PhotoStore.get(this, number)
            val key = PhotoStore.key(number).ifEmpty { name }
            val g = Genders.get(this, number)
            val id = key + "#" + g + "#" + System.identityHashCode(photo)
            val cached = avatarBmp
            if (cached != null && id == avatarKey) return cached
            val size = (resources.displayMetrics.density * 128f).toInt()
            val bmp = AvatarBitmap.make(this, key, photo, size, g)
            avatarKey = id
            avatarBmp = bmp
            bmp
        } catch (e: Exception) {
            null
        }
    }

    override fun onCreate() {
        super.onCreate()
        CallManager.service = this
        CallManager.addListener(this)

        val incoming = NotificationChannel(
            CH_INCOMING, getString(R.string.incoming), NotificationManager.IMPORTANCE_HIGH
        )
        incoming.setSound(null, null)
        incoming.enableVibration(false)
        nm.createNotificationChannel(incoming)

        val ongoing = NotificationChannel(
            CH_ONGOING, getString(R.string.ongoing), NotificationManager.IMPORTANCE_LOW
        )
        nm.createNotificationChannel(ongoing)
    }

    override fun onDestroy() {
        Ringer.stop()
        CallManager.removeListener(this)
        CallManager.service = null
        nm.cancel(NOTIF_ID)
        super.onDestroy()
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        CallManager.add(call) // triggers onChanged -> notification
        try {
            startActivity(
                Intent(this, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            // Background start can be blocked; the notification covers this case.
        }
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        CallManager.remove(call)
    }

    override fun onCallAudioStateChanged(audioState: CallAudioState?) {
        super.onCallAudioStateChanged(audioState)
        CallManager.notifyChanged()
    }

    override fun onChanged() {
        updateNotification()
    }

    private fun updateNotification() {
        val call = CallManager.primary
        if (call == null || call.state == Call.STATE_DISCONNECTED) {
            Ringer.stop()
            nm.cancel(NOTIF_ID)
            return
        }
        if (call.state == Call.STATE_RINGING) Ringer.start(this) else Ringer.stop()
        val number = CallManager.numberOf(call)
        val name = ContactUtils.lookupName(this, number)
            ?: number.ifBlank { getString(R.string.unknown) }

        val openPi = PendingIntent.getActivity(
            this, 0,
            Intent(this, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PI_FLAGS
        )
        val avatar = avatarFor(number, name)
        if (call.state == Call.STATE_RINGING) showIncoming(name, avatar, openPi)
        else showOngoing(call, name, avatar, openPi)
    }

    private fun showIncoming(name: String, avatar: Bitmap?, openPi: PendingIntent) {
        val answerPi = PendingIntent.getActivity(
            this, 1,
            Intent(this, AnswerActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PI_FLAGS
        )
        val declinePi = PendingIntent.getBroadcast(
            this, 2,
            Intent(this, CallActionReceiver::class.java).setAction(CallActionReceiver.ACTION_DECLINE),
            PI_FLAGS
        )
        try {
            val pb = Person.Builder().setName(name).setImportant(true)
            if (avatar != null) pb.setIcon(IconCompat.createWithBitmap(avatar))
            val person = pb.build()
            val n = NotificationCompat.Builder(this, CH_INCOMING)
                .setSmallIcon(R.drawable.ic_call)
                .setLargeIcon(avatar)
                .setContentText(getString(R.string.incoming))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(openPi)
                .setFullScreenIntent(openPi, true)
                .setStyle(NotificationCompat.CallStyle.forIncomingCall(person, declinePi, answerPi))
                .build()
            nm.notify(NOTIF_ID, n)
        } catch (e: Exception) {
            try {
                val n = NotificationCompat.Builder(this, CH_INCOMING)
                    .setSmallIcon(R.drawable.ic_call)
                    .setLargeIcon(avatar)
                    .setContentTitle(name)
                    .setContentText(getString(R.string.incoming))
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setCategory(NotificationCompat.CATEGORY_CALL)
                    .setOngoing(true)
                    .setOnlyAlertOnce(true)
                    .setContentIntent(openPi)
                    .setFullScreenIntent(openPi, true)
                    .addAction(0, getString(R.string.decline), declinePi)
                    .addAction(0, getString(R.string.answer), answerPi)
                    .build()
                nm.notify(NOTIF_ID, n)
            } catch (e2: Exception) {
            }
        }
    }

    private fun showOngoing(call: Call, name: String, avatar: Bitmap?, openPi: PendingIntent) {
        val hangPi = PendingIntent.getBroadcast(
            this, 3,
            Intent(this, CallActionReceiver::class.java).setAction(CallActionReceiver.ACTION_HANGUP),
            PI_FLAGS
        )
        val state = call.state
        val text = when (state) {
            Call.STATE_HOLDING -> getString(R.string.on_hold)
            Call.STATE_ACTIVE -> getString(R.string.ongoing)
            else -> getString(R.string.calling)
        }
        try {
            val b = NotificationCompat.Builder(this, CH_ONGOING)
                .setSmallIcon(R.drawable.ic_call)
                .setLargeIcon(avatar)
                .setContentTitle(name)
                .setContentText(text)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(openPi)
                .addAction(0, getString(R.string.hangup), hangPi)
            val start = call.details?.connectTimeMillis ?: 0L
            if (state == Call.STATE_ACTIVE && start > 0L) {
                b.setUsesChronometer(true).setWhen(start)
            }
            nm.notify(NOTIF_ID, b.build())
        } catch (e: Exception) {
        }
    }
}
