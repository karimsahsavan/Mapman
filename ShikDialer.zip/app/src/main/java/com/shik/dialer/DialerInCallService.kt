package com.shik.dialer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import androidx.core.app.NotificationCompat
import androidx.core.app.Person

class DialerInCallService : InCallService(), CallManager.Listener {

    companion object {
        private const val CH_INCOMING = "incoming_calls"
        private const val CH_ONGOING = "ongoing_calls"
        private const val NOTIF_ID = 1001
        private const val PI_FLAGS = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    }

    private val nm: NotificationManager by lazy {
        getSystemService(NotificationManager::class.java)
    }

    override fun onCreate() {
        super.onCreate()
        CallManager.service = this
        CallManager.addListener(this)

        val incoming = NotificationChannel(
            CH_INCOMING, getString(R.string.incoming), NotificationManager.IMPORTANCE_HIGH
        )
        incoming.setSound(null, null)
        incoming.enableVibration(false)
        nm.createNotificationChannel(incoming)

        val ongoing = NotificationChannel(
            CH_ONGOING, getString(R.string.ongoing), NotificationManager.IMPORTANCE_LOW
        )
        nm.createNotificationChannel(ongoing)
    }

    override fun onDestroy() {
        CallManager.removeListener(this)
        CallManager.service = null
        nm.cancel(NOTIF_ID)
        super.onDestroy()
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        CallManager.add(call) // triggers onChanged -> notification
        try {
            startActivity(
                Intent(this, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            // Background start can be blocked; the notification covers this case.
        }
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        CallManager.remove(call)
    }

    override fun onCallAudioStateChanged(audioState: CallAudioState?) {
        super.onCallAudioStateChanged(audioState)
        CallManager.notifyChanged()
    }

    override fun onChanged() {
        updateNotification()
    }

    private fun updateNotification() {
        val call = CallManager.primary
        if (call == null || call.state == Call.STATE_DISCONNECTED) {
            nm.cancel(NOTIF_ID)
            return
        }
        val number = CallManager.numberOf(call)
        val name = ContactUtils.lookupName(this, number)
            ?: number.ifBlank { getString(R.string.unknown) }

        val openPi = PendingIntent.getActivity(
            this, 0,
            Intent(this, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PI_FLAGS
        )
        if (call.state == Call.STATE_RINGING) showIncoming(name, openPi)
        else showOngoing(call, name, openPi)
    }

    private fun showIncoming(name: String, openPi: PendingIntent) {
        val answerPi = PendingIntent.getActivity(
            this, 1,
            Intent(this, AnswerActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PI_FLAGS
        )
        val declinePi = PendingIntent.getBroadcast(
            this, 2,
            Intent(this, CallActionReceiver::class.java).setAction(CallActionReceiver.ACTION_DECLINE),
            PI_FLAGS
        )
        try {
            val person = Person.Builder().setName(name).setImportant(true).build()
            val n = NotificationCompat.Builder(this, CH_INCOMING)
                .setSmallIcon(R.drawable.ic_call)
                .setContentText(getString(R.string.incoming))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(openPi)
                .setFullScreenIntent(openPi, true)
                .setStyle(NotificationCompat.CallStyle.forIncomingCall(person, declinePi, answerPi))
                .build()
            nm.notify(NOTIF_ID, n)
        } catch (e: Exception) {
            try {
                val n = NotificationCompat.Builder(this, CH_INCOMING)
                    .setSmallIcon(R.drawable.ic_call)
                    .setContentTitle(name)
                    .setContentText(getString(R.string.incoming))
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setCategory(NotificationCompat.CATEGORY_CALL)
                    .setOngoing(true)
                    .setOnlyAlertOnce(true)
                    .setContentIntent(openPi)
                    .setFullScreenIntent(openPi, true)
                    .addAction(0, getString(R.string.decline), declinePi)
                    .addAction(0, getString(R.string.answer), answerPi)
                    .build()
                nm.notify(NOTIF_ID, n)
            } catch (e2: Exception) {
            }
        }
    }

    private fun showOngoing(call: Call, name: String, openPi: PendingIntent) {
        val hangPi = PendingIntent.getBroadcast(
            this, 3,
            Intent(this, CallActionReceiver::class.java).setAction(CallActionReceiver.ACTION_HANGUP),
            PI_FLAGS
        )
        val state = call.state
        val text = when (state) {
            Call.STATE_HOLDING -> getString(R.string.on_hold)
            Call.STATE_ACTIVE -> getString(R.string.ongoing)
            else -> getString(R.string.calling)
        }
        try {
            val b = NotificationCompat.Builder(this, CH_ONGOING)
                .setSmallIcon(R.drawable.ic_call)
                .setContentTitle(name)
                .setContentText(text)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(openPi)
                .addAction(0, getString(R.string.hangup), hangPi)
            val start = call.details?.connectTimeMillis ?: 0L
            if (state == Call.STATE_ACTIVE && start > 0L) {
                b.setUsesChronometer(true).setWhen(start)
            }
            nm.notify(NOTIF_ID, b.build())
        } catch (e: Exception) {
        }
    }
}
