package com.shik.dialer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import androidx.core.app.NotificationCompat

class DialerInCallService : InCallService() {

    companion object {
        private const val CHANNEL = "incoming_calls"
        private const val NOTIF_ID = 1001
    }

    private val nm: NotificationManager by lazy {
        getSystemService(NotificationManager::class.java)
    }

    private val stateCallback = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            if (state != Call.STATE_RINGING) nm.cancel(NOTIF_ID)
        }
    }

    override fun onCreate() {
        super.onCreate()
        CallManager.service = this
        val ch = NotificationChannel(
            CHANNEL,
            getString(R.string.incoming),
            NotificationManager.IMPORTANCE_HIGH
        )
        ch.setSound(null, null)
        ch.enableVibration(false)
        nm.createNotificationChannel(ch)
    }

    override fun onDestroy() {
        CallManager.service = null
        super.onDestroy()
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        call.registerCallback(stateCallback)
        CallManager.add(call)

        val intent = Intent(this, InCallActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        if (call.state == Call.STATE_RINGING) {
            showIncomingNotification(call, intent)
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            // Background start may be blocked; the full-screen notification covers this case.
        }
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        call.unregisterCallback(stateCallback)
        CallManager.remove(call)
        nm.cancel(NOTIF_ID)
    }

    override fun onCallAudioStateChanged(audioState: CallAudioState?) {
        super.onCallAudioStateChanged(audioState)
        CallManager.notifyChanged()
    }

    private fun showIncomingNotification(call: Call, intent: Intent) {
        val number = CallManager.numberOf(call)
        val name = ContactUtils.lookupName(this, number)
            ?: number.ifBlank { getString(R.string.unknown) }
        val pi = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_call)
            .setContentTitle(name)
            .setContentText(getString(R.string.incoming))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setOngoing(true)
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .build()
        try {
            nm.notify(NOTIF_ID, n)
        } catch (e: Exception) {
        }
    }
}
