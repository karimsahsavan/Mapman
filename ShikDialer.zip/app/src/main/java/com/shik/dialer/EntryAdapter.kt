package com.shik.dialer

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.content.res.ColorStateList
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class EntryAdapter(
    private val onClick: (Entry) -> Unit,
    private val onAvatar: (Entry) -> Unit,
    private val onMenu: (Entry) -> Unit,
    private val large: Boolean = false,
    private val recents: Boolean = false,
    private val onInfo: ((Entry) -> Unit)? = null
) : RecyclerView.Adapter<EntryAdapter.VH>() {

    private var items: List<Entry> = emptyList()

    fun submit(list: List<Entry>) {
        items = list
        notifyDataSetChanged()
    }

    fun itemAt(pos: Int): Entry? = items.getOrNull(pos)

    /** Re-binds every row (used after a contact photo changes). */
    fun refresh() {
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val avatar: AvatarView = v.findViewById(R.id.avatar)
        val title: TextView = v.findViewById(R.id.title)
        val subtitle: TextView = v.findViewById(R.id.subtitle)
        val typeIcon: ImageView? = v.findViewById(R.id.typeIcon)
        val time: TextView? = v.findViewById(R.id.time)
        val dateText: TextView? = v.findViewById(R.id.dateText)
        val info: ImageButton? = v.findViewById(R.id.btnInfo)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val layout = when {
            recents -> R.layout.item_recent
            large -> R.layout.item_entry_large
            else -> R.layout.item_entry
        }
        return VH(LayoutInflater.from(parent.context).inflate(layout, parent, false))
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val e = items[position]
        val ctx = holder.itemView.context
        val key = PhotoStore.key(e.number).ifEmpty { e.title }
        holder.avatar.setPerson(key, PhotoStore.get(ctx, e.number), Genders.get(ctx, e.number))
        holder.avatar.setOnClickListener { onAvatar(e) }
        holder.title.text = e.title
        holder.title.setTextColor(if (e.missed) 0xFFF0524A.toInt() else 0xFF14161C.toInt())

        if (recents) {
            val color = FaFormat.typeColor(e)
            holder.subtitle.text = FaFormat.summary(ctx, e)
            holder.subtitle.setTextColor(if (e.missed) color else 0xFF6B7280.toInt())
            holder.typeIcon?.setImageResource(FaFormat.typeIcon(e))
            holder.typeIcon?.imageTintList = ColorStateList.valueOf(color)
            holder.time?.text = FaFormat.time(e.date)
            holder.dateText?.text = FaFormat.shortDate(ctx, e.date)
            holder.info?.let { b ->
                Anim.press(b, 0.85f)
                b.setOnClickListener { onInfo?.invoke(e) }
            }
        } else {
            holder.subtitle.text = e.subtitle
        }

        Anim.press(holder.itemView, 0.97f)
        holder.itemView.setOnClickListener { onClick(e) }
        holder.itemView.setOnLongClickListener {
            onMenu(e)
            true
        }
    }
}
