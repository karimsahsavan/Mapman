package com.shik.dialer

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class EntryAdapter(
    private val onClick: (Entry) -> Unit,
    private val onAvatar: (Entry) -> Unit,
    private val onMenu: (Entry) -> Unit
) : RecyclerView.Adapter<EntryAdapter.VH>() {

    private var items: List<Entry> = emptyList()

    fun submit(list: List<Entry>) {
        items = list
        notifyDataSetChanged()
    }

    fun itemAt(pos: Int): Entry? = items.getOrNull(pos)

    /** Re-binds every row (used after a contact photo changes). */
    fun refresh() {
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val avatar: AvatarView = v.findViewById(R.id.avatar)
        val title: TextView = v.findViewById(R.id.title)
        val subtitle: TextView = v.findViewById(R.id.subtitle)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_entry, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val e = items[position]
        val key = PhotoStore.key(e.number).ifEmpty { e.title }
        holder.avatar.setPerson(key, PhotoStore.get(holder.itemView.context, e.number))
        holder.avatar.setOnClickListener { onAvatar(e) }
        holder.title.text = e.title
        holder.subtitle.text = e.subtitle
        holder.title.setTextColor(if (e.missed) 0xFFF0524A.toInt() else 0xFF14161C.toInt())
        Anim.press(holder.itemView, 0.97f)
        holder.itemView.setOnClickListener { onClick(e) }
        holder.itemView.setOnLongClickListener {
            onMenu(e)
            true
        }
    }
}
