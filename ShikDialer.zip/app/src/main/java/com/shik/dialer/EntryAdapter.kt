package com.shik.dialer

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class EntryAdapter(private val onClick: (Entry) -> Unit) :
    RecyclerView.Adapter<EntryAdapter.VH>() {

    private var items: List<Entry> = emptyList()

    fun submit(list: List<Entry>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val avatar: TextView = v.findViewById(R.id.avatar)
        val title: TextView = v.findViewById(R.id.title)
        val subtitle: TextView = v.findViewById(R.id.subtitle)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_entry, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val e = items[position]
        val first = e.title.trim().firstOrNull()
        holder.avatar.text =
            if (first != null && first.isLetter()) first.uppercaseChar().toString() else "#"
        holder.title.text = e.title
        holder.subtitle.text = e.subtitle
        holder.title.setTextColor(if (e.missed) 0xFFF0524A.toInt() else 0xFFFFFFFF.toInt())
        holder.itemView.setOnClickListener { onClick(e) }
    }
}
