package com.shik.dialer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.util.LruCache
import java.io.File
import kotlin.math.max
import kotlin.math.min

/**
 * Stores a custom photo per phone number inside the app's private storage.
 * Numbers are matched by their last 10 digits so "+98912..." and "0912..." share one photo.
 */
object PhotoStore {

    private const val SIZE = 320
    private val cache = LruCache<String, Bitmap>(48)

    fun key(number: String): String {
        val digits = number.filter { it.isDigit() }
        return if (digits.length > 10) digits.takeLast(10) else digits
    }

    private fun file(ctx: Context, k: String): File {
        val dir = File(ctx.filesDir, "photos")
        if (!dir.exists()) dir.mkdirs()
        return File(dir, "$k.jpg")
    }

    fun has(ctx: Context, number: String): Boolean {
        val k = key(number)
        return k.isNotEmpty() && file(ctx, k).exists()
    }

    fun get(ctx: Context, number: String): Bitmap? {
        val k = key(number)
        if (k.isEmpty()) return null
        cache.get(k)?.let { return it }
        val f = file(ctx, k)
        if (!f.exists()) return null
        var b: Bitmap? = null
        try {
            b = BitmapFactory.decodeFile(f.path)
        } catch (e: Exception) {
        }
        if (b != null) cache.put(k, b)
        return b
    }

    /** Decodes, center-crops to a square, downsizes and saves. Call from a background thread. */
    fun save(ctx: Context, number: String, uri: Uri): Boolean {
        val k = key(number)
        if (k.isEmpty()) return false
        return try {
            val src = ImageDecoder.createSource(ctx.contentResolver, uri)
            val bmp = ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val longest = max(info.size.width, info.size.height)
                if (longest > 1024) {
                    val f = 1024f / longest
                    decoder.setTargetSize(
                        max(1, (info.size.width * f).toInt()),
                        max(1, (info.size.height * f).toInt())
                    )
                }
            }
            val side = min(bmp.width, bmp.height)
            val square = Bitmap.createBitmap(
                bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side
            )
            val out = Bitmap.createScaledBitmap(square, SIZE, SIZE, true)
            file(ctx, k).outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            cache.put(k, out)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun remove(ctx: Context, number: String) {
        val k = key(number)
        if (k.isEmpty()) return
        cache.remove(k)
        file(ctx, k).delete()
    }
}
