package com.shik.dialer

import android.Manifest
import android.content.ContentProviderOperation
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.database.ContentObserver
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.TelecomManager
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var pageKeypad: View
    private lateinit var pageRecents: View
    private lateinit var pageContacts: View
    private lateinit var display: TextView
    private lateinit var banner: View
    private lateinit var bannerOverlay: View
    private lateinit var nav: BottomNavigationView
    private lateinit var searchBox: EditText
    private lateinit var emptyRecents: View
    private lateinit var emptyContacts: View

    private val number = StringBuilder()
    private val recentsAdapter = EntryAdapter(
        { place(it.number) }, { showPhotoDialog(it) }, { showMenu(it, false) }
    )
    private val contactsAdapter = EntryAdapter(
        { place(it.number) }, { showPhotoDialog(it) }, { showMenu(it, true) }
    )
    private lateinit var btnAddFromKeypad: View
    private var pendingPhotoNumber: String? = null
    private var allContacts: List<Entry> = emptyList()
    private var allRecents: List<Entry> = emptyList()
    private var loadGen = 0
    private val uiHandler = Handler(Looper.getMainLooper())
    private val reloadRunnable = Runnable { loadData() }
    private val dbObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            uiHandler.removeCallbacks(reloadRunnable)
            uiHandler.postDelayed(reloadRunnable, 200)
        }
    }

    private val tone: ToneGenerator? = try {
        ToneGenerator(AudioManager.STREAM_DTMF, 60)
    } catch (e: Exception) {
        null
    }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            loadData()
        }

    private val pickPhoto =
        registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            val num = pendingPhotoNumber
            if (uri != null && !num.isNullOrBlank()) {
                Thread {
                    val ok = PhotoStore.save(this, num, uri)
                    runOnUiThread {
                        if (ok) {
                            recentsAdapter.refresh()
                            contactsAdapter.refresh()
                        } else {
                            Toast.makeText(this, R.string.photo_failed, Toast.LENGTH_SHORT).show()
                        }
                    }
                }.start()
            }
        }

    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            updateBanner()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        pendingPhotoNumber = savedInstanceState?.getString("pendingPhotoNumber")

        pageKeypad = findViewById(R.id.pageKeypad)
        pageRecents = findViewById(R.id.pageRecents)
        pageContacts = findViewById(R.id.pageContacts)
        display = findViewById(R.id.display)
        banner = findViewById(R.id.bannerDefault)
        bannerOverlay = findViewById(R.id.bannerOverlay)
        nav = findViewById(R.id.nav)
        searchBox = findViewById(R.id.searchBox)
        emptyRecents = findViewById(R.id.emptyRecents)
        emptyContacts = findViewById(R.id.emptyContacts)

        val listRecents = findViewById<RecyclerView>(R.id.listRecents).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = recentsAdapter
        }
        val listContacts = findViewById<RecyclerView>(R.id.listContacts).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = contactsAdapter
        }
        ItemTouchHelper(
            SwipeHandler(this, { recentsAdapter.itemAt(it) }) { a, e -> doSwipe(a, e, false) }
        ).attachToRecyclerView(listRecents)
        ItemTouchHelper(
            SwipeHandler(this, { contactsAdapter.itemAt(it) }) { a, e -> doSwipe(a, e, true) }
        ).attachToRecyclerView(listContacts)

        btnAddFromKeypad = findViewById(R.id.btnAddFromKeypad)
        btnAddFromKeypad.setOnClickListener { showAddContact(number.toString()) }
        Anim.press(findViewById<View>(R.id.btnAddContact), 0.88f)
        findViewById<View>(R.id.btnAddContact).setOnClickListener { showAddContact("") }

        buildKeypad()

        Anim.press(findViewById<View>(R.id.btnCall), 0.88f)
        Anim.press(findViewById<View>(R.id.btnBackspace), 0.85f)
        Anim.press(findViewById<View>(R.id.btnSetDefault), 0.95f)
        Anim.press(findViewById<View>(R.id.btnOverlay), 0.95f)

        findViewById<ImageButton>(R.id.btnBackspace).apply {
            setOnClickListener {
                if (number.isNotEmpty()) number.deleteCharAt(number.length - 1)
                updateDisplay()
            }
            setOnLongClickListener {
                number.clear()
                updateDisplay()
                true
            }
        }
        findViewById<View>(R.id.btnCall).setOnClickListener { place(number.toString()) }
        findViewById<View>(R.id.btnSetDefault).setOnClickListener { requestDefault() }
        findViewById<View>(R.id.btnOverlay).setOnClickListener {
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            } catch (e: Exception) {
            }
        }

        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                applyFilter()
            }
        })

        nav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_keypad -> show(0)
                R.id.nav_recents -> show(1)
                R.id.nav_contacts -> show(2)
                R.id.nav_settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java))
                    return@setOnItemSelectedListener false
                }
            }
            true
        }
        nav.selectedItemId = R.id.nav_keypad

        handleIntent(intent)
        requestPermissionsIfNeeded()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("pendingPhotoNumber", pendingPhotoNumber)
    }

    override fun onResume() {
        super.onResume()
        AvatarClock.reaction = Prefs.reaction(this)
        recentsAdapter.refresh()
        contactsAdapter.refresh()
        updateBanner()
        loadData()
    }

    override fun onStart() {
        super.onStart()
        try {
            contentResolver.registerContentObserver(ContactsContract.Contacts.CONTENT_URI, true, dbObserver)
            contentResolver.registerContentObserver(CallLog.Calls.CONTENT_URI, true, dbObserver)
        } catch (e: Exception) {
        }
    }

    override fun onStop() {
        try {
            contentResolver.unregisterContentObserver(dbObserver)
        } catch (e: Exception) {
        }
        uiHandler.removeCallbacks(reloadRunnable)
        super.onStop()
    }

    override fun onDestroy() {
        tone?.release()
        super.onDestroy()
    }

    // ---------- navigation ----------

    private fun show(index: Int) {
        val pages = listOf(pageKeypad, pageRecents, pageContacts)
        pages.forEachIndexed { i, p ->
            p.visibility = if (i == index) View.VISIBLE else View.GONE
        }
        pages[index].alpha = 0f
        pages[index].animate().alpha(1f).setDuration(220).start()
    }

    private fun handleIntent(i: Intent?) {
        val data: Uri? = i?.data
        if (data != null && data.scheme == "tel") {
            number.clear()
            number.append(data.schemeSpecificPart ?: "")
            updateDisplay()
            nav.selectedItemId = R.id.nav_keypad
        }
    }

    // ---------- keypad ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildKeypad() {
        val container = findViewById<LinearLayout>(R.id.keysContainer)
        val rows = listOf(
            listOf("1" to "", "2" to "ABC", "3" to "DEF"),
            listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
            listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ"),
            listOf("*" to "", "0" to "+", "#" to "")
        )
        for (r in rows) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            container.addView(
                row,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            )
            for ((digit, letters) in r) {
                val key = LayoutInflater.from(this).inflate(R.layout.item_key, row, false)
                key.findViewById<TextView>(R.id.keyDigit).text = digit
                key.findViewById<TextView>(R.id.keyLetters).text = letters
                val lp = key.layoutParams as LinearLayout.LayoutParams
                lp.setMargins(dp(5), dp(5), dp(5), dp(5))
                Anim.press(key, 0.92f)
                key.setOnClickListener {
                    append(digit)
                }
                if (digit == "0") {
                    key.setOnLongClickListener {
                        append("+")
                        true
                    }
                }
                row.addView(key)
            }
        }
    }

    private fun append(ch: String) {
        number.append(ch)
        updateDisplay()
        try {
            val t = when (ch) {
                "*" -> ToneGenerator.TONE_DTMF_S
                "#" -> ToneGenerator.TONE_DTMF_P
                "+" -> -1
                else -> ch.toInt() + ToneGenerator.TONE_DTMF_0
            }
            if (t >= 0) tone?.startTone(t, 100)
        } catch (e: Exception) {
        }
    }

    private fun updateDisplay() {
        display.text = formatNumber(number.toString())
        btnAddFromKeypad.visibility = if (number.isEmpty()) View.INVISIBLE else View.VISIBLE
        display.scaleX = 1.07f
        display.scaleY = 1.07f
        display.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
    }

    /** 09121234567 -> 0912 123 4567 (display only; the dialed number stays unchanged). */
    private fun formatNumber(n: String): String {
        if (n.length > 4 && n.startsWith("09") && n.all { it.isDigit() }) {
            val sb = StringBuilder()
            for ((i, ch) in n.withIndex()) {
                if (i == 4 || i == 7) sb.append(' ')
                sb.append(ch)
            }
            return sb.toString()
        }
        return n
    }

    // ---------- contact photos ----------

    private fun showPhotoDialog(e: Entry) {
        if (PhotoStore.key(e.number).isEmpty()) return
        val labels = ArrayList<String>()
        labels.add(getString(R.string.photo_pick))
        val hasPhoto = PhotoStore.has(this, e.number)
        if (hasPhoto) labels.add(getString(R.string.photo_remove))
        AlertDialog.Builder(this)
            .setTitle(e.title)
            .setItems(labels.toTypedArray()) { _, which ->
                if (which == 0) {
                    choosePhoto(e)
                } else {
                    PhotoStore.remove(this, e.number)
                    recentsAdapter.refresh()
                    contactsAdapter.refresh()
                }
            }
            .show()
    }

    // ---------- row menu, swipe actions ----------

    private fun toast(res: Int) {
        Toast.makeText(this, res, Toast.LENGTH_SHORT).show()
    }

    private fun sms(num: String) {
        if (num.isBlank()) return
        try {
            startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(num))))
        } catch (e: Exception) {
            toast(R.string.sms_failed)
        }
    }

    private fun doSwipe(action: Int, e: Entry, fromContacts: Boolean) {
        when (action) {
            Prefs.SW_CALL -> place(e.number)
            Prefs.SW_SMS -> sms(e.number)
            Prefs.SW_DELETE ->
                if (fromContacts) confirmDeleteContact(e) else deleteLog(e)
        }
    }

    private fun choosePhoto(e: Entry) {
        pendingPhotoNumber = e.number
        pickPhoto.launch(
            PickVisualMediaRequest.Builder()
                .setMediaType(ActivityResultContracts.PickVisualMedia.ImageOnly)
                .build()
        )
    }

    private fun showMenu(e: Entry, fromContacts: Boolean) {
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        labels.add(getString(R.string.menu_call)); acts.add { place(e.number) }
        labels.add(getString(R.string.menu_sms)); acts.add { sms(e.number) }
        if (PhotoStore.key(e.number).isNotEmpty()) {
            labels.add(getString(R.string.photo_pick)); acts.add { choosePhoto(e) }
            if (PhotoStore.has(this, e.number)) {
                labels.add(getString(R.string.photo_remove))
                acts.add {
                    PhotoStore.remove(this, e.number)
                    recentsAdapter.refresh()
                    contactsAdapter.refresh()
                }
            }
        }
        if (fromContacts) {
            labels.add(getString(R.string.delete_contact)); acts.add { confirmDeleteContact(e) }
        } else {
            if (!e.saved && e.number.isNotBlank()) {
                labels.add(getString(R.string.add_to_contacts))
                acts.add { showAddContact(e.number) }
            }
            labels.add(getString(R.string.delete_history)); acts.add { deleteLog(e) }
        }
        AlertDialog.Builder(this)
            .setTitle(e.title)
            .setItems(labels.toTypedArray()) { _, which -> acts[which]() }
            .show()
    }

    // ---------- add / delete contacts ----------

    private fun showAddContact(prefillNumber: String) {
        val pad = dp(22)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(pad, dp(8), pad, 0)
        val nameEt = EditText(this)
        nameEt.hint = getString(R.string.contact_name)
        nameEt.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
        nameEt.maxLines = 1
        val numEt = EditText(this)
        numEt.hint = getString(R.string.contact_number)
        numEt.inputType = InputType.TYPE_CLASS_PHONE
        numEt.maxLines = 1
        numEt.textDirection = View.TEXT_DIRECTION_LTR
        numEt.setText(prefillNumber)
        box.addView(nameEt)
        box.addView(numEt)
        AlertDialog.Builder(this)
            .setTitle(R.string.add_contact)
            .setView(box)
            .setPositiveButton(R.string.save) { _, _ ->
                saveContact(nameEt.text.toString().trim(), numEt.text.toString().trim())
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun saveContact(name: String, num: String) {
        if (name.isEmpty() || num.isEmpty()) {
            toast(R.string.contact_incomplete)
            return
        }
        if (!has(Manifest.permission.WRITE_CONTACTS)) {
            // no write permission yet: ask for it, and meanwhile open the system editor
            permLauncher.launch(arrayOf(Manifest.permission.WRITE_CONTACTS))
            try {
                startActivity(
                    Intent(ContactsContract.Intents.Insert.ACTION).apply {
                        type = ContactsContract.RawContacts.CONTENT_TYPE
                        putExtra(ContactsContract.Intents.Insert.NAME, name)
                        putExtra(ContactsContract.Intents.Insert.PHONE, num)
                    }
                )
            } catch (e: Exception) {
                toast(R.string.contact_failed)
            }
            return
        }
        applyOptimistic(name, num)
        Thread {
            val ok = try {
                val ops = ArrayList<ContentProviderOperation>()
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                        .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                        .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                        .build()
                )
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(
                            ContactsContract.Data.MIMETYPE,
                            ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE
                        )
                        .withValue(
                            ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, name
                        )
                        .build()
                )
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(
                            ContactsContract.Data.MIMETYPE,
                            ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE
                        )
                        .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, num)
                        .withValue(
                            ContactsContract.CommonDataKinds.Phone.TYPE,
                            ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE
                        )
                        .build()
                )
                contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
                true
            } catch (e: Exception) {
                false
            }
            runOnUiThread {
                toast(if (ok) R.string.contact_saved else R.string.contact_failed)
                if (ok) loadData()
            }
        }.start()
    }

    private fun confirmDeleteContact(e: Entry) {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_contact)
            .setMessage(getString(R.string.delete_contact_msg, e.title))
            .setPositiveButton(R.string.delete) { _, _ -> deleteContact(e) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun deleteContact(e: Entry) {
        if (!has(Manifest.permission.WRITE_CONTACTS)) {
            toast(R.string.need_write_perm)
            permLauncher.launch(arrayOf(Manifest.permission.WRITE_CONTACTS))
            return
        }
        Thread {
            val ok = try {
                val key = e.lookupKey
                if (key.isNullOrEmpty() || e.contactId == 0L) false
                else {
                    val uri = ContactsContract.Contacts.getLookupUri(e.contactId, key)
                    contentResolver.delete(uri, null, null) > 0
                }
            } catch (ex: Exception) {
                false
            }
            runOnUiThread {
                if (ok) {
                    PhotoStore.remove(this, e.number)
                    toast(R.string.contact_deleted)
                    loadData()
                } else toast(R.string.delete_failed)
            }
        }.start()
    }

    private fun deleteLog(e: Entry) {
        if (!has(Manifest.permission.WRITE_CALL_LOG)) {
            toast(R.string.need_write_perm)
            permLauncher.launch(arrayOf(Manifest.permission.WRITE_CALL_LOG))
            return
        }
        Thread {
            val ok = try {
                contentResolver.delete(
                    CallLog.Calls.CONTENT_URI,
                    CallLog.Calls._ID + "=?",
                    arrayOf(e.logId.toString())
                ) > 0
            } catch (ex: Exception) {
                false
            }
            runOnUiThread {
                if (ok) loadData() else toast(R.string.delete_failed)
            }
        }.start()
    }

    // ---------- calling ----------

    private fun has(p: String): Boolean =
        checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun place(num: String) {
        if (num.isBlank()) return
        if (!has(Manifest.permission.CALL_PHONE)) {
            Toast.makeText(this, R.string.perm_needed, Toast.LENGTH_SHORT).show()
            requestPermissionsIfNeeded()
            return
        }
        try {
            val tm = getSystemService(TelecomManager::class.java)
            tm.placeCall(Uri.fromParts("tel", num, null), Bundle())
        } catch (e: SecurityException) {
            Toast.makeText(this, R.string.perm_needed, Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- default dialer ----------

    private fun isDefault(): Boolean =
        getSystemService(TelecomManager::class.java)?.defaultDialerPackage == packageName

    private fun updateBanner() {
        banner.visibility = if (isDefault()) View.GONE else View.VISIBLE
        bannerOverlay.visibility = if (Settings.canDrawOverlays(this)) View.GONE else View.VISIBLE
    }

    private fun requestDefault() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val rm = getSystemService(RoleManager::class.java)
                if (rm.isRoleAvailable(RoleManager.ROLE_DIALER) &&
                    !rm.isRoleHeld(RoleManager.ROLE_DIALER)
                ) {
                    roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER))
                }
            } else {
                val i = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                    .putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
                roleLauncher.launch(i)
            }
        } catch (e: Exception) {
            Toast.makeText(this, e.message ?: "Error", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- permissions & data ----------

    private fun requestPermissionsIfNeeded() {
        val wanted = mutableListOf(
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.ANSWER_PHONE_CALLS,
            Manifest.permission.WRITE_CONTACTS,
            Manifest.permission.WRITE_CALL_LOG
        )
        if (Build.VERSION.SDK_INT >= 33) wanted.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = wanted.filter { !has(it) }
        if (missing.isNotEmpty()) permLauncher.launch(missing.toTypedArray())
    }

    private fun loadData() {
        val canContacts = has(Manifest.permission.READ_CONTACTS)
        val canLog = has(Manifest.permission.READ_CALL_LOG)
        if (!canContacts && !canLog) return
        val gen = ++loadGen
        Thread {
            val contacts = if (canContacts) queryContacts() else null
            // names are resolved live from the contacts, so a new contact shows up in
            // Recents at once instead of waiting for the call-log name cache
            val names = HashMap<String, String>()
            contacts?.forEach {
                val k = PhotoStore.key(it.number)
                if (k.isNotEmpty() && !names.containsKey(k)) names[k] = it.title
            }
            val recents = if (canLog) queryRecents(names) else null
            runOnUiThread {
                if (gen != loadGen) return@runOnUiThread
                if (contacts != null) {
                    allContacts = contacts
                    applyFilter()
                }
                if (recents != null) {
                    allRecents = recents
                    recentsAdapter.submit(recents)
                    emptyRecents.visibility = if (recents.isEmpty()) View.VISIBLE else View.GONE
                }
            }
        }.start()
    }

    /** Shows a freshly saved contact immediately, before the contacts database is re-read. */
    private fun applyOptimistic(name: String, num: String) {
        val k = PhotoStore.key(num)
        allContacts = (allContacts + Entry(name, num, num, saved = true))
            .sortedBy { it.title.lowercase() }
        applyFilter()
        if (k.isNotEmpty()) {
            allRecents = allRecents.map {
                if (PhotoStore.key(it.number) == k) it.copy(title = name, saved = true) else it
            }
            recentsAdapter.submit(allRecents)
        }
    }

    private fun applyFilter() {
        val q = searchBox.text.toString().trim()
        val list = if (q.isEmpty()) allContacts
        else allContacts.filter { it.title.contains(q, true) || it.number.contains(q) }
        contactsAdapter.submit(list)
        emptyContacts.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun queryRecents(names: Map<String, String>): List<Entry> {
        val out = ArrayList<Entry>()
        try {
            contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(
                    CallLog.Calls.NUMBER,
                    CallLog.Calls.CACHED_NAME,
                    CallLog.Calls.TYPE,
                    CallLog.Calls.DATE,
                    CallLog.Calls._ID
                ),
                null, null, CallLog.Calls.DATE + " DESC"
            )?.use { c ->
                val fmt = SimpleDateFormat("MM/dd  HH:mm", Locale.getDefault())
                while (c.moveToNext() && out.size < 100) {
                    val num = c.getString(0) ?: ""
                    val cached = c.getString(1)
                    val k = PhotoStore.key(num)
                    val name = (if (k.isNotEmpty()) names[k] else null) ?: cached
                    val type = c.getInt(2)
                    val date = c.getLong(3)
                    val logId = c.getLong(4)
                    val label = when (type) {
                        CallLog.Calls.MISSED_TYPE -> getString(R.string.type_missed)
                        CallLog.Calls.OUTGOING_TYPE -> getString(R.string.type_outgoing)
                        else -> getString(R.string.type_incoming)
                    }
                    val title = if (!name.isNullOrBlank()) name
                    else if (num.isBlank()) getString(R.string.unknown) else num
                    out.add(
                        Entry(
                            title,
                            label + "  •  " + num + "  •  " + fmt.format(Date(date)),
                            num,
                            type == CallLog.Calls.MISSED_TYPE,
                            logId = logId,
                            saved = !name.isNullOrBlank()
                        )
                    )
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun queryContacts(): List<Entry> {
        val out = ArrayList<Entry>()
        val seen = HashSet<String>()
        try {
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                    ContactsContract.CommonDataKinds.Phone.LOOKUP_KEY
                ),
                null, null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(0) ?: continue
                    val num = c.getString(1) ?: continue
                    val key = name + "|" + num.filter { it.isDigit() }
                    if (seen.add(key)) {
                        out.add(
                            Entry(
                                name, num, num,
                                contactId = c.getLong(2),
                                lookupKey = c.getString(3),
                                saved = true
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
        }
        return out
    }
}
