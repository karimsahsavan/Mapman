package com.shik.dialer

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.provider.CallLog
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.text.Editable
import android.text.TextWatcher
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var pageKeypad: View
    private lateinit var pageRecents: View
    private lateinit var pageContacts: View
    private lateinit var display: TextView
    private lateinit var banner: View
    private lateinit var nav: BottomNavigationView
    private lateinit var searchBox: EditText
    private lateinit var emptyRecents: View
    private lateinit var emptyContacts: View

    private val number = StringBuilder()
    private val recentsAdapter = EntryAdapter { place(it.number) }
    private val contactsAdapter = EntryAdapter { place(it.number) }
    private var allContacts: List<Entry> = emptyList()

    private val tone: ToneGenerator? = try {
        ToneGenerator(AudioManager.STREAM_DTMF, 60)
    } catch (e: Exception) {
        null
    }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            loadData()
        }

    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            updateBanner()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        pageKeypad = findViewById(R.id.pageKeypad)
        pageRecents = findViewById(R.id.pageRecents)
        pageContacts = findViewById(R.id.pageContacts)
        display = findViewById(R.id.display)
        banner = findViewById(R.id.bannerDefault)
        nav = findViewById(R.id.nav)
        searchBox = findViewById(R.id.searchBox)
        emptyRecents = findViewById(R.id.emptyRecents)
        emptyContacts = findViewById(R.id.emptyContacts)

        findViewById<RecyclerView>(R.id.listRecents).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = recentsAdapter
        }
        findViewById<RecyclerView>(R.id.listContacts).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = contactsAdapter
        }

        buildKeypad()

        findViewById<ImageButton>(R.id.btnBackspace).apply {
            setOnClickListener {
                if (number.isNotEmpty()) number.deleteCharAt(number.length - 1)
                updateDisplay()
            }
            setOnLongClickListener {
                number.clear()
                updateDisplay()
                true
            }
        }
        findViewById<View>(R.id.btnCall).setOnClickListener { place(number.toString()) }
        findViewById<View>(R.id.btnSetDefault).setOnClickListener { requestDefault() }

        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                applyFilter()
            }
        })

        nav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_keypad -> show(0)
                R.id.nav_recents -> show(1)
                R.id.nav_contacts -> show(2)
            }
            true
        }
        nav.selectedItemId = R.id.nav_keypad

        handleIntent(intent)
        requestPermissionsIfNeeded()
    }

    override fun onResume() {
        super.onResume()
        updateBanner()
        loadData()
    }

    override fun onDestroy() {
        tone?.release()
        super.onDestroy()
    }

    // ---------- navigation ----------

    private fun show(index: Int) {
        pageKeypad.visibility = if (index == 0) View.VISIBLE else View.GONE
        pageRecents.visibility = if (index == 1) View.VISIBLE else View.GONE
        pageContacts.visibility = if (index == 2) View.VISIBLE else View.GONE
    }

    private fun handleIntent(i: Intent?) {
        val data: Uri? = i?.data
        if (data != null && data.scheme == "tel") {
            number.clear()
            number.append(data.schemeSpecificPart ?: "")
            updateDisplay()
            nav.selectedItemId = R.id.nav_keypad
        }
    }

    // ---------- keypad ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildKeypad() {
        val container = findViewById<LinearLayout>(R.id.keysContainer)
        val rows = listOf(
            listOf("1" to "", "2" to "ABC", "3" to "DEF"),
            listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
            listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ"),
            listOf("*" to "", "0" to "+", "#" to "")
        )
        for (r in rows) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            container.addView(
                row,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            )
            for ((digit, letters) in r) {
                val key = LayoutInflater.from(this).inflate(R.layout.item_key, row, false)
                key.findViewById<TextView>(R.id.keyDigit).text = digit
                key.findViewById<TextView>(R.id.keyLetters).text = letters
                val lp = key.layoutParams as LinearLayout.LayoutParams
                lp.setMargins(dp(5), dp(5), dp(5), dp(5))
                key.setOnClickListener {
                    append(digit)
                }
                if (digit == "0") {
                    key.setOnLongClickListener {
                        append("+")
                        true
                    }
                }
                row.addView(key)
            }
        }
    }

    private fun append(ch: String) {
        number.append(ch)
        updateDisplay()
        try {
            val t = when (ch) {
                "*" -> ToneGenerator.TONE_DTMF_S
                "#" -> ToneGenerator.TONE_DTMF_P
                "+" -> -1
                else -> ch.toInt() + ToneGenerator.TONE_DTMF_0
            }
            if (t >= 0) tone?.startTone(t, 100)
        } catch (e: Exception) {
        }
    }

    private fun updateDisplay() {
        display.text = number.toString()
    }

    // ---------- calling ----------

    private fun has(p: String): Boolean =
        checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun place(num: String) {
        if (num.isBlank()) return
        if (!has(Manifest.permission.CALL_PHONE)) {
            Toast.makeText(this, R.string.perm_needed, Toast.LENGTH_SHORT).show()
            requestPermissionsIfNeeded()
            return
        }
        try {
            val tm = getSystemService(TelecomManager::class.java)
            tm.placeCall(Uri.fromParts("tel", num, null), Bundle())
        } catch (e: SecurityException) {
            Toast.makeText(this, R.string.perm_needed, Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- default dialer ----------

    private fun isDefault(): Boolean =
        getSystemService(TelecomManager::class.java)?.defaultDialerPackage == packageName

    private fun updateBanner() {
        banner.visibility = if (isDefault()) View.GONE else View.VISIBLE
    }

    private fun requestDefault() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val rm = getSystemService(RoleManager::class.java)
                if (rm.isRoleAvailable(RoleManager.ROLE_DIALER) &&
                    !rm.isRoleHeld(RoleManager.ROLE_DIALER)
                ) {
                    roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER))
                }
            } else {
                val i = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                    .putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
                roleLauncher.launch(i)
            }
        } catch (e: Exception) {
            Toast.makeText(this, e.message ?: "Error", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- permissions & data ----------

    private fun requestPermissionsIfNeeded() {
        val wanted = mutableListOf(
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.ANSWER_PHONE_CALLS
        )
        if (Build.VERSION.SDK_INT >= 33) wanted.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = wanted.filter { !has(it) }
        if (missing.isNotEmpty()) permLauncher.launch(missing.toTypedArray())
    }

    private fun loadData() {
        if (has(Manifest.permission.READ_CALL_LOG)) {
            Thread {
                val list = queryRecents()
                runOnUiThread {
                    recentsAdapter.submit(list)
                    emptyRecents.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                }
            }.start()
        }
        if (has(Manifest.permission.READ_CONTACTS)) {
            Thread {
                val list = queryContacts()
                runOnUiThread {
                    allContacts = list
                    applyFilter()
                }
            }.start()
        }
    }

    private fun applyFilter() {
        val q = searchBox.text.toString().trim()
        val list = if (q.isEmpty()) allContacts
        else allContacts.filter { it.title.contains(q, true) || it.number.contains(q) }
        contactsAdapter.submit(list)
        emptyContacts.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun queryRecents(): List<Entry> {
        val out = ArrayList<Entry>()
        try {
            contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(
                    CallLog.Calls.NUMBER,
                    CallLog.Calls.CACHED_NAME,
                    CallLog.Calls.TYPE,
                    CallLog.Calls.DATE
                ),
                null, null, CallLog.Calls.DATE + " DESC"
            )?.use { c ->
                val fmt = SimpleDateFormat("MM/dd  HH:mm", Locale.getDefault())
                while (c.moveToNext() && out.size < 100) {
                    val num = c.getString(0) ?: ""
                    val name = c.getString(1)
                    val type = c.getInt(2)
                    val date = c.getLong(3)
                    val label = when (type) {
                        CallLog.Calls.MISSED_TYPE -> getString(R.string.type_missed)
                        CallLog.Calls.OUTGOING_TYPE -> getString(R.string.type_outgoing)
                        else -> getString(R.string.type_incoming)
                    }
                    val title = if (!name.isNullOrBlank()) name
                    else if (num.isBlank()) getString(R.string.unknown) else num
                    out.add(
                        Entry(
                            title,
                            label + "  •  " + num + "  •  " + fmt.format(Date(date)),
                            num,
                            type == CallLog.Calls.MISSED_TYPE
                        )
                    )
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun queryContacts(): List<Entry> {
        val out = ArrayList<Entry>()
        val seen = HashSet<String>()
        try {
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null, null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(0) ?: continue
                    val num = c.getString(1) ?: continue
                    val key = name + "|" + num.filter { it.isDigit() }
                    if (seen.add(key)) out.add(Entry(name, num, num))
                }
            }
        } catch (e: Exception) {
        }
        return out
    }
}
