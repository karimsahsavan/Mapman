package com.shik.dialer

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.content.ContentProviderOperation
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.database.ContentObserver
import android.graphics.Outline
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.TelecomManager
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.net.Uri
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var pageKeypad: View
    private lateinit var pageRecents: View
    private lateinit var pageContacts: View
    private lateinit var display: TextView
    private lateinit var banner: View
    private lateinit var bannerOverlay: View
    private lateinit var nav: BottomBar
    private lateinit var btnCall: ImageButton
    private lateinit var displayFlash: View
    private lateinit var dancingGirl: DancingGirlView
    private var curPage = 0
    private var autoNumber: String? = null
    private var autoPrefix = ""
    private var rejectedPrefix: String? = null
    private lateinit var searchBox: EditText
    private lateinit var emptyRecents: View
    private lateinit var emptyContacts: View

    private val number = StringBuilder()
    private val recentsAdapter = EntryAdapter(
        { place(it.number) }, { showPhotoDialog(it) }, { showMenu(it, false) },
        recents = true, onInfo = { showDetails(it) }
    )
    private val contactsAdapter = EntryAdapter(
        { place(it.number) }, { showPhotoDialog(it) }, { showMenu(it, true) }, true
    )
    private lateinit var btnAddFromKeypad: TextView
    private var pendingPhotoNumber: String? = null
    private var allContacts: List<Entry> = emptyList()
    private var allRecents: List<Entry> = emptyList()
    private var loadGen = 0
    private val uiHandler = Handler(Looper.getMainLooper())
    private val reloadRunnable = Runnable { loadData() }
    private val dbObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            uiHandler.removeCallbacks(reloadRunnable)
            uiHandler.postDelayed(reloadRunnable, 200)
        }
    }

    private val tone: ToneGenerator? = try {
        ToneGenerator(AudioManager.STREAM_DTMF, 60)
    } catch (e: Exception) {
        null
    }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            loadData()
        }

    private val pickPhoto =
        registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            val num = pendingPhotoNumber
            if (uri != null && !num.isNullOrBlank()) {
                Thread {
                    val ok = PhotoStore.save(this, num, uri)
                    runOnUiThread {
                        if (ok) {
                            recentsAdapter.refresh()
                            contactsAdapter.refresh()
                        } else {
                            Toast.makeText(this, R.string.photo_failed, Toast.LENGTH_SHORT).show()
                        }
                    }
                }.start()
            }
        }

    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            updateBanner()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        pendingPhotoNumber = savedInstanceState?.getString("pendingPhotoNumber")

        pageKeypad = findViewById(R.id.pageKeypad)
        pageRecents = findViewById(R.id.pageRecents)
        pageContacts = findViewById(R.id.pageContacts)
        display = findViewById(R.id.display)
        banner = findViewById(R.id.bannerDefault)
        bannerOverlay = findViewById(R.id.bannerOverlay)
        nav = findViewById(R.id.nav)
        btnCall = findViewById(R.id.btnCall)
        displayFlash = findViewById(R.id.displayFlash)
        dancingGirl = findViewById(R.id.dancingGirl)
        if (number.isEmpty()) dancingGirl.startDance() else dancingGirl.hideNow()
        searchBox = findViewById(R.id.searchBox)
        emptyRecents = findViewById(R.id.emptyRecents)
        emptyContacts = findViewById(R.id.emptyContacts)

        val listRecents = findViewById<RecyclerView>(R.id.listRecents).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = recentsAdapter
        }
        val listContacts = findViewById<RecyclerView>(R.id.listContacts).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = contactsAdapter
        }
        ItemTouchHelper(
            SwipeHandler(this, { recentsAdapter.itemAt(it) }) { a, e -> doSwipe(a, e, false) }
        ).attachToRecyclerView(listRecents)
        ItemTouchHelper(
            SwipeHandler(this, { contactsAdapter.itemAt(it) }) { a, e -> doSwipe(a, e, true) }
        ).attachToRecyclerView(listContacts)

        btnAddFromKeypad = findViewById(R.id.btnAddFromKeypad)
        btnAddFromKeypad.setOnClickListener { showAddContact(number.toString()) }
        Anim.press(findViewById<View>(R.id.btnCleanup), 0.88f)
        findViewById<View>(R.id.btnCleanup).setOnClickListener { showCleanup() }
        Anim.press(findViewById<View>(R.id.btnAddContact), 0.88f)
        findViewById<View>(R.id.btnAddContact).setOnClickListener { showAddContact("") }

        buildKeypad()

        Anim.press(btnCall, 0.9f)
        btnCall.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
        styleCallButton(0)
        btnCall.setOnClickListener {
            when {
                // Recents / Contacts: the orange button opens the dial pad
                curPage != 0 -> nav.selectedId = R.id.nav_keypad
                number.isNotEmpty() -> place(number.toString())
                else -> {
                    val a = resources.displayMetrics.density * 10f
                    ObjectAnimator.ofFloat(
                        display, View.TRANSLATION_X, 0f, -a, a, -a * 0.6f, a * 0.6f, 0f
                    ).setDuration(300).start()
                }
            }
        }
        Anim.press(findViewById<View>(R.id.btnBackspace), 0.85f)
        Anim.press(findViewById<View>(R.id.btnSetDefault), 0.95f)
        Anim.press(findViewById<View>(R.id.btnOverlay), 0.95f)

        findViewById<ImageButton>(R.id.btnBackspace).apply {
            setOnClickListener {
                val an = autoNumber
                if (an != null && number.toString() == an) {
                    // undo the auto-completion: back to the digits the user typed
                    number.setLength(0)
                    number.append(autoPrefix)
                    rejectedPrefix = autoPrefix
                    autoNumber = null
                } else if (number.isNotEmpty()) {
                    number.deleteCharAt(number.length - 1)
                }
                updateDisplay()
            }
            setOnLongClickListener {
                number.clear()
                autoNumber = null
                rejectedPrefix = null
                updateDisplay()
                true
            }
        }
        findViewById<View>(R.id.btnSetDefault).setOnClickListener { requestDefault() }
        findViewById<View>(R.id.btnOverlay).setOnClickListener {
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            } catch (e: Exception) {
            }
        }

        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                applyFilter()
            }
        })

        nav.onSelect = { id ->
            when (id) {
                R.id.nav_keypad -> {
                    show(0)
                    true
                }
                R.id.nav_recents -> {
                    show(1)
                    true
                }
                R.id.nav_contacts -> {
                    show(2)
                    true
                }
                R.id.nav_settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java))
                    false
                }
                else -> false
            }
        }
        nav.selectedId = R.id.nav_keypad

        handleIntent(intent)
        requestPermissionsIfNeeded()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("pendingPhotoNumber", pendingPhotoNumber)
    }

    override fun onResume() {
        super.onResume()
        AvatarClock.reaction = Prefs.reaction(this)
        recentsAdapter.refresh()
        contactsAdapter.refresh()
        updateBanner()
        loadData()
    }

    override fun onStart() {
        super.onStart()
        try {
            contentResolver.registerContentObserver(ContactsContract.Contacts.CONTENT_URI, true, dbObserver)
            contentResolver.registerContentObserver(CallLog.Calls.CONTENT_URI, true, dbObserver)
        } catch (e: Exception) {
        }
    }

    override fun onStop() {
        try {
            contentResolver.unregisterContentObserver(dbObserver)
        } catch (e: Exception) {
        }
        uiHandler.removeCallbacks(reloadRunnable)
        super.onStop()
    }

    override fun onDestroy() {
        tone?.release()
        super.onDestroy()
    }

    // ---------- navigation ----------

    private fun styleCallButton(page: Int) {
        if (page == 0) {
            btnCall.setImageResource(R.drawable.ic_call)
            btnCall.setBackgroundResource(R.drawable.bg_fab)
            btnCall.contentDescription = getString(R.string.menu_call)
            btnCall.outlineSpotShadowColor = 0xFF1FC46A.toInt()
            btnCall.outlineAmbientShadowColor = 0xFF1FC46A.toInt()
        } else {
            btnCall.setImageResource(R.drawable.ic_dialpad)
            btnCall.setBackgroundResource(R.drawable.bg_fab_orange)
            btnCall.contentDescription = getString(R.string.tab_dialpad_open)
            btnCall.outlineSpotShadowColor = 0xFFFF8F3F.toInt()
            btnCall.outlineAmbientShadowColor = 0xFFFF8F3F.toInt()
        }
    }

    /** Slides the old page out and the new one in (direction follows the tab order). */
    private fun show(index: Int) {
        val pages = listOf(pageKeypad, pageRecents, pageContacts)
        if (index == curPage) {
            pages.forEachIndexed { i, p ->
                p.visibility = if (i == index) View.VISIBLE else View.GONE
            }
            return
        }
        val from = pages[curPage]
        val to = pages[index]
        val dir = if (index > curPage) 1f else -1f
        val host = to.parent as View
        val w = (if (host.width > 0) host.width else resources.displayMetrics.widthPixels).toFloat()

        pages.forEach { p ->
            p.animate().cancel()
            p.translationX = 0f
            p.alpha = 1f
            p.scaleX = 1f
            p.scaleY = 1f
            if (p !== from && p !== to) p.visibility = View.GONE
        }
        from.visibility = View.VISIBLE
        to.visibility = View.VISIBLE

        from.animate().translationX(-dir * w * 0.28f).alpha(0f).scaleX(0.95f).scaleY(0.95f)
            .setDuration(230).setInterpolator(AccelerateInterpolator(1.3f))
            .withEndAction {
                from.visibility = View.GONE
                from.translationX = 0f
                from.alpha = 1f
                from.scaleX = 1f
                from.scaleY = 1f
            }.start()

        to.translationX = dir * w * 0.28f
        to.alpha = 0f
        to.scaleX = 0.95f
        to.scaleY = 0.95f
        to.animate().translationX(0f).alpha(1f).scaleX(1f).scaleY(1f)
            .setDuration(340).setInterpolator(DecelerateInterpolator(1.8f)).start()

        if (index == 0) popKeys()

        // call button: green call <-> orange dial pad, with a little spin
        styleCallButton(index)
        btnCall.animate().cancel()
        btnCall.scaleX = 0.7f
        btnCall.scaleY = 0.7f
        btnCall.rotation = -70f * dir
        btnCall.animate().scaleX(1f).scaleY(1f).rotation(0f).setDuration(380)
            .setInterpolator(OvershootInterpolator(2.4f)).start()
        curPage = index
    }

    /** Keys pop in one after another when the dial pad opens. */
    private fun popKeys() {
        val kc = findViewById<LinearLayout>(R.id.keysContainer)
        var n = 0
        for (r in 0 until kc.childCount) {
            val row = kc.getChildAt(r) as ViewGroup
            for (c in 0 until row.childCount) {
                val k = row.getChildAt(c)
                k.alpha = 0f
                k.scaleX = 0.6f
                k.scaleY = 0.6f
                ObjectAnimator.ofPropertyValuesHolder(
                    k,
                    PropertyValuesHolder.ofFloat(View.ALPHA, 0f, 1f),
                    PropertyValuesHolder.ofFloat(View.SCALE_X, 0.6f, 1f),
                    PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.6f, 1f)
                ).apply {
                    startDelay = 90L + n * 24L
                    duration = 320
                    interpolator = OvershootInterpolator(2.2f)
                    start()
                }
                n++
            }
        }
    }

    private fun handleIntent(i: Intent?) {
        val data: Uri? = i?.data
        if (data != null && data.scheme == "tel") {
            number.clear()
            number.append(data.schemeSpecificPart ?: "")
            updateDisplay()
            autoNumber = null
            nav.selectedId = R.id.nav_keypad
        }
    }

    // ---------- keypad ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildKeypad() {
        val container = findViewById<LinearLayout>(R.id.keysContainer)
        val rows = listOf(
            listOf("1" to "", "2" to "ABC", "3" to "DEF"),
            listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
            listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ"),
            listOf("*" to "", "0" to "+", "#" to "")
        )
        for (r in rows) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            container.addView(
                row,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            )
            for ((digit, letters) in r) {
                val key = LayoutInflater.from(this).inflate(R.layout.item_key, row, false)
                key.findViewById<TextView>(R.id.keyDigit).text = digit
                key.findViewById<TextView>(R.id.keyLetters).text = letters
                val lp = key.layoutParams as LinearLayout.LayoutParams
                lp.setMargins(dp(5), dp(5), dp(5), dp(5))
                Anim.press(key, 0.92f)
                key.setOnClickListener {
                    append(digit)
                }
                if (digit == "0") {
                    key.setOnLongClickListener {
                        append("+")
                        true
                    }
                }
                row.addView(key)
            }
        }
    }

    private fun append(ch: String) {
        autoNumber = null
        number.append(ch)
        updateDisplay()
        try {
            val t = when (ch) {
                "*" -> ToneGenerator.TONE_DTMF_S
                "#" -> ToneGenerator.TONE_DTMF_P
                "+" -> -1
                else -> ch.toInt() + ToneGenerator.TONE_DTMF_0
            }
            if (t >= 0) tone?.startTone(t, 100)
        } catch (e: Exception) {
        }
        if (ch.length == 1 && ch[0].isDigit()) maybeAutoComplete()
    }

    /** Digits (and a leading +) of a stored number; Iranian +98 / 0098 numbers become 09xx... */
    private fun fullForm(raw: String): String? {
        val plus = raw.trim().startsWith("+")
        val digits = raw.filter { it.isDigit() }
        if (digits.isEmpty()) return null
        if (digits.startsWith("0098")) return "0" + digits.drop(4)
        if (digits.startsWith("98") && digits.length == 12) return "0" + digits.drop(2)
        return if (plus) "+$digits" else digits
    }

    /**
     * When exactly 8 digits are typed and they are the start of ONE saved contact's number,
     * the full number is filled in at once and the display flashes green.
     */
    private fun maybeAutoComplete() {
        val typed = number.toString()
        if (typed.length != 8 || !typed.all { it.isDigit() }) return
        if (typed == rejectedPrefix) return
        val matches = LinkedHashSet<String>()
        for (e in allContacts) {
            val full = fullForm(e.number) ?: continue
            val digits = full.filter { it.isDigit() }
            if (digits.length > typed.length && digits.startsWith(typed)) matches.add(full)
        }
        if (matches.size != 1) return
        val full = matches.first()
        autoPrefix = typed
        autoNumber = full
        number.setLength(0)
        number.append(full)
        updateDisplay()
        flashComplete()
    }

    /** Green blinking background + a bump of the call button: the number is complete. */
    private fun flashComplete() {
        displayFlash.animate().cancel()
        ObjectAnimator.ofFloat(displayFlash, View.ALPHA, 0f, 1f, 0.1f, 1f, 0.1f, 1f, 0f).apply {
            duration = 1200
            start()
        }
        display.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        btnCall.animate().cancel()
        btnCall.animate().scaleX(1.22f).scaleY(1.22f).setDuration(160).withEndAction {
            btnCall.animate().scaleX(1f).scaleY(1f).setDuration(420)
                .setInterpolator(OvershootInterpolator(3f)).start()
        }.start()
    }

    /** Name of the saved contact whose number equals [num], if any. */
    private fun findContactName(num: String): String? {
        val k = PhotoStore.key(num)
        if (k.length < 8) return null
        return allContacts.firstOrNull { PhotoStore.key(it.number) == k }?.title
    }

    private fun updateDisplay() {
        display.text = formatNumber(number.toString())
        if (number.isNotEmpty()) dancingGirl.stopAndFade() else dancingGirl.startDance()
        if (number.isEmpty()) rejectedPrefix = null
        val matched = if (number.length >= 8) findContactName(number.toString()) else null
        if (number.isEmpty()) {
            btnAddFromKeypad.visibility = View.INVISIBLE
        } else {
            btnAddFromKeypad.visibility = View.VISIBLE
            if (matched != null) {
                btnAddFromKeypad.text = matched
                btnAddFromKeypad.isClickable = false
            } else {
                btnAddFromKeypad.setText(R.string.add_to_contacts)
                btnAddFromKeypad.isClickable = true
            }
        }
        display.scaleX = 1.07f
        display.scaleY = 1.07f
        display.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
    }

    /** 09121234567 -> 0912 123 4567 (display only; the dialed number stays unchanged). */
    private fun formatNumber(n: String): String {
        if (n.length > 4 && n.startsWith("09") && n.all { it.isDigit() }) {
            val sb = StringBuilder()
            for ((i, ch) in n.withIndex()) {
                if (i == 4 || i == 7) sb.append(' ')
                sb.append(ch)
            }
            return sb.toString()
        }
        return n
    }

    // ---------- contact photos ----------

    private fun showPhotoDialog(e: Entry) {
        if (PhotoStore.key(e.number).isEmpty()) return
        val labels = ArrayList<String>()
        labels.add(getString(R.string.photo_pick))
        val hasPhoto = PhotoStore.has(this, e.number)
        if (hasPhoto) labels.add(getString(R.string.photo_remove))
        AlertDialog.Builder(this)
            .setTitle(e.title)
            .setItems(labels.toTypedArray()) { _, which ->
                if (which == 0) {
                    choosePhoto(e)
                } else {
                    PhotoStore.remove(this, e.number)
                    recentsAdapter.refresh()
                    contactsAdapter.refresh()
                }
            }
            .show()
    }

    // ---------- row menu, swipe actions ----------

    private fun toast(res: Int) {
        Toast.makeText(this, res, Toast.LENGTH_SHORT).show()
    }

    private fun sms(num: String) {
        if (num.isBlank()) return
        try {
            startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(num))))
        } catch (e: Exception) {
            toast(R.string.sms_failed)
        }
    }

    private fun doSwipe(action: Int, e: Entry, fromContacts: Boolean) {
        when (action) {
            Prefs.SW_CALL -> place(e.number)
            Prefs.SW_SMS -> sms(e.number)
            Prefs.SW_DELETE ->
                if (fromContacts) confirmDeleteContact(e) else deleteLog(e)
        }
    }

    private fun choosePhoto(e: Entry) {
        pendingPhotoNumber = e.number
        pickPhoto.launch(
            PickVisualMediaRequest.Builder()
                .setMediaType(ActivityResultContracts.PickVisualMedia.ImageOnly)
                .build()
        )
    }

    private fun findContactEntry(num: String): Entry? {
        val k = PhotoStore.key(num)
        if (k.length < 8) return null
        return allContacts.firstOrNull { PhotoStore.key(it.number) == k }
    }

    private fun showMenu(e: Entry, fromContacts: Boolean) {
        val green = 0xFF1FC46A.toInt()
        val blue = 0xFF2F80ED.toInt()
        val purple = 0xFF8E5CF7.toInt()
        val orange = 0xFFFF8F3F.toInt()
        val red = 0xFFF0524A.toInt()
        val items = ArrayList<Sheets.Item>()
        items.add(Sheets.Item(getString(R.string.menu_call), R.drawable.ic_call, green) { place(e.number) })
        items.add(Sheets.Item(getString(R.string.menu_sms), R.drawable.ic_message, blue) { sms(e.number) })
        if (!fromContacts && e.date > 0L) {
            items.add(
                Sheets.Item(getString(R.string.call_details), R.drawable.ic_info, 0xFF5B6B8C.toInt()) {
                    showDetails(e)
                }
            )
        }
        val contact = if (fromContacts) e else findContactEntry(e.number)
        if (contact != null && contact.contactId != 0L) {
            items.add(
                Sheets.Item(getString(R.string.edit_contact), R.drawable.ic_edit, orange) {
                    showEditContact(contact)
                }
            )
        }
        if (PhotoStore.key(e.number).isNotEmpty()) {
            items.add(Sheets.Item(getString(R.string.photo_pick), R.drawable.ic_person, purple) { choosePhoto(e) })
            if (PhotoStore.has(this, e.number)) {
                items.add(
                    Sheets.Item(getString(R.string.photo_remove), R.drawable.ic_delete, purple) {
                        PhotoStore.remove(this, e.number)
                        recentsAdapter.refresh()
                        contactsAdapter.refresh()
                    }
                )
            }
        }
        if (fromContacts) {
            items.add(Sheets.Item(getString(R.string.delete_contact), R.drawable.ic_delete, red) { confirmDeleteContact(e) })
        } else {
            if (!e.saved && e.number.isNotBlank()) {
                items.add(
                    Sheets.Item(getString(R.string.add_to_contacts), R.drawable.ic_add, green) {
                        showAddContact(e.number)
                    }
                )
            }
            items.add(Sheets.Item(getString(R.string.delete_history), R.drawable.ic_delete, red) { deleteLog(e) })
        }
        Sheets.menu(this, e.title, e.number, items)
    }

    // ---------- call details, history clean-up ----------

    private fun showDetails(e: Entry) {
        Sheets.callDetails(
            this, e,
            onCall = { place(e.number) },
            onSms = { sms(e.number) },
            onDelete = { deleteLog(e) }
        )
    }

    private fun showCleanup() {
        val items = ArrayList<Sheets.Item>()
        items.add(
            Sheets.Item(getString(R.string.clean_week), R.drawable.ic_history, 0xFF2F80ED.toInt()) {
                confirmCleanup(7)
            }
        )
        items.add(
            Sheets.Item(getString(R.string.clean_month), R.drawable.ic_history, 0xFF8E5CF7.toInt()) {
                confirmCleanup(30)
            }
        )
        Sheets.menu(this, getString(R.string.clean_history), null, items)
    }

    /** Counts the call-log rows older than [days] days, asks, then deletes them. */
    private fun confirmCleanup(days: Int) {
        if (!has(Manifest.permission.WRITE_CALL_LOG) || !has(Manifest.permission.READ_CALL_LOG)) {
            toast(R.string.need_write_perm)
            permLauncher.launch(
                arrayOf(Manifest.permission.READ_CALL_LOG, Manifest.permission.WRITE_CALL_LOG)
            )
            return
        }
        val cutoff = System.currentTimeMillis() - days * 86400000L
        Thread {
            val n = try {
                contentResolver.query(
                    CallLog.Calls.CONTENT_URI,
                    arrayOf(CallLog.Calls._ID),
                    CallLog.Calls.DATE + "<?",
                    arrayOf(cutoff.toString()),
                    null
                )?.use { it.count } ?: 0
            } catch (ex: Exception) {
                0
            }
            runOnUiThread {
                if (n == 0) {
                    toast(R.string.clean_none)
                } else {
                    AlertDialog.Builder(this)
                        .setTitle(R.string.clean_history)
                        .setMessage(getString(R.string.clean_confirm, FaFormat.digits(n.toString())))
                        .setPositiveButton(R.string.delete) { _, _ -> doCleanup(cutoff) }
                        .setNegativeButton(R.string.cancel, null)
                        .show()
                }
            }
        }.start()
    }

    private fun doCleanup(cutoff: Long) {
        Thread {
            val n = try {
                contentResolver.delete(
                    CallLog.Calls.CONTENT_URI,
                    CallLog.Calls.DATE + "<?",
                    arrayOf(cutoff.toString())
                )
            } catch (ex: Exception) {
                -1
            }
            runOnUiThread {
                if (n >= 0) {
                    Toast.makeText(
                        this,
                        getString(R.string.cleaned, FaFormat.digits(n.toString())),
                        Toast.LENGTH_SHORT
                    ).show()
                    loadData()
                } else toast(R.string.delete_failed)
            }
        }.start()
    }

    // ---------- add / delete contacts ----------

    private fun showAddContact(prefillNumber: String) {
        Sheets.contactForm(
            this, getString(R.string.add_contact), "", prefillNumber, getString(R.string.save),
            GENDER_AUTO
        ) { name, num, g -> saveContact(name, num, g) }
    }

    private fun showEditContact(e: Entry) {
        Sheets.contactForm(
            this, getString(R.string.edit_contact), e.title, e.number, getString(R.string.save),
            Genders.effective(this, e.number, e.title)
        ) { name, num, g -> updateContact(e, name, num, g) }
    }

    private fun updateContact(e: Entry, name: String, num: String, gender: Int) {
        if (name.isEmpty() || num.isEmpty()) {
            toast(R.string.contact_incomplete)
            return
        }
        if (!has(Manifest.permission.WRITE_CONTACTS)) {
            toast(R.string.need_write_perm)
            permLauncher.launch(arrayOf(Manifest.permission.WRITE_CONTACTS))
            return
        }
        if (PhotoStore.key(e.number) != PhotoStore.key(num)) Genders.move(this, e.number, num)
        Genders.set(this, num, gender)
        // show the change at once; the database is re-read afterwards
        allContacts = allContacts.map {
            if (it.contactId == e.contactId) {
                if (it.number == e.number) it.copy(title = name, subtitle = num, number = num)
                else it.copy(title = name)
            } else it
        }.sortedBy { it.title.lowercase() }
        applyFilter()
        Thread {
            val ok = try {
                val id = e.contactId.toString()
                val ops = ArrayList<ContentProviderOperation>()
                ops.add(
                    ContentProviderOperation.newUpdate(ContactsContract.Data.CONTENT_URI)
                        .withSelection(
                            ContactsContract.Data.CONTACT_ID + "=? AND " +
                                ContactsContract.Data.MIMETYPE + "=?",
                            arrayOf(
                                id,
                                ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE
                            )
                        )
                        .withValue(
                            ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, name
                        )
                        .build()
                )
                ops.add(
                    ContentProviderOperation.newUpdate(ContactsContract.Data.CONTENT_URI)
                        .withSelection(
                            ContactsContract.Data.CONTACT_ID + "=? AND " +
                                ContactsContract.Data.MIMETYPE + "=? AND " +
                                ContactsContract.CommonDataKinds.Phone.NUMBER + "=?",
                            arrayOf(
                                id,
                                ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE,
                                e.number
                            )
                        )
                        .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, num)
                        .build()
                )
                val res = contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
                if ((res.getOrNull(0)?.count ?: 0) == 0) {
                    // contact had no name row yet: add one to its first raw contact
                    contentResolver.query(
                        ContactsContract.RawContacts.CONTENT_URI,
                        arrayOf(ContactsContract.RawContacts._ID),
                        ContactsContract.RawContacts.CONTACT_ID + "=?",
                        arrayOf(id), null
                    )?.use { c ->
                        if (c.moveToFirst()) {
                            val v = android.content.ContentValues()
                            v.put(ContactsContract.Data.RAW_CONTACT_ID, c.getLong(0))
                            v.put(
                                ContactsContract.Data.MIMETYPE,
                                ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE
                            )
                            v.put(
                                ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, name
                            )
                            contentResolver.insert(ContactsContract.Data.CONTENT_URI, v)
                        }
                    }
                }
                true
            } catch (ex: Exception) {
                false
            }
            runOnUiThread {
                if (ok) {
                    if (PhotoStore.key(e.number) != PhotoStore.key(num)) {
                        PhotoStore.move(this, e.number, num)
                    }
                    toast(R.string.contact_updated)
                } else toast(R.string.contact_edit_failed)
                loadData()
                recentsAdapter.refresh()
                contactsAdapter.refresh()
            }
        }.start()
    }

    private fun saveContact(name: String, num: String, gender: Int) {
        if (name.isEmpty() || num.isEmpty()) {
            toast(R.string.contact_incomplete)
            return
        }
        Genders.set(this, num, gender)
        if (!has(Manifest.permission.WRITE_CONTACTS)) {
            // no write permission yet: ask for it, and meanwhile open the system editor
            permLauncher.launch(arrayOf(Manifest.permission.WRITE_CONTACTS))
            try {
                startActivity(
                    Intent(ContactsContract.Intents.Insert.ACTION).apply {
                        type = ContactsContract.RawContacts.CONTENT_TYPE
                        putExtra(ContactsContract.Intents.Insert.NAME, name)
                        putExtra(ContactsContract.Intents.Insert.PHONE, num)
                    }
                )
            } catch (e: Exception) {
                toast(R.string.contact_failed)
            }
            return
        }
        applyOptimistic(name, num)
        Thread {
            val ok = try {
                val ops = ArrayList<ContentProviderOperation>()
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                        .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                        .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                        .build()
                )
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(
                            ContactsContract.Data.MIMETYPE,
                            ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE
                        )
                        .withValue(
                            ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, name
                        )
                        .build()
                )
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(
                            ContactsContract.Data.MIMETYPE,
                            ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE
                        )
                        .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, num)
                        .withValue(
                            ContactsContract.CommonDataKinds.Phone.TYPE,
                            ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE
                        )
                        .build()
                )
                contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
                true
            } catch (e: Exception) {
                false
            }
            runOnUiThread {
                toast(if (ok) R.string.contact_saved else R.string.contact_failed)
                if (ok) loadData()
            }
        }.start()
    }

    private fun confirmDeleteContact(e: Entry) {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_contact)
            .setMessage(getString(R.string.delete_contact_msg, e.title))
            .setPositiveButton(R.string.delete) { _, _ -> deleteContact(e) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun deleteContact(e: Entry) {
        if (!has(Manifest.permission.WRITE_CONTACTS)) {
            toast(R.string.need_write_perm)
            permLauncher.launch(arrayOf(Manifest.permission.WRITE_CONTACTS))
            return
        }
        Thread {
            val ok = try {
                val key = e.lookupKey
                if (key.isNullOrEmpty() || e.contactId == 0L) false
                else {
                    val uri = ContactsContract.Contacts.getLookupUri(e.contactId, key)
                    contentResolver.delete(uri, null, null) > 0
                }
            } catch (ex: Exception) {
                false
            }
            runOnUiThread {
                if (ok) {
                    PhotoStore.remove(this, e.number)
                    Genders.remove(this, e.number)
                    toast(R.string.contact_deleted)
                    loadData()
                } else toast(R.string.delete_failed)
            }
        }.start()
    }

    private fun deleteLog(e: Entry) {
        if (!has(Manifest.permission.WRITE_CALL_LOG)) {
            toast(R.string.need_write_perm)
            permLauncher.launch(arrayOf(Manifest.permission.WRITE_CALL_LOG))
            return
        }
        Thread {
            val ok = try {
                contentResolver.delete(
                    CallLog.Calls.CONTENT_URI,
                    CallLog.Calls._ID + "=?",
                    arrayOf(e.logId.toString())
                ) > 0
            } catch (ex: Exception) {
                false
            }
            runOnUiThread {
                if (ok) loadData() else toast(R.string.delete_failed)
            }
        }.start()
    }

    // ---------- calling ----------

    private fun has(p: String): Boolean =
        checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun place(num: String) {
        if (num.isBlank()) return
        if (!has(Manifest.permission.CALL_PHONE)) {
            Toast.makeText(this, R.string.perm_needed, Toast.LENGTH_SHORT).show()
            requestPermissionsIfNeeded()
            return
        }
        try {
            val tm = getSystemService(TelecomManager::class.java)
            tm.placeCall(Uri.fromParts("tel", num, null), Bundle())
        } catch (e: SecurityException) {
            Toast.makeText(this, R.string.perm_needed, Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- default dialer ----------

    private fun isDefault(): Boolean =
        getSystemService(TelecomManager::class.java)?.defaultDialerPackage == packageName

    private fun updateBanner() {
        banner.visibility = if (isDefault()) View.GONE else View.VISIBLE
        bannerOverlay.visibility = if (Settings.canDrawOverlays(this)) View.GONE else View.VISIBLE
    }

    private fun requestDefault() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val rm = getSystemService(RoleManager::class.java)
                if (rm.isRoleAvailable(RoleManager.ROLE_DIALER) &&
                    !rm.isRoleHeld(RoleManager.ROLE_DIALER)
                ) {
                    roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER))
                }
            } else {
                val i = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                    .putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
                roleLauncher.launch(i)
            }
        } catch (e: Exception) {
            Toast.makeText(this, e.message ?: "Error", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- permissions & data ----------

    private fun requestPermissionsIfNeeded() {
        val wanted = mutableListOf(
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.ANSWER_PHONE_CALLS,
            Manifest.permission.WRITE_CONTACTS,
            Manifest.permission.WRITE_CALL_LOG
        )
        if (Build.VERSION.SDK_INT >= 33) wanted.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = wanted.filter { !has(it) }
        if (missing.isNotEmpty()) permLauncher.launch(missing.toTypedArray())
    }

    private fun loadData() {
        val canContacts = has(Manifest.permission.READ_CONTACTS)
        val canLog = has(Manifest.permission.READ_CALL_LOG)
        if (!canContacts && !canLog) return
        val gen = ++loadGen
        Thread {
            val contacts = if (canContacts) queryContacts() else null
            // names are resolved live from the contacts, so a new contact shows up in
            // Recents at once instead of waiting for the call-log name cache
            val names = HashMap<String, String>()
            contacts?.forEach {
                val k = PhotoStore.key(it.number)
                if (k.isNotEmpty() && !names.containsKey(k)) names[k] = it.title
            }
            val recents = if (canLog) queryRecents(names) else null
            runOnUiThread {
                if (gen != loadGen) return@runOnUiThread
                if (contacts != null) {
                    allContacts = contacts
                    applyFilter()
                }
                if (recents != null) {
                    allRecents = recents
                    recentsAdapter.submit(recents)
                    emptyRecents.visibility = if (recents.isEmpty()) View.VISIBLE else View.GONE
                }
            }
        }.start()
    }

    /** Shows a freshly saved contact immediately, before the contacts database is re-read. */
    private fun applyOptimistic(name: String, num: String) {
        val k = PhotoStore.key(num)
        allContacts = (allContacts + Entry(name, num, num, saved = true))
            .sortedBy { it.title.lowercase() }
        applyFilter()
        if (k.isNotEmpty()) {
            allRecents = allRecents.map {
                if (PhotoStore.key(it.number) == k) it.copy(title = name, saved = true) else it
            }
            recentsAdapter.submit(allRecents)
        }
    }

    private fun applyFilter() {
        val q = searchBox.text.toString().trim()
        val list = if (q.isEmpty()) allContacts
        else allContacts.filter { it.title.contains(q, true) || it.number.contains(q) }
        contactsAdapter.submit(list)
        emptyContacts.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun queryRecents(names: Map<String, String>): List<Entry> {
        val out = ArrayList<Entry>()
        try {
            contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(
                    CallLog.Calls.NUMBER,
                    CallLog.Calls.CACHED_NAME,
                    CallLog.Calls.TYPE,
                    CallLog.Calls.DATE,
                    CallLog.Calls._ID,
                    CallLog.Calls.DURATION
                ),
                null, null, CallLog.Calls.DATE + " DESC"
            )?.use { c ->
                while (c.moveToNext() && out.size < 100) {
                    val num = c.getString(0) ?: ""
                    val cached = c.getString(1)
                    val k = PhotoStore.key(num)
                    val name = (if (k.isNotEmpty()) names[k] else null) ?: cached
                    val type = c.getInt(2)
                    val date = c.getLong(3)
                    val logId = c.getLong(4)
                    val dur = c.getLong(5)
                    val title = if (!name.isNullOrBlank()) name
                    else if (num.isBlank()) getString(R.string.unknown) else num
                    val entry = Entry(
                        title,
                        num,
                        num,
                        type == CallLog.Calls.MISSED_TYPE,
                        logId = logId,
                        saved = !name.isNullOrBlank(),
                        type = type,
                        duration = dur,
                        date = date
                    )
                    out.add(entry.copy(subtitle = FaFormat.summary(this, entry)))
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun queryContacts(): List<Entry> {
        val out = ArrayList<Entry>()
        val seen = HashSet<String>()
        try {
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                    ContactsContract.CommonDataKinds.Phone.LOOKUP_KEY
                ),
                null, null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(0) ?: continue
                    val num = c.getString(1) ?: continue
                    val key = name + "|" + num.filter { it.isDigit() }
                    if (seen.add(key)) {
                        out.add(
                            Entry(
                                name, num, num,
                                contactId = c.getLong(2),
                                lookupKey = c.getString(3),
                                saved = true
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
        }
        return out
    }
}
