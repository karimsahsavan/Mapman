package com.shik.dialer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import java.util.Random
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Full-screen animated space for the call screen:
 * twinkling stars, drifting nebulae, a slowly turning spiral galaxy around the avatar,
 * radar-like pulse rings, dashed orbits with planets, flowing neon wave lines,
 * light streaks and shooting stars. Colours and energy follow the call state.
 */
class CosmicView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) :
    View(ctx, attrs) {

    enum class Mode(val color: Int, val energy: Float, val periodMs: Float) {
        RINGING(0xFF2EE59D.toInt(), 1.0f, 1700f),
        CALLING(0xFF4CC9F0.toInt(), 0.75f, 2400f),
        ACTIVE(0xFFB388FF.toInt(), 0.55f, 3400f),
        HOLD(0xFFFFB74D.toInt(), 0.25f, 4600f),
        ENDED(0xFFFF5C73.toInt(), 0.1f, 4200f)
    }

    /** The view the galaxy and rings are centred on (the avatar). */
    var anchor: View? = null

    private var mode = Mode.CALLING
    private var accent = mode.color
    private var energy = mode.energy
    private var period = mode.periodMs

    fun setMode(m: Mode) {
        mode = m
    }

    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()
    private val rnd = Random(11)

    private var running = false
    private var lastMs = 0L
    private var ringPhase = 0f
    private var galaxyRot = 0f
    private var wavePhase = 0f

    // ---- stars
    private val nStars = 120
    private val sx = FloatArray(nStars) { rnd.nextFloat() }
    private val sy = FloatArray(nStars) { rnd.nextFloat() }
    private val sr = FloatArray(nStars) { 0.5f + rnd.nextFloat() * 1.5f }
    private val sp = FloatArray(nStars) { rnd.nextFloat() * 6.28f }
    private val ss = FloatArray(nStars) { 0.6f + rnd.nextFloat() * 1.8f }
    private val sd = FloatArray(nStars) { 0.2f + rnd.nextFloat() }

    // ---- galaxy particles
    private val nGal = 240
    private val gr = FloatArray(nGal) { sqrt(rnd.nextFloat()) }
    private val garm = IntArray(nGal) { rnd.nextInt(3) }
    private val gjit = FloatArray(nGal) { (rnd.nextFloat() - 0.5f) * 0.9f }
    private val gsize = FloatArray(nGal) { 0.5f + rnd.nextFloat() * 1.3f }
    private val gtw = FloatArray(nGal) { rnd.nextFloat() * 6.28f }

    // ---- shooting star
    private var ssNext = 0L
    private var ssStart = 0L
    private var ssX = 0f
    private var ssY = 0f

    private var bg: Shader? = null
    private var neb1: Shader? = null
    private var neb2: Shader? = null
    private var neb3: Shader? = null
    private val glow: Shader = RadialGradient(
        0f, 0f, 100f,
        intArrayOf(0xFFFFFFFF.toInt(), 0x00FFFFFF),
        null, Shader.TileMode.CLAMP
    )

    private val loc1 = IntArray(2)
    private val loc2 = IntArray(2)
    private var ax = 0f
    private var ay = 0f
    private var ar = 0f

    private val tilt = (-18.0 * PI / 180.0).toFloat()
    private val ct = cos(tilt)
    private val st = sin(tilt)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (w <= 0 || h <= 0) return
        bg = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            intArrayOf(0xFF05030F.toInt(), 0xFF120833.toInt(), 0xFF0A1B3C.toInt()),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        val r = max(w, h) * 0.62f
        neb1 = RadialGradient(
            0f, 0f, r, intArrayOf(0x995B2A86.toInt(), 0x00000000), null, Shader.TileMode.CLAMP
        )
        neb2 = RadialGradient(
            0f, 0f, r, intArrayOf(0x80B5179E.toInt(), 0x00000000), null, Shader.TileMode.CLAMP
        )
        neb3 = RadialGradient(
            0f, 0f, r, intArrayOf(0x800E7C86.toInt(), 0x00000000), null, Shader.TileMode.CLAMP
        )
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        lastMs = SystemClock.uptimeMillis()
        invalidate()
    }

    override fun onDetachedFromWindow() {
        running = false
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        running = visibility == VISIBLE
        if (running) {
            lastMs = SystemClock.uptimeMillis()
            invalidate()
        }
    }

    private fun withA(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    private fun lerpColor(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    private fun resolveAnchor(w: Float, h: Float) {
        val a = anchor
        if (a != null && a.width > 0 && a.isAttachedToWindow) {
            a.getLocationInWindow(loc1)
            getLocationInWindow(loc2)
            ax = (loc1[0] - loc2[0]) + a.width / 2f
            ay = (loc1[1] - loc2[1]) + a.height / 2f
            ar = min(a.width, a.height) / 2f
        } else {
            ax = w / 2f
            ay = h * 0.32f
            ar = d * 60f
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val nowMs = SystemClock.uptimeMillis()
        val dt = (nowMs - lastMs).coerceIn(0L, 64L).toFloat()
        lastMs = nowMs
        val t = (nowMs % 1_000_000L) / 1000f
        val tau = (2.0 * PI).toFloat()

        energy += (mode.energy - energy) * 0.04f
        period += (mode.periodMs - period) * 0.04f
        accent = lerpColor(accent, mode.color, 0.05f)
        ringPhase = (ringPhase + dt / period) % 1f
        galaxyRot += dt * 0.00012f * (0.5f + energy)
        wavePhase += dt * 0.001f * (0.6f + energy * 1.2f)

        resolveAnchor(w, h)

        // --- space + nebulae
        p.style = Paint.Style.FILL
        p.colorFilter = null
        p.shader = bg
        c.drawRect(0f, 0f, w, h, p)

        val nebs = arrayOf(neb1, neb2, neb3)
        val nx = floatArrayOf(0.2f, 0.85f, 0.5f)
        val ny = floatArrayOf(0.18f, 0.5f, 0.92f)
        val nr = max(w, h) * 0.62f
        for (i in 0..2) {
            val s = nebs[i] ?: continue
            val x = w * (nx[i] + 0.1f * sin(t * 0.07f * (i + 1) + i * 2f))
            val y = h * (ny[i] + 0.06f * cos(t * 0.05f * (i + 2) + i))
            c.save()
            c.translate(x, y)
            p.shader = s
            c.drawCircle(0f, 0f, nr, p)
            c.restore()
        }

        // --- stars
        p.shader = null
        for (i in 0 until nStars) {
            val y = (sy[i] - t * 0.004f * sd[i]).let { it - kotlin.math.floor(it) }
            val x = sx[i] + 0.01f * sin(t * 0.2f + sp[i])
            val tw = 0.45f + 0.55f * (0.5f + 0.5f * sin(t * ss[i] + sp[i]))
            p.style = Paint.Style.FILL
            p.color = Color.argb((255 * tw).toInt(), 255, 255, 255)
            c.drawCircle(x * w, y * h, sr[i] * d * 0.8f, p)
            if (i % 9 == 0) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = d * 0.8f
                p.color = Color.argb((140 * tw).toInt(), 200, 220, 255)
                val len = d * (4f + 3f * tw)
                c.drawLine(x * w - len, y * h, x * w + len, y * h, p)
                c.drawLine(x * w, y * h - len, x * w, y * h + len, p)
            }
        }

        // --- diagonal light streaks (thin straight lines)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d * 1f
        for (i in 0..4) {
            val x0 = ((t * 22f * d * (1f + i * 0.35f)) + i * w / 4f) % (w + d * 240f) - d * 120f
            p.color = withA(Color.WHITE, 14 + (10 * energy).toInt())
            c.drawLine(x0, 0f, x0 - h * 0.35f, h, p)
        }

        // --- galaxy disc around the avatar
        val rMax = min(w, h) * (0.5f + 0.06f * energy)
        val r0 = ar * 0.95f
        p.style = Paint.Style.FILL
        val warm = 0xFFFFF1C9.toInt()
        val cool = lerpColor(0xFF7C4DFF.toInt(), accent, 0.5f)
        for (i in 0 until nGal) {
            val rr = r0 + gr[i] * rMax
            val ang = garm[i] * (tau / 3f) + gr[i] * 3.6f + gjit[i] + galaxyRot
            val dx = rr * cos(ang)
            val dy = rr * sin(ang) * 0.42f
            val x = ax + dx * ct - dy * st
            val y = ay + dx * st + dy * ct
            val tw = 0.6f + 0.4f * sin(t * 1.5f + gtw[i])
            val a = (230f * (1f - gr[i] * 0.75f) * tw).toInt()
            p.color = withA(lerpColor(warm, cool, gr[i]), a)
            c.drawCircle(x, y, gsize[i] * d, p)
        }

        // --- glow behind the avatar
        run {
            val pulse = 1f + 0.06f * sin(t * tau * 0.5f)
            val k = ar * 2.6f * pulse / 100f
            c.save()
            c.translate(ax, ay)
            c.scale(k, k)
            p.shader = glow
            p.colorFilter = PorterDuffColorFilter(
                withA(accent, (90 + 60 * energy).toInt()), PorterDuff.Mode.SRC_IN
            )
            c.drawCircle(0f, 0f, 100f, p)
            p.shader = null
            p.colorFilter = null
            c.restore()
        }

        // --- radar rings
        p.style = Paint.Style.STROKE
        for (k in 0..2) {
            val pr = (ringPhase + k / 3f) % 1f
            val rad = ar * (1.06f + 1.9f * pr)
            val a = ((1f - pr).pow(1.6f) * (110f + 110f * energy)).toInt()
            p.strokeWidth = d * (2.2f - 1.2f * pr)
            p.color = withA(accent, a)
            c.drawCircle(ax, ay, rad, p)
        }

        // --- dashed orbits with planets
        p.strokeWidth = d * 1f
        p.pathEffect = DashPathEffect(floatArrayOf(d * 3f, d * 7f), (t * 14f * d) % (d * 10f))
        p.color = withA(Color.WHITE, 60)
        c.drawCircle(ax, ay, ar * 1.5f, p)
        c.drawCircle(ax, ay, ar * 1.95f, p)
        p.pathEffect = null
        p.style = Paint.Style.FILL
        for (o in 0..1) {
            val rad = ar * (if (o == 0) 1.5f else 1.95f)
            val ang = if (o == 0) t * 0.9f else -t * 0.6f + 2f
            val px = ax + rad * cos(ang)
            val py = ay + rad * sin(ang)
            p.color = withA(if (o == 0) accent else 0xFF4CC9F0.toInt(), 70)
            c.drawCircle(px, py, d * 7f, p)
            p.color = Color.WHITE
            c.drawCircle(px, py, d * 2.6f, p)
        }

        // --- flowing neon waves
        val step = d * 8f
        for (i in 0..5) {
            val base = h * (0.6f + 0.045f * i)
            val amp = d * (9f + 5f * i) * (0.35f + energy)
            val freq = (1.6f + i * 0.35f) * tau / w
            val dir = if (i % 2 == 0) 1f else -1f
            val ph = wavePhase * (1f + i * 0.18f) * dir + i * 1.3f
            path.reset()
            var x = 0f
            var first = true
            while (x <= w + step) {
                val e = sin(PI.toFloat() * min(x, w) / w)
                val y = base + amp * e * sin(x * freq + ph) +
                        amp * 0.35f * e * sin(x * freq * 2.3f - ph * 1.4f)
                if (first) {
                    path.moveTo(x, y)
                    first = false
                } else path.lineTo(x, y)
                x += step
            }
            p.style = Paint.Style.STROKE
            p.strokeWidth = d * (1.1f + (i % 3) * 0.55f)
            val col = when (i % 3) {
                0 -> accent
                1 -> 0xFF7C4DFF.toInt()
                else -> 0xFF4CC9F0.toInt()
            }
            p.color = withA(col, 95 + (50 * energy).toInt() - i * 6)
            c.drawPath(path, p)
        }

        // --- shooting star
        if (nowMs > ssNext) {
            ssStart = nowMs
            ssNext = nowMs + 4500L + rnd.nextInt(5000)
            ssX = w * (0.35f + 0.6f * rnd.nextFloat())
            ssY = h * (0.02f + 0.25f * rnd.nextFloat())
        }
        val sprog = (nowMs - ssStart) / 900f
        if (sprog in 0f..1f) {
            val hx = ssX - sprog * w * 0.45f
            val hy = ssY + sprog * w * 0.3f
            p.style = Paint.Style.STROKE
            p.strokeWidth = d * 1.6f
            val fade = 1f - sprog
            for (j in 0 until 8) {
                val f0 = j / 8f
                val f1 = (j + 1) / 8f
                p.color = Color.argb((230 * fade * (1f - f0)).toInt(), 255, 255, 255)
                c.drawLine(
                    hx + f0 * w * 0.12f, hy - f0 * w * 0.08f,
                    hx + f1 * w * 0.12f, hy - f1 * w * 0.08f, p
                )
            }
        }

        if (running) postInvalidateOnAnimation()
    }
}
