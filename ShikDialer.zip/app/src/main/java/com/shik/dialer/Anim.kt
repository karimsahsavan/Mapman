package com.shik.dialer

import android.annotation.SuppressLint
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator

object Anim {
    @SuppressLint("ClickableViewAccessibility")
    fun press(v: View, scale: Float = 0.9f) {
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(scale).scaleY(scale)
                        .setDuration(90)
                        .setInterpolator(DecelerateInterpolator())
                        .start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f)
                        .setDuration(240)
                        .setInterpolator(OvershootInterpolator(3f))
                        .start()
            }
            false
        }
    }
}
