package ir.kian.hamrah

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.firebase.database.*

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("kian", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private var approvalListener: ValueEventListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun page(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 22, 24, 22)
            setBackgroundColor(0xFFFFF7ED.toInt())
        }
        setContentView(ScrollView(this).apply { addView(root) })
        root.addView(TextView(this).apply {
            text = title; textSize = 25f; gravity = Gravity.CENTER
            setTextColor(0xFFD9572D.toInt()); setPadding(0, 12, 0, 18)
        })
    }

    private fun field(hint: String, key: String, value: String? = null): EditText {
        val e = EditText(this).apply {
            this.hint = hint; setSingleLine(true); textSize = 15f
            setText(value ?: prefs.getString(key, "") ?: "")
        }
        root.addView(e, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 9 })
        return e
    }

    private fun button(label: String, action: () -> Unit) {
        root.addView(Button(this).apply { text = label; setOnClickListener { action() } },
            LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun saveCloud(api: String, app: String, project: String, url: String, family: String) {
        prefs.edit().putString("api", api).putString("app", app)
            .putString("project", project).putString("url", url)
            .putString("family", family).putString("role", "child").apply()
    }

    private fun cloudReady(done: () -> Unit) {
        val ok = Cloud.initialize(this,
            prefs.getString("api", "") ?: "", prefs.getString("app", "") ?: "",
            prefs.getString("project", "") ?: "", prefs.getString("url", "") ?: "")
        if (!ok) { toast("مشخصات Firebase کامل یا معتبر نیست."); showSettings(); return }
        val auth = Cloud.auth()
        if (auth.currentUser != null) done()
        else auth.signInAnonymously().addOnSuccessListener { done() }
            .addOnFailureListener { toast("اتصال به Firebase ناموفق: ${it.message}") }
    }

    private fun showHome(message: String = "") {
        page("کیان همراه فرزند")
        root.addView(TextView(this).apply {
            text = "این نسخه مخصوص گوشی فرزند است؛ نقشه ندارد و فقط پس از درخواست و تأیید والد، موقعیت را با اعلان دائمی ارسال می‌کند. هر زمان بخواهی می‌توانی اشتراک موقعیت را متوقف کنی.\n\n$message"
            textSize = 15f; setTextColor(0xFF49382F.toInt()); setPadding(4, 4, 4, 16)
        })
        val code = field("کد اتصال خانواده را وارد کن", "family")
        button("اتصال به خانواده") {
            val family = code.text.toString().trim()
            if (family.length < 8) { toast("کد خانواده معتبر نیست."); return@button }
            prefs.edit().putString("family", family).apply()
            cloudReady {
                val uid = Cloud.auth().currentUser!!.uid
                val req = Cloud.db().child("families").child(family).child("pairingRequests").child(uid)
                req.setValue(mapOf("requestedAt" to ServerValue.TIMESTAMP, "status" to "pending"))
                    .addOnSuccessListener {
                        toast("درخواست ارسال شد. والد باید آن را تأیید کند.")
                        watchApproval(family, uid)
                        showHome("درخواست اتصال ارسال شده است. پس از تأیید والد، ارسال موقعیت را شروع کن.")
                    }.addOnFailureListener { toast("ارسال درخواست ناموفق: ${it.message}") }
            }
        }
        button("بررسی وضعیت اتصال") { checkApproval() }
        button("شروع ارسال موقعیت") { checkApprovalThenStart() }
        button("توقف ارسال موقعیت") {
            stopService(Intent(this, LocationService::class.java))
            prefs.edit().putBoolean("sharing", false).apply()
            toast("اشتراک موقعیت متوقف شد.")
            showHome("اشتراک موقعیت خاموش است.")
        }
        button("تنظیمات Firebase") { showSettings() }
        val sharing = prefs.getBoolean("sharing", false)
        root.addView(TextView(this).apply {
            text = if (sharing) "● اشتراک موقعیت: فعال" else "○ اشتراک موقعیت: خاموش"
            textSize = 16f; gravity = Gravity.CENTER; setTextColor(if (sharing) 0xFF238447.toInt() else 0xFF777777.toInt())
            setPadding(0, 14, 0, 4)
        })
    }

    private fun showSettings() {
        page("تنظیمات اتصال")
        root.addView(TextView(this).apply {
            text = "چهار مقدار Firebase باید دقیقاً مانند برنامه والد باشد. این مقادیر فقط روی همین گوشی ذخیره می‌شوند."
            textSize = 14f; setPadding(0, 0, 0, 12)
        })
        val api = field("Firebase API Key", "api")
        val app = field("Firebase App ID", "app")
        val project = field("Firebase Project ID", "project")
        val url = field("Realtime Database URL", "url")
        button("ذخیره و آزمایش اتصال") {
            val family = prefs.getString("family", "") ?: ""
            saveCloud(api.text.toString().trim(), app.text.toString().trim(),
                project.text.toString().trim(), url.text.toString().trim(), family)
            if (listOf(api, app, project, url).any { it.text.isNullOrBlank() }) {
                toast("همه چهار مقدار را وارد کن."); return@button
            }
            cloudReady { toast("اتصال Firebase برقرار شد."); showHome() }
        }
        button("بازگشت") { showHome() }
    }

    private fun checkApproval() {
        val family = prefs.getString("family", "") ?: ""
        if (family.isBlank()) { toast("ابتدا کد خانواده را وارد کن."); return }
        cloudReady {
            val uid = Cloud.auth().currentUser!!.uid
            Cloud.db().child("families").child(family).child("childUid").get()
                .addOnSuccessListener { s ->
                    if (s.getValue(String::class.java) == uid) toast("اتصال تأیید شده است.")
                    else toast("هنوز والد درخواست را تأیید نکرده است.")
                }.addOnFailureListener { toast("بررسی اتصال ناموفق بود: ${it.message}") }
        }
    }

    private fun watchApproval(family: String, uid: String) {
        val ref = Cloud.db().child("families").child(family).child("childUid")
        approvalListener?.let { ref.removeEventListener(it) }
        approvalListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.getValue(String::class.java) == uid)
                    toast("والد اتصال را تأیید کرد. اکنون می‌توانی ارسال موقعیت را شروع کنی.")
            }
            override fun onCancelled(error: DatabaseError) { toast(error.message) }
        }
        ref.addValueEventListener(approvalListener!!)
    }

    private fun checkApprovalThenStart() {
        val family = prefs.getString("family", "") ?: ""
        if (family.isBlank()) { toast("ابتدا کد خانواده را وارد کن."); return }
        cloudReady {
            val uid = Cloud.auth().currentUser!!.uid
            Cloud.db().child("families").child(family).child("childUid").get()
                .addOnSuccessListener { snap ->
                    if (snap.getValue(String::class.java) != uid) {
                        toast("هنوز والد اتصال را تأیید نکرده است."); return@addOnSuccessListener
                    }
                    requestLocationPermissions()
                }.addOnFailureListener { toast("بررسی تأیید ناموفق بود.") }
        }
    }

    private fun requestLocationPermissions() {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        if (needed.isNotEmpty()) ActivityCompat.requestPermissions(this, needed.toTypedArray(), 82)
        else startSharingService()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != 82) return
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine) { toast("برای ارسال موقعیت، مجوز مکان دقیق لازم است."); return }
        if (Build.VERSION.SDK_INT >= 29 && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            toast("برای ادامه کار وقتی برنامه بسته است، در تنظیمات برنامه مجوز مکان را روی «همیشه مجاز» بگذار. در اندروید ۸ این مجوز جداگانه وجود ندارد.")
            try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } catch (_: Exception) {}
            return
        }
        startSharingService()
    }

    private fun startSharingService() {
        try {
            val intent = Intent(this, LocationService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            prefs.edit().putBoolean("sharing", true).apply()
            toast("ارسال موقعیت فعال شد. اعلان دائمی را می‌بینی.")
            showHome("اشتراک موقعیت فعال است.")
        } catch (e: Exception) { toast("شروع سرویس ناموفق بود: ${e.message}") }
    }

    override fun onDestroy() {
        approvalListener?.let {
            val family = prefs.getString("family", "") ?: ""
            if (family.isNotBlank()) Cloud.db().child("families").child(family).child("childUid").removeEventListener(it)
        }
        super.onDestroy()
    }
}
