package ir.kian.hamrah

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import com.google.firebase.database.ServerValue

class LocationService : Service() {
    private lateinit var fused: FusedLocationProviderClient
    private lateinit var callback: LocationCallback
    private val prefs by lazy { getSharedPreferences("kian", MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(41, notification())
        // A sticky foreground service may be recreated after the process is killed.
        // Rebuild Firebase from the values saved by the setup screen before using it.
        val cloudReady = Cloud.initialize(
            this,
            prefs.getString("api", "") ?: "",
            prefs.getString("app", "") ?: "",
            prefs.getString("project", "") ?: "",
            prefs.getString("url", "") ?: ""
        )
        if (!cloudReady || com.google.firebase.auth.FirebaseAuth.getInstance().currentUser == null) {
            stopSelf()
            return
        }
        fused = LocationServices.getFusedLocationProviderClient(this)
        callback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                val loc = result.lastLocation ?: return
                val family = prefs.getString("family", "") ?: return
                val user = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser ?: return
                val payload = mapOf(
                    "lat" to loc.latitude, "lon" to loc.longitude,
                    "accuracy" to loc.accuracy, "speed" to loc.speed,
                    "bearing" to loc.bearing, "time" to ServerValue.TIMESTAMP,
                    "uid" to user.uid
                )
                val ref = Cloud.db().child("families").child(family)
                ref.child("lastLocation").setValue(payload)
                ref.child("history").push().setValue(payload)
            }
        }
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 5000L)
            .setMinUpdateIntervalMillis(4000L)
            .setMaxUpdateDelayMillis(5000L)
            .setWaitForAccurateLocation(false)
            .build()
        try {
            fused.requestLocationUpdates(request, callback, mainLooper)
        } catch (_: SecurityException) {
            stopSelf()
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("kian_location", "اشتراک موقعیت", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification =
        NotificationCompat.Builder(this, "kian_location")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("کیان همراه فعال است")
            .setContentText("اشتراک موقعیت فعال است؛ برای توقف، برنامه را باز کن.")
            .setOngoing(true)
            .build()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onDestroy() {
        if (::fused.isInitialized && ::callback.isInitialized) fused.removeLocationUpdates(callback)
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
