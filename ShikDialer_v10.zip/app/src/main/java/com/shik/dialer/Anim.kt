package com.shik.dialer

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import java.util.WeakHashMap
import kotlin.math.min

/** Neon ring that lights up around a view while it is touched. */
class NeonGlow(
    color: Int,
    private val radius: Float, // < 0 = circle
    private val spread: Float,
    private val d: Float
) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val r = RectF()
    private val cr = Color.red(color)
    private val cg = Color.green(color)
    private val cb = Color.blue(color)
    private val coreColor = Color.rgb(
        cr + (255 - cr) * 35 / 100, cg + (255 - cg) * 35 / 100, cb + (255 - cb) * 35 / 100
    )

    var level = 0f
        set(v) {
            field = v
            invalidateSelf()
        }

    override fun draw(c: Canvas) {
        if (level <= 0.01f) return
        val b = bounds
        val steps = 10
        val step = spread / steps
        for (i in steps downTo 1) {
            val g = i * step
            r.set(b.left + spread - g, b.top + spread - g, b.right - spread + g, b.bottom - spread + g)
            val f = i / steps.toFloat()
            val a = (level * (150f * (1f - f) * (1f - f) + 10f)).toInt().coerceIn(0, 255)
            p.strokeWidth = step * 1.7f
            p.color = Color.argb(a, cr, cg, cb)
            val rad = if (radius < 0f) min(r.width(), r.height()) / 2f else radius + g
            c.drawRoundRect(r, rad, rad, p)
        }
        r.set(b.left + spread, b.top + spread, b.right - spread, b.bottom - spread)
        p.strokeWidth = 2.4f * d
        p.color = Color.argb((level * 255).toInt().coerceIn(0, 255), Color.red(coreColor), Color.green(coreColor), Color.blue(coreColor))
        val rad = if (radius < 0f) min(r.width(), r.height()) / 2f else radius
        c.drawRoundRect(r, rad, rad, p)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

object Anim {
    private class State {
        var glow: NeonGlow? = null
        var anim: ValueAnimator? = null
    }

    private val states = WeakHashMap<View, State>()

    /**
     * Press animation. With [neon] the view also lights up with a neon ring while touched;
     * [radiusDp] < 0 means a round view.
     */
    @SuppressLint("ClickableViewAccessibility")
    fun press(v: View, scale: Float = 0.9f, neon: (() -> Int)? = null, radiusDp: Float = -1f) {
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.animate().scaleX(scale).scaleY(scale)
                        .setDuration(90)
                        .setInterpolator(DecelerateInterpolator())
                        .start()
                    if (neon != null) glowOn(view, neon(), radiusDp)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.animate().scaleX(1f).scaleY(1f)
                        .setDuration(240)
                        .setInterpolator(OvershootInterpolator(3f))
                        .start()
                    if (neon != null) glowOff(view)
                }
            }
            false
        }
    }

    private fun glowOn(view: View, color: Int, radiusDp: Float) {
        val d = view.resources.displayMetrics.density
        val st = states.getOrPut(view) { State() }
        st.anim?.cancel()
        st.glow?.let { view.overlay.remove(it) }
        // let the light spill outside the parents too
        var p = view.parent
        while (p is ViewGroup) {
            p.clipChildren = false
            p = p.parent
        }
        val spread = 12f * d
        val g = NeonGlow(color, if (radiusDp < 0f) -1f else radiusDp * d, spread, d)
        g.setBounds(
            (-spread).toInt(), (-spread).toInt(),
            (view.width + spread).toInt(), (view.height + spread).toInt()
        )
        view.overlay.add(g)
        st.glow = g
        st.anim = ValueAnimator.ofFloat(g.level, 1f).apply {
            duration = 110
            addUpdateListener { g.level = it.animatedValue as Float }
            start()
        }
    }

    private fun glowOff(view: View) {
        val st = states[view] ?: return
        val g = st.glow ?: return
        st.anim?.cancel()
        st.anim = ValueAnimator.ofFloat(g.level, 0f).apply {
            duration = 650
            addUpdateListener { g.level = it.animatedValue as Float }
            addListener(object : AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(animation: Animator) {
                    cancelled = true
                }

                override fun onAnimationEnd(animation: Animator) {
                    if (cancelled) return
                    view.overlay.remove(g)
                    if (st.glow === g) st.glow = null
                }
            })
            start()
        }
    }
}
