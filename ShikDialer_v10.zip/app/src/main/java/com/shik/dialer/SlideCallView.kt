package com.shik.dialer

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import androidx.core.content.ContextCompat
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Incoming-call control: one round knob in the middle of a pill-shaped track.
 * Drag it to the right to answer (green) or to the left to decline (red).
 * While idle the knob breathes, glows and nudges, and arrows flow towards both sides.
 */
class SlideCallView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) :
    View(ctx, attrs) {

    var onAnswer: (() -> Unit)? = null
    var onDecline: (() -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val green = 0xFF1FC46A.toInt()
    private val red = 0xFFF0524A.toInt()
    private val dark = 0xFF1A1040.toInt()

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = 16f * resources.displayMetrics.scaledDensity
    }
    private val rect = RectF()
    private val path = Path()

    private val icCall: Drawable = ContextCompat.getDrawable(ctx, R.drawable.ic_call)!!.mutate()
    private val icEnd: Drawable = ContextCompat.getDrawable(ctx, R.drawable.ic_call_end)!!.mutate()

    private val knobR = 46f * d
    private val trackH = 96f * d
    private val edge = 4f * d

    private var dx = 0f
    private var downX = 0f
    private var startDx = 0f
    private var dragging = false
    private var armed = false
    private var locked = false
    private var phase = 0f

    private var idle: ValueAnimator? = null
    private var move: ValueAnimator? = null

    init {
        contentDescription = context.getString(R.string.incoming)
    }

    private fun maxDx(): Float = max(1f, width / 2f - knobR - edge)

    // ------------------------------------------------------------------ lifecycle

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        setMeasuredDimension(
            resolveSize(suggestedMinimumWidth, wSpec),
            resolveSize((124f * d).toInt(), hSpec)
        )
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        startIdle()
    }

    override fun onDetachedFromWindow() {
        stopIdle()
        move?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE && isAttachedToWindow) startIdle() else stopIdle()
    }

    private fun startIdle() {
        if (idle != null || visibility != VISIBLE) return
        idle = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1700
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                phase = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun stopIdle() {
        idle?.cancel()
        idle = null
    }

    /** Puts the knob back in the middle so the control can be used for a new call. */
    fun reset() {
        move?.cancel()
        locked = false
        dragging = false
        armed = false
        dx = 0f
        invalidate()
    }

    // ------------------------------------------------------------------ touch

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (locked) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val cx = width / 2f + dx
                if (abs(e.x - cx) <= knobR * 1.6f) {
                    move?.cancel()
                    dragging = true
                    armed = false
                    downX = e.x
                    startDx = dx
                    parent?.requestDisallowInterceptTouchEvent(true)
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    invalidate()
                    return true
                }
                return false
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging) return false
                val m = maxDx()
                dx = (startDx + e.x - downX).coerceIn(-m, m)
                val now = abs(dx) / m >= THRESHOLD
                if (now && !armed) performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                armed = now
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!dragging) return false
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(false)
                if (abs(dx) / maxDx() >= THRESHOLD) complete(dx > 0f) else springBack()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                if (!dragging) return false
                dragging = false
                springBack()
                return true
            }
        }
        return true
    }

    private fun springBack() {
        move?.cancel()
        move = ValueAnimator.ofFloat(dx, 0f).apply {
            duration = 420
            interpolator = OvershootInterpolator(2.4f)
            addUpdateListener {
                dx = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun complete(answer: Boolean) {
        locked = true
        move?.cancel()
        val target = if (answer) maxDx() else -maxDx()
        move = ValueAnimator.ofFloat(dx, target).apply {
            duration = 140
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                dx = it.animatedValue as Float
                invalidate()
            }
            addListener(object : AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(animation: Animator) {
                    cancelled = true
                }

                override fun onAnimationEnd(animation: Animator) {
                    if (cancelled) return
                    if (answer) onAnswer?.invoke() else onDecline?.invoke()
                }
            })
            start()
        }
    }

    // ------------------------------------------------------------------ drawing

    private fun blend(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        return Color.argb(
            (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * k).toInt(),
            (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
        )
    }

    private fun chevron(c: Canvas, x: Float, cy: Float, right: Boolean) {
        val s = 6f * d
        val h = 10f * d
        path.reset()
        if (right) {
            path.moveTo(x - s, cy - h)
            path.lineTo(x + s, cy)
            path.lineTo(x - s, cy + h)
        } else {
            path.moveTo(x + s, cy - h)
            path.lineTo(x - s, cy)
            path.lineTo(x + s, cy + h)
        }
        c.drawPath(path, paint)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cy = h / 2f
        val m = maxDx()
        val p = (dx / m).coerceIn(-1f, 1f)
        val ap = abs(p)
        val tint = if (p >= 0f) green else red
        val tau = (2.0 * PI).toFloat()

        // ---- track
        rect.set(edge, cy - trackH / 2f, w - edge, cy + trackH / 2f)
        paint.style = Paint.Style.FILL
        paint.color = 0x26FFFFFF
        c.drawRoundRect(rect, trackH / 2f, trackH / 2f, paint)
        if (ap > 0.01f) {
            paint.color = Color.argb((170 * min(1f, ap * 1.3f)).toInt(), Color.red(tint), Color.green(tint), Color.blue(tint))
            c.drawRoundRect(rect, trackH / 2f, trackH / 2f, paint)
        }
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.2f * d
        paint.color = 0x40FFFFFF
        c.drawRoundRect(rect, trackH / 2f, trackH / 2f, paint)

        // ---- labels (fade while dragging)
        val labelA = (1f - ap * 1.6f).coerceIn(0f, 1f)
        if (labelA > 0f) {
            text.color = Color.argb((210 * labelA).toInt(), 255, 255, 255)
            val ty = cy - (text.descent() + text.ascent()) / 2f
            c.drawText(context.getString(R.string.decline), edge + 58f * d, ty, text)
            c.drawText(context.getString(R.string.answer), w - edge - 58f * d, ty, text)
        }

        // ---- flowing chevrons on both sides
        val chevA = (1f - ap * 1.8f).coerceIn(0f, 1f)
        if (chevA > 0f) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3f * d
            paint.strokeCap = Paint.Cap.ROUND
            paint.strokeJoin = Paint.Join.ROUND
            for (i in 0..2) {
                val wave = 0.5f + 0.5f * sin((phase - i / 3f) * tau)
                val a = (60f + 195f * wave) * chevA
                val off = knobR + 20f * d + i * 20f * d
                paint.color = Color.argb(a.toInt(), 0x7B, 0xF0, 0xB0)
                chevron(c, w / 2f + off, cy, true)
                paint.color = Color.argb(a.toInt(), 0xFF, 0x9A, 0x92)
                chevron(c, w / 2f - off, cy, false)
            }
            paint.strokeCap = Paint.Cap.BUTT
        }

        // ---- knob
        val idleOn = !dragging && !locked && ap < 0.02f
        val nudge = if (idleOn) sin(phase * tau) * 5f * d else 0f
        val cx = w / 2f + dx + nudge

        if (idleOn) {
            val ringT = phase
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2.5f * d
            paint.color = Color.argb((120 * (1f - ringT)).toInt(), 255, 255, 255)
            c.drawCircle(cx, cy, knobR + 13f * d * ringT, paint)
            val ringT2 = (phase + 0.5f) % 1f
            paint.color = Color.argb((90 * (1f - ringT2)).toInt(), 255, 255, 255)
            c.drawCircle(cx, cy, knobR + 13f * d * ringT2, paint)
        }

        // soft halo that grows with the drag
        if (ap > 0.01f) {
            paint.style = Paint.Style.FILL
            paint.color = Color.argb((90 * ap).toInt(), Color.red(tint), Color.green(tint), Color.blue(tint))
            c.drawCircle(cx, cy, knobR + 10f * d * ap, paint)
        }

        // neon light around the knob while it is dragged
        if (dragging || ap > 0.01f) {
            val neon = blend(0xFF35E0FF.toInt(), tint, min(1f, ap * 3f))
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2.6f * d
            for (i in 1..9) {
                val f = i / 9f
                val a = (170f * (1f - f) * (1f - f) + 12f).toInt()
                paint.color = Color.argb(a, Color.red(neon), Color.green(neon), Color.blue(neon))
                c.drawCircle(cx, cy, knobR + 14f * d * f, paint)
            }
        }

        val breathe = if (idleOn) 1f + 0.04f * sin(phase * tau * 2f) else 1f + 0.08f * ap
        paint.style = Paint.Style.FILL
        paint.color = blend(0xFFFFFFFF.toInt(), tint, min(1f, ap * 1.6f))
        c.drawCircle(cx, cy, knobR * breathe, paint)

        val icon = if (p < -0.02f) icEnd else icCall
        icon.setTint(blend(dark, Color.WHITE, min(1f, ap * 1.8f)))
        val half = (21f * d * breathe).toInt()
        c.save()
        // the handset tilts a little in the direction of the drag
        c.rotate(p * 14f, cx, cy)
        icon.setBounds((cx - half).toInt(), (cy - half).toInt(), (cx + half).toInt(), (cy + half).toInt())
        icon.draw(c)
        c.restore()
    }

    private companion object {
        const val THRESHOLD = 0.78f
    }
}
