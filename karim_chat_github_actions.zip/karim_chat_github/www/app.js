import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, updateProfile, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getDatabase, ref, push, onChildAdded, query, limitToLast, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-database.js";

// مقادیر قابل مشاهده در تصویر ارسالی
const firebaseConfig = {
  apiKey: "AlzaSyCfE3k_jd5kBupVGmjDusxg4-3mlygQImc",
  authDomain: "karim-d498f.firebaseapp.com",
  databaseURL: "https://karim-d498f.firebaseio.com",
  projectId: "karim-d498f",
  storageBucket: "karim-d498f.appspot.com",
  messagingSenderId: "155259908435",
  appId: "1:155259908435:android:ce09b0d8bde059d85bb1a6"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);
const $ = id => document.getElementById(id);
let stopMessages = null;

function usernameEmail(name) {
  // نام کاربری به شناسه ایمیل‌مانند برای Firebase Authentication تبدیل می‌شود.
  return name.trim().toLowerCase().replace(/[^a-z0-9_.-]/g, "") + "@karim-chat.app";
}
function toast(text) {
  $("toast").textContent = text;
  $("toast").classList.add("show");
  setTimeout(() => $("toast").classList.remove("show"), 2600);
}
function safeText(value) { return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }

$("signup").addEventListener("click", async () => {
  const name = $("username").value.trim();
  const pass = $("password").value;
  if (!/^[a-zA-Z0-9_.-]{3,24}$/.test(name)) return $("authmsg").textContent = "نام کاربری انگلیسی، ۳ تا ۲۴ حرف باشد.";
  if (pass.length < 6) return $("authmsg").textContent = "رمز عبور باید حداقل ۶ کاراکتر باشد.";
  try {
    const cred = await createUserWithEmailAndPassword(auth, usernameEmail(name), pass);
    await updateProfile(cred.user, { displayName: name });
    $("authmsg").textContent = "";
  } catch (e) { $("authmsg").textContent = friendly(e); }
});
$("signin").addEventListener("click", async () => {
  const name = $("username").value.trim(), pass = $("password").value;
  if (!name || !pass) return $("authmsg").textContent = "نام کاربری و رمز عبور را وارد کنید.";
  try { await signInWithEmailAndPassword(auth, usernameEmail(name), pass); $("authmsg").textContent = ""; }
  catch (e) { $("authmsg").textContent = friendly(e); }
});
$("logout").addEventListener("click", () => signOut(auth));
function friendly(e) {
  const map = {
    "auth/invalid-credential":"نام کاربری یا رمز عبور اشتباه است.",
    "auth/email-already-in-use":"این نام کاربری قبلاً ثبت شده است.",
    "auth/weak-password":"رمز عبور ضعیف است.",
    "auth/operation-not-allowed":"ورود با ایمیل/رمز در Firebase فعال نشده است.",
    "auth/network-request-failed":"اتصال اینترنت را بررسی کنید."
  };
  return map[e.code] || "خطا: " + (e.message || e.code);
}
function renderMessage(data, me) {
  const empty = document.querySelector(".empty"); if (empty) empty.remove();
  const el = document.createElement("article");
  el.className = "bubble " + (data.uid === me ? "mine" : "other");
  const date = data.createdAt ? new Date(data.createdAt).toLocaleTimeString("fa-IR",{hour:"2-digit",minute:"2-digit"}) : "اکنون";
  el.innerHTML = `<div class="sender">${safeText(data.name || "کاربر")}</div><div class="body">${safeText(data.text)}</div><div class="time">${safeText(date)}</div>`;
  $("messages").appendChild(el);
  $("messages").scrollTop = $("messages").scrollHeight;
}
onAuthStateChanged(auth, user => {
  $("auth").hidden = !!user;
  $("chat").hidden = !user;
  $("logout").hidden = !user;
  $("status").textContent = user ? "گفتگوی آنلاین" : "گفتگوی خصوصی";
  if (stopMessages) { stopMessages(); stopMessages = null; }
  $("messages").innerHTML = '<div class="empty">در حال دریافت پیام‌ها…</div>';
  if (user) {
    const q = query(ref(db, "messages"), limitToLast(150));
    stopMessages = onChildAdded(q, snap => renderMessage(snap.val() || {}, user.uid));
  }
});
$("sendform").addEventListener("submit", async e => {
  e.preventDefault();
  const user = auth.currentUser, text = $("message").value.trim();
  if (!user || !text) return;
  $("message").value = "";
  try {
    await push(ref(db, "messages"), { uid:user.uid, name:user.displayName || "کاربر", text, createdAt:Date.now() });
  } catch (err) { toast("ارسال نشد؛ قوانین دسترسی Firebase را بررسی کنید."); $("message").value = text; }
});
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  navigator.serviceWorker.register("./sw.js").catch(()=>{});
}