const CACHE="karim-chat-v1";
self.addEventListener("install", e => e.waitUntil(caches.open(CACHE).then(c=>c.addAll(["./","./index.html","./style.css"]))));
self.addEventListener("fetch", e => {
  if (e.request.method !== "GET" || new URL(e.request.url).origin !== self.location.origin) return;
  e.respondWith(caches.match(e.request).then(r=>r || fetch(e.request)));
});