package com.galaxydialer.pro

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.CallLog
import android.view.Gravity
import android.view.View
import android.widget.*
import android.media.MediaRecorder
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 13, 24)
    private val panel = Color.rgb(22, 30, 48)
    private val green = Color.rgb(45, 217, 137)
    private val white = Color.rgb(242, 246, 255)
    private val muted = Color.rgb(155, 169, 192)
    private lateinit var root: LinearLayout
    private lateinit var number: EditText
    private var recorder: MediaRecorder? = null
    private var recording = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float, color: Int = white, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setTextColor(white)
            setBackgroundColor(panel)
            setOnClickListener { action() }
        }

    private fun base(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(16))
            setBackgroundColor(bg)
        }
        val heading = text(title, 26f, white, true)
        root.addView(heading, LinearLayout.LayoutParams(-1, dp(58)))
        setContentView(root)
    }

    private fun buildHome() {
        base("تلفن")
        root.addView(text("Galaxy Dialer Pro  •  نسخه ۱.۰", 13f, muted))
        root.addView(space(16))
        number = EditText(this).apply {
            hint = "شماره تلفن"
            textSize = 30f
            setTextColor(white)
            setHintTextColor(muted)
            gravity = Gravity.CENTER
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_PHONE
            setBackgroundColor(panel)
            setPadding(dp(12), dp(14), dp(12), dp(14))
        }
        root.addView(number, LinearLayout.LayoutParams(-1, dp(70)))
        root.addView(space(12))

        val keys = listOf(
            listOf("۱", "۲", "۳"), listOf("۴", "۵", "۶"),
            listOf("۷", "۸", "۹"), listOf("*", "۰", "⌫")
        )
        keys.forEach { row ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.forEach { key ->
                val b = button(key) {
                    if (key == "⌫") {
                        val s = number.text.toString()
                        if (s.isNotEmpty()) number.setText(s.dropLast(1))
                    } else number.append(key)
                }
                line.addView(b, LinearLayout.LayoutParams(0, dp(64), 1f).apply {
                    setMargins(dp(4), dp(4), dp(4), dp(4))
                })
            }
            root.addView(line)
        }

        val call = Button(this).apply {
            text = "☎   تماس"
            textSize = 19f
            isAllCaps = false
            setTextColor(Color.BLACK)
            setBackgroundColor(green)
            setOnClickListener { dial() }
        }
        root.addView(call, LinearLayout.LayoutParams(-1, dp(58)).apply {
            setMargins(0, dp(12), 0, dp(12))
        })
        root.addView(button("مخاطبین", ::showContacts), LinearLayout.LayoutParams(-1, dp(48)))
        root.addView(space(8))
        root.addView(button("تاریخچه تماس‌ها", ::showCallLog), LinearLayout.LayoutParams(-1, dp(48)))
        root.addView(space(8))
        root.addView(button("ضبط‌های صوتی", ::showRecordings), LinearLayout.LayoutParams(-1, dp(48)))
        root.addView(space(10))
        root.addView(text("ضبط مکالمه تلفنی در اندروید و بسته به مدل/منطقه ممکن است مسدود باشد.", 12f, muted))
    }

    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }

    private fun dial() {
        val value = number.text.toString().trim()
        if (value.isBlank()) {
            Toast.makeText(this, "ابتدا شماره را وارد کنید", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(value)}")))
    }

    private fun showContacts() {
        base("مخاطبین")
        val search = EditText(this).apply {
            hint = "جست‌وجوی مخاطب"
            setTextColor(white); setHintTextColor(muted); textSize = 16f
            setBackgroundColor(panel)
        }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(52)))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this); scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        fun load(filter: String = "") {
            list.removeAllViews()
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 10)
                list.addView(text("برای نمایش مخاطبین، مجوز مخاطبین را تأیید کنید.", 15f, muted))
                return
            }
            val cursor: Cursor? = contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC"
            )
            cursor?.use {
                while (it.moveToNext()) {
                    val name = it.getString(0) ?: ""
                    val phone = it.getString(1) ?: ""
                    if (name.contains(filter, true) || phone.contains(filter)) {
                        val item = button("$name\n$phone") {
                            number.setText(phone)
                            dial()
                        }
                        list.addView(item, LinearLayout.LayoutParams(-1, dp(62)).apply {
                            setMargins(0, dp(3), 0, dp(3))
                        })
                    }
                }
            }
        }
        search.addTextChangedListener(SimpleWatcher { load(it) })
        load()
        root.addView(button("بازگشت", ::buildHome))
    }

    private fun showCallLog() {
        base("تاریخچه تماس")
        if (checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_CALL_LOG), 11)
            root.addView(text("برای خواندن تاریخچه تماس، مجوز لازم است.", 15f, muted))
        } else {
            val scroll = ScrollView(this)
            val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            scroll.addView(list); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
            val c = contentResolver.query(CallLog.Calls.CONTENT_URI, arrayOf(
                CallLog.Calls.CACHED_NAME, CallLog.Calls.NUMBER, CallLog.Calls.DATE, CallLog.Calls.TYPE
            ), null, null, CallLog.Calls.DATE + " DESC")
            c?.use {
                var count = 0
                while (it.moveToNext() && count++ < 100) {
                    val name = it.getString(0) ?: it.getString(1) ?: "نامشخص"
                    val date = SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.getDefault()).format(Date(it.getLong(2)))
                    val type = when (it.getInt(3)) {
                        CallLog.Calls.INCOMING_TYPE -> "ورودی"
                        CallLog.Calls.OUTGOING_TYPE -> "خروجی"
                        CallLog.Calls.MISSED_TYPE -> "ازدست‌رفته"
                        else -> "تماس"
                    }
                    list.addView(text("$name   •   $type\n$date", 15f, white).apply {
                        setPadding(0, dp(12), 0, dp(12))
                    })
                }
            }
        }
        root.addView(button("بازگشت", ::buildHome))
    }

    private fun showRecordings() {
        base("ضبط‌های صوتی")
        val dir = getExternalFilesDir("Recordings") ?: filesDir
        val files = dir.listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() } ?: emptyList()
        if (files.isEmpty()) root.addView(text("هنوز فایلی ذخیره نشده است.", 15f, muted))
        files.forEach { f ->
            root.addView(button("${f.name}\n${f.length() / 1024} KB") {
                try {
                    val intent = Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(Uri.fromFile(f), "audio/*")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(intent)
                } catch (_: Exception) {
                    Toast.makeText(this, "پخش‌کننده‌ای پیدا نشد", Toast.LENGTH_SHORT).show()
                }
            }, LinearLayout.LayoutParams(-1, dp(64)))
        }
        root.addView(space(10))
        root.addView(text("ضبط مکالمه با محدودیت‌های سخت‌افزاری و نرم‌افزاری اندروید روبه‌رو است. این برنامه ضبط مخفی انجام نمی‌دهد.", 13f, muted))
        root.addView(button(if (recording) "توقف ضبط" else "آزمایش ضبط صدا") {
            if (recording) stopRecording() else startRecording()
        }, LinearLayout.LayoutParams(-1, dp(52)))
        root.addView(button("بازگشت", ::buildHome))
    }

    private fun startRecording() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 12)
            return
        }
        try {
            val dir = getExternalFilesDir("Recordings") ?: filesDir
            val file = File(dir, "Audio_${System.currentTimeMillis()}.m4a")
            val r = MediaRecorder()
            // VOICE_CALL is restricted on many Android builds and may throw SecurityException.
            r.setAudioSource(MediaRecorder.AudioSource.VOICE_CALL)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setOutputFile(file.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            recording = true
            Toast.makeText(this, "ضبط شروع شد؛ فقط در دستگاه‌های مجاز", Toast.LENGTH_LONG).show()
            showRecordings()
        } catch (e: Exception) {
            try { recorder?.release() } catch (_: Exception) {}
            recorder = null
            recording = false
            Toast.makeText(this, "این گوشی اجازه ضبط صدای تماس را نمی‌دهد. ضبط مکالمه در این نسخه پشتیبانی نشد.", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopRecording() {
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        recording = false
        Toast.makeText(this, "ضبط متوقف شد", Toast.LENGTH_SHORT).show()
        showRecordings()
    }

    override fun onDestroy() {
        if (recording) stopRecording()
        super.onDestroy()
    }
}

private class SimpleWatcher(val changed: (String) -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed(s?.toString() ?: "") }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
