# Pixel Dialer — Compose starter

پروژه Kotlin + Jetpack Compose با طراحی الهام‌گرفته از Google Phone و Material 3.

## شامل
- Kotlin DSL و Version Catalog
- Compose Material 3 و Dynamic Color در Android 12+
- Navigation Compose با چهار تب
- MVVM-ready structure و Hilt
- Room entity/DAO/database برای تاریخچه
- DataStore preferences پایه
- Contacts Provider با جست‌وجوی فارسی/عربی و ارقام فارسی
- تماس با `ACTION_CALL` و درخواست مجوز در زمان اجرا
- manifest با مجوزهای درخواستی و targetSdk 34

## ساخت APK
تمام محتویات ZIP را در ریشه مخزن GitHub استخراج کنید؛ `settings.gradle.kts` باید مستقیماً در ریشه باشد. سپس Actions را اجرا کنید و Artifact را دریافت کنید.

## وضعیت فعلی و محدودیت‌ها
این یک پایه پروژه قابل توسعه است، نه Dialer نهایی و کامل:
- Recents فعلاً Empty State دارد؛ اتصال واقعی به CallLog و ذخیره Room هنوز پیاده نشده.
- Favorites و Contact Detail و In-Call UI کامل هنوز پیاده نشده‌اند.
- درخواست مجوز مخاطبین در UI فعلاً نیازمند تکمیل با Activity Result API است.
- WRITE_CALL_LOG و ANSWER_PHONE_CALLS در Manifest درج شده‌اند اما استفاده عملی و سیاست/نقش‌های لازم پیاده‌سازی نشده.
- برای تبدیل شدن به شماره‌گیر پیش‌فرض باید RoleManager + InCallService + UI تماس ورودی/فعال و جریان‌های Telecom به‌طور کامل پیاده‌سازی و روی دستگاه واقعی آزمایش شوند.
- Emergency call routing عمداً به شماره‌گیر سیستم واگذار می‌شود؛ برنامه نباید مسیر تماس اضطراری را دستکاری کند.
- Accompanist Permissions استفاده نشده؛ برای Compose جدید از AndroidX Activity Result API استفاده کنید.
- Multi-SIM/T9/Swipe actions/Shimmer/Google Fonts/Contact Detail نیازمند توسعه بیشتر هستند.

## پیش‌فرض کردن
در این نسخه هنوز نقش Dialer پیش‌فرض درخواست نمی‌شود. برای تماس، مجوز CALL_PHONE لازم است. برای تبدیل به شماره‌گیر پیش‌فرض باید اجزای Telecom را اضافه کنید و از کاربر تأیید رسمی RoleManager بگیرید.
