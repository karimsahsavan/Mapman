package com.example.dialer
import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.example.dialer.presentation.navigation.AppNavigation
import com.example.dialer.presentation.theme.PixelDialerTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    private val callPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) pendingNumber?.let(::placeCall)
    }
    private var pendingNumber: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val incoming = intent?.data?.schemeSpecificPart
        setContent {
            PixelDialerTheme {
                AppNavigation { number ->
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                        placeCall(number)
                    } else {
                        pendingNumber = number
                        callPermission.launch(Manifest.permission.CALL_PHONE)
                    }
                }
            }
        }
        if (!incoming.isNullOrBlank()) pendingNumber = incoming
    }

    private fun placeCall(number: String) {
        try {
            startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(number)}")))
        } catch (_: SecurityException) {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}")))
        }
    }
}
