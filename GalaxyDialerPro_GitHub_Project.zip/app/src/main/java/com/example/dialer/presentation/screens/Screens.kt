package com.example.dialer.presentation.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.content.pm.PackageManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.dialer.domain.model.Contact
import com.example.dialer.data.remote.ContactsProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun KeypadScreen(onCall: (String) -> Unit) {
    var digits by remember { mutableStateOf("") }
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().padding(horizontal=24.dp), horizontalAlignment=Alignment.CenterHorizontally) {
        Text("شماره‌گیر", style=MaterialTheme.typography.headlineMedium, modifier=Modifier.fillMaxWidth().padding(top=18.dp))
        Spacer(Modifier.height(16.dp))
        Text(if (digits.isBlank()) "شماره را وارد کنید" else digits, fontSize=32.sp, fontWeight=FontWeight.Medium,
            color=MaterialTheme.colorScheme.onSurface, modifier=Modifier.fillMaxWidth().height(58.dp))
        AnimatedVisibility(digits.isNotBlank()) { Text("جست‌وجوی مخاطب هنگام شماره‌گیری", color=MaterialTheme.colorScheme.onSurfaceVariant) }
        Spacer(Modifier.weight(1f))
        val keys = listOf("1","2","3","4","5","6","7","8","9","*","0","#")
        keys.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceEvenly) {
                row.forEach { key ->
                    Surface(
                        modifier=Modifier.padding(5.dp).size(76.dp).clip(CircleShape).clickable { digits += key },
                        shape=CircleShape, color=MaterialTheme.colorScheme.surfaceContainerHigh
                    ) {
                        Box(contentAlignment=Alignment.Center) {
                            Text(key, fontSize=27.sp, color=MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical=18.dp), horizontalArrangement=Arrangement.SpaceEvenly, verticalAlignment=Alignment.CenterVertically) {
            Spacer(Modifier.size(58.dp))
            FilledIconButton(onClick={ if(digits.isNotEmpty()) digits=digits.dropLast(1) }, modifier=Modifier.size(58.dp)) {
                Icon(Icons.Default.Backspace, contentDescription="حذف رقم")
            }
            FilledIconButton(onClick={ if(digits.isNotBlank()) onCall(digits) }, modifier=Modifier.size(68.dp),
                colors=IconButtonDefaults.filledIconButtonColors(containerColor=MaterialTheme.colorScheme.primary)) {
                Icon(Icons.Default.Call, contentDescription="تماس", tint=MaterialTheme.colorScheme.onPrimary)
            }
            Spacer(Modifier.size(58.dp))
        }
    }
}

@Composable
fun ContactsScreen() {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var contacts by remember { mutableStateOf<List<Contact>>(emptyList()) }
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)==PackageManager.PERMISSION_GRANTED) }
    LaunchedEffect(granted) {
        if (granted) contacts = withContext(Dispatchers.IO) { ContactsProvider(context.contentResolver).load() }
    }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("مخاطبین", style=MaterialTheme.typography.headlineMedium)
        OutlinedTextField(query, {query=it}, modifier=Modifier.fillMaxWidth(), label={Text("جست‌وجو")}, singleLine=true)
        if (!granted) {
            Button(onClick={ granted = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)==PackageManager.PERMISSION_GRANTED }) { Text("مجوز مخاطبین را از تنظیمات تأیید کنید") }
        } else {
            val filtered=contacts.filter { normalize(it.name).contains(normalize(query)) || normalize(it.number).contains(normalize(query)) }
            LazyColumn {
                items(filtered, key={it.id.toString()+it.number}) { c ->
                    ListItem(
                        headlineContent={Text(c.name)},
                        supportingContent={Text(c.number)},
                        leadingContent={Surface(Modifier.size(44.dp),shape=CircleShape,color=MaterialTheme.colorScheme.secondaryContainer){Box(contentAlignment=Alignment.Center){Text(c.name.take(1).ifBlank{"?"})}}}
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}

private fun normalize(value:String):String = value
    .replace('ي','ی').replace('ك','ک')
    .map { ch -> when(ch) { in '۰'..'۹' -> ('0'.code + (ch.code-'۰'.code)).toChar(); in '٠'..'٩' -> ('0'.code + (ch.code-'٠'.code)).toChar(); else -> ch } }
    .joinToString("").lowercase()

@Composable
fun RecentsScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("تماس‌های اخیر", style=MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(20.dp))
        EmptyState("تاریخچه تماس در این نسخه هنوز به Call Log سیستم متصل نشده است.")
    }
}
@Composable
fun FavoritesScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("علاقه‌مندی‌ها", style=MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(20.dp))
        EmptyState("مخاطب موردعلاقه‌ای اضافه نشده است.")
    }
}
@Composable
private fun EmptyState(message:String) {
    Box(Modifier.fillMaxWidth().padding(top=70.dp), contentAlignment=Alignment.Center) {
        Text(message, color=MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
