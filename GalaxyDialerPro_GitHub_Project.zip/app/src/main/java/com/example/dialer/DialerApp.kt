package com.example.dialer
import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class DialerApp : Application()
