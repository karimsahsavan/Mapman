package com.example.dialer.data.remote

import android.content.ContentResolver
import android.provider.ContactsContract
import com.example.dialer.domain.model.Contact
import javax.inject.Inject

class ContactsProvider @Inject constructor(private val resolver: ContentResolver) {
    fun load(): List<Contact> {
        val result = mutableListOf<Contact>()
        val cursor = resolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ), null, null,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC"
        ) ?: return result
        cursor.use {
            val idCol = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
            val nameCol = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numberCol = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (it.moveToNext()) {
                result += Contact(
                    id = it.getLong(idCol),
                    name = it.getString(nameCol).orEmpty(),
                    number = it.getString(numberCol).orEmpty()
                )
            }
        }
        return result.distinctBy { it.id to it.number }
    }
}
