package com.example.dialer.data.local
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface CallDao {
    @Query("SELECT * FROM call_history ORDER BY timestamp DESC")
    fun observeAll(): Flow<List<CallEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(call: CallEntity)
    @Query("DELETE FROM call_history WHERE id = :id")
    suspend fun delete(id: Long)
}
