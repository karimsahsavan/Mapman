package com.example.dialer.domain.repository
import com.example.dialer.domain.model.Contact

interface ContactsRepository {
    suspend fun contacts(): List<Contact>
}
