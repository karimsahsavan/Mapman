package com.example.dialer.data.repository
import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "user_settings")
class SettingsStore(private val context: Context) {
    private val darkKey = booleanPreferencesKey("dark_mode")
    val darkMode: Flow<Boolean> = context.dataStore.data.map { it[darkKey] ?: false }
    suspend fun setDarkMode(enabled: Boolean) { context.dataStore.edit { it[darkKey] = enabled } }
}
