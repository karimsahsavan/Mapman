package com.example.dialer.data.local
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "call_history")
data class CallEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val number: String,
    val displayName: String,
    val type: Int,
    val timestamp: Long,
    val durationSeconds: Long = 0
)
