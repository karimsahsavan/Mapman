package com.example.dialer.di
import android.content.Context
import androidx.room.Room
import com.example.dialer.data.local.DialerDatabase
import com.example.dialer.data.remote.ContactsProvider
import com.example.dialer.data.repository.ContactsRepositoryImpl
import com.example.dialer.domain.repository.ContactsRepository
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import dagger.hilt.android.components.ViewModelComponent
import dagger.hilt.android.scopes.ViewModelScoped
import dagger.hilt.android.scopes.ActivityRetainedScoped
import javax.inject.Singleton
import android.content.ContentResolver

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    @Provides @Singleton
    fun database(@ApplicationContext context: Context): DialerDatabase =
        Room.databaseBuilder(context, DialerDatabase::class.java, "pixel_dialer.db").build()
    @Provides fun callDao(db: DialerDatabase) = db.callDao()
    @Provides fun contentResolver(@ApplicationContext context: Context): ContentResolver = context.contentResolver
    @Provides fun contactsProvider(resolver: ContentResolver) = ContactsProvider(resolver)
}

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {
    @Binds abstract fun contactsRepository(impl: ContactsRepositoryImpl): ContactsRepository
}
