package com.example.dialer.data.repository
import com.example.dialer.data.remote.ContactsProvider
import com.example.dialer.domain.model.Contact
import com.example.dialer.domain.repository.ContactsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject

class ContactsRepositoryImpl @Inject constructor(
    private val provider: ContactsProvider
) : ContactsRepository {
    override suspend fun contacts(): List<Contact> = withContext(Dispatchers.IO) { provider.load() }
}
