package com.example.dialer.data.local
import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [CallEntity::class], version = 1, exportSchema = false)
abstract class DialerDatabase : RoomDatabase() {
    abstract fun callDao(): CallDao
}
