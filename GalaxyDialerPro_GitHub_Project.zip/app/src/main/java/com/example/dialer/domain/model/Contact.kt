package com.example.dialer.domain.model
data class Contact(val id: Long, val name: String, val number: String)
