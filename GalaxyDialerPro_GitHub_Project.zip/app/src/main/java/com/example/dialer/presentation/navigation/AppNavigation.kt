package com.example.dialer.presentation.navigation
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.padding
import androidx.navigation.compose.*
import androidx.navigation.NavGraph.Companion.findStartDestination
import com.example.dialer.presentation.screens.*

private data class Tab(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)
@Composable
fun AppNavigation(onCall: (String) -> Unit) {
    val tabs = listOf(
        Tab("favorites","علاقه‌مندی‌ها",Icons.Default.Favorite),
        Tab("recents","اخیر",Icons.Default.History),
        Tab("contacts","مخاطبین",Icons.Default.Contacts),
        Tab("keypad","شماره‌گیر",Icons.Default.Dialpad)
    )
    val nav = rememberNavController()
    Scaffold(
        bottomBar = {
            NavigationBar {
                val current = nav.currentBackStackEntryAsState().value?.destination?.route
                tabs.forEach { tab ->
                    NavigationBarItem(
                        selected = current == tab.route,
                        onClick = { nav.navigate(tab.route) {
                            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true; restoreState = true
                        } },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(navController = nav, startDestination = "keypad", modifier = Modifier.padding(padding)) {
            composable("keypad") { KeypadScreen(onCall) }
            composable("contacts") { ContactsScreen() }
            composable("recents") { RecentsScreen() }
            composable("favorites") { FavoritesScreen() }
        }
    }
}
