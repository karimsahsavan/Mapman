package com.example.dialer.domain.usecase
class NormalizeSearch {
    operator fun invoke(input: String): String = input
        .replace('ي','ی').replace('ك','ک')
        .map { c -> when(c) {
            in '۰'..'۹' -> ('0'.code + c.code - '۰'.code).toChar()
            in '٠'..'٩' -> ('0'.code + c.code - '٠'.code).toChar()
            else -> c
        }}.joinToString("").lowercase().trim()
}
